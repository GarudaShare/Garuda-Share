COMPATIBLE_MACHINE:sama5d29-garuda3-noremmc = "(sama5d29-garuda3-noremmc)"
COMPATIBLE_MACHINE:sama5d29-garuda3-emmc = "(sama5d29-garuda3-emmc)"

FILESEXTRAPATHS:prepend := "${THISDIR}/${PN}-${LINUX_VERSION}:"

#SRC_URI:append:sama5d29-garuda3-noremmc = " file://sama5.cfg"
SRC_URI:append:sama5d29-garuda3-noremmc = " file://at91-sama5d29_garuda3.dts;subdir=git/arch/arm/boot/dts/microchip"
SRC_URI:append:sama5d29-garuda3-noremmc = " file://defconfig"
SRC_URI:append:sama5d29-garuda3-noremmc = " file://mmc-lower_clk_force_cd.patch"
SRC_URI:append:sama5d29-garuda3-noremmc = " file://sama5d2_dtsi-can_clock_rate_fix.patch"
SRC_URI:append:sama5d29-garuda3-noremmc = " file://m_can-napi_fix.patch"
SRC_URI:append:sama5d29-garuda3-noremmc = " file://kernel-reduced_spurious_irqs.patch"
SRC_URI:append:sama5d29-garuda3-noremmc = " file://atmel_kwp_uart.patch"

#SRC_URI:append:sama5d29-garuda3-emmc = " file://sama5.cfg"
SRC_URI:append:sama5d29-garuda3-emmc = " file://at91-sama5d29_garuda3.dts;subdir=git/arch/arm/boot/dts/microchip"

