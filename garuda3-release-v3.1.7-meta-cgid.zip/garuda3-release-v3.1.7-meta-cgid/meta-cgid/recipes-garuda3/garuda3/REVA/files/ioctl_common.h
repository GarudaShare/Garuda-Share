#ifndef IOCTL_COMMON_H
#define IOCTL_COMMOM_H

#include<linux/ioctl.h>

#define ATMEL_IOCTL_MAGIC 'A'

#define ATMEL_IOCTL_SET_KWP_BAUD  _IOW(ATMEL_IOCTL_MAGIC, 0xA1, unsigned int)


#define ATMEL_IOCTL_SET_LIN_BAUD  _IOW(ATMEL_IOCTL_MAGIC, 0xA2, unsigned int)


#define ATMEL_IOCTL_SET_LIN_ID  _IOW(ATMEL_IOCTL_MAGIC, 0xA3, unsigned int)


#define ATMEL_IOCTL_SET_PARITY  _IOW(ATMEL_IOCTL_MAGIC, 0xA4, unsigned int)

#define ATMEL_IOCTL_ENABLE_KWP_TX_RX   _IOW(ATMEL_IOCTL_MAGIC, 0xA5, unsigned int)

#define ATMEL_IOCTL_SEND_DATA _IOW(ATMEL_IOCTL_MAGIC, 0xA6, unsigned int)

#define ATMEL_IOCTL_RAW_mode   _IOW(ATMEL_IOCTL_MAGIC, 0xA7, unsigned int)


#define ATMEL_IOCTL_SET_TIMER   _IOW(ATMEL_IOCTL_MAGIC, 0xA8, unsigned int)

#define ATMEL_KWP_CHECK_TIMEOUT  _IOW(ATMEL_IOCTL_MAGIC, 0xA9, unsigned int)



#define ATMEL_PARITY_NONE 0
#define ATMEL_PARITY_EVEN 1
#define ATMEL_PARITY_ODD 2
#define ATMEL_PARITY_SPACE 3
#define ATMEL_PARITY_MARK 4


#endif
