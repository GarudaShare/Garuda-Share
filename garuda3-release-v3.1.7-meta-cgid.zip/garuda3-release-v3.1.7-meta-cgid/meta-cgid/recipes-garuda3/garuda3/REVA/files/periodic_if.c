


#include	<unistd.h>
#include	<glib.h>
#include	"kwp_if.h"
#include        <termios.h>
#include        <termios.h>
#include 	<time.h>
#include	<sys/timerfd.h>
#include 	"doip_cli.h"
#include  <fcntl.h>
#include  <errno.h>
#include <sys/stat.h>
#include <stdio.h>
#include "periodic_if.h"

/* Holds the structure of periodic messages that are to be transmitted */

#define    c_MAX_PERIODIC_MSG          10
#define    c_TX_IMMEDIATE_CNT          1
#define    PERIODIC_STEPVAL            1000
#define    TICK_PERIOD_MS              1 /* 1000/1000 */

PERIODIC_MSG local_pmsg_buf[NO_OF_CHANNEL_USED][c_MAX_PERIODIC_MSG];
GIOChannel *ch_periodic;

extern uint32_t GarudaProID_Used[NO_OF_CHANNEL_USED];

static uint8_t periodic_startnew_pmsg(PERIODIC_MSG *p_msg_ptr);
static void periodic_handle(uint8_t index);
static void periodic_handle_DOIP(uint8_t index);
static uint8_t periodic_stop_pmsg( uint8_t p_pmsg_id,uint32_t p_protocol_id);
static uint8_t periodic_update_new_pmsg (PERIODIC_MSG  *p_msg_ptr);

static uint8_t local_pmsg_count_hold[NO_OF_CHANNEL_USED];
static uint8_t periodic_cnt;


void PERIODIC_task_handler(void)
{
    uint8_t i,j;
	
	if(periodic_cnt)
	{
		for(j=0;j<NO_OF_CHANNEL_USED;j++)
		{
			if(local_pmsg_count_hold[j] != 0)
			{
				for(i = 0; i < c_MAX_PERIODIC_MSG; i++)
				{
					if(local_pmsg_buf[j][i].prmsg_id != 0)
					{
						local_pmsg_buf[j][i].local_periodicity -= 10; // Every 10ms we are calling this function
                        
						/**< Added to just update the local periodicity in case of overrun : AMIT */ 
						if(local_pmsg_buf[j][i].local_periodicity > local_pmsg_buf[j][i].periodicity)
						{
							local_pmsg_buf[j][i].local_periodicity = local_pmsg_buf[j][i].periodicity;
						}
                        
            			            
						if(local_pmsg_buf[j][i].local_periodicity <= 0)
						{
							switch(j)
							{
								case GARUDA_KWP_CH1:
								{
									/* Call transmit function for 9141 / 14230 */
									if(kwp_MessageIdle() == FALSE)
										periodic_handle(i);
									break;
								}
								case GARUDA_DOIP:
								{
									periodic_handle_DOIP(i);
									break;
								}	
								default :
								{
									/* Do nothing */
									break;
								}
							}
							local_pmsg_buf[j][i].local_periodicity = local_pmsg_buf[j][i].periodicity;
						}
						else {
							/* do nothing */
						}
					}
					else {
						/* do nothing */
					}
				}
			}
			else {
				/* do nothing */
			}
		}
	}
	else {
		/* do nothing */
	}
}

static void periodic_handle_DOIP(uint8_t index)
{

	doip_conn_table_t *conn;
        int ret;	

	int i;
	conn = doip_cli_ipaddr_to_conn_table(local_pmsg_buf[GARUDA_DOIP][index].u.doip_periodic_send_data.ipaddr);
        if (conn == NULL) {
                DBG("No server with %s is added", local_pmsg_buf[GARUDA_DOIP][index].u.doip_periodic_send_data.ipaddr);
                return ERR_FAILED;
        }

        ret  = doip_cli_send_diag_msg(conn, local_pmsg_buf[GARUDA_DOIP][index].u.doip_periodic_send_data.dst_laddr, 
					local_pmsg_buf[GARUDA_DOIP][index].u.doip_periodic_send_data.seqNum,
                                        local_pmsg_buf[GARUDA_DOIP][index].u.doip_periodic_send_data.lastpkt, 
					local_pmsg_buf[GARUDA_DOIP][index].u.doip_periodic_send_data.msg_len,
				     	local_pmsg_buf[GARUDA_DOIP][index].u.doip_periodic_send_data.diag_data);

	if (ret < 0) {
                DBG("DiagMsg send failed");
                return ERR_FAILED;
        }


}


static void periodic_handle(uint8_t index)
{
    ISO9141_14230_TxMsg_S fl_App_ISO9141_14230TxMsg_S;
    ISO9141_14230_RETCODE fl_ISO9141_14230RetStatus;
    uint16_t loop_cnt;

    /* Determine the Tx message */
    ISO9141_14230_TxMsg_S_Buffer.Flags  = local_pmsg_buf[GARUDA_KWP_CH1][index].proto_msg.tx_flags;
    ISO9141_14230_TxMsg_S_Buffer.Length = local_pmsg_buf[GARUDA_KWP_CH1][index].proto_msg.length;

    for(loop_cnt = 0;  loop_cnt < ISO9141_14230_TxMsg_S_Buffer.Length; loop_cnt++)
    {
        ISO9141_14230_TxMsg_S_Buffer.Data[loop_cnt] = local_pmsg_buf[GARUDA_KWP_CH1][index].proto_msg.data[loop_cnt];
    }
    /* Call the Write Message function */

    fl_ISO9141_14230RetStatus = ISO9141_14230_WriteMsg();

    if(NO_ERROR != fl_ISO9141_14230RetStatus)
    {
      /* Q Full - Discard Message */
    }

}


static uint8_t periodic_startnew_pmsg(PERIODIC_MSG *p_msg_ptr)
{
    uint8_t fl_ret_val = PERIODIC_FAILED,fl_ProtoIndex,i,j;

    /* find the Protocol Table Index using the Protocol ID */
    for(fl_ProtoIndex=0; fl_ProtoIndex< NO_OF_CHANNEL_USED;fl_ProtoIndex++)
    {
        if(p_msg_ptr->protocol_id == GarudaProID_Used[fl_ProtoIndex])
	    {
	         /* The Protocol ID Matched @fl_ProtoIndex*/
             break;
	    }
    }
    /* The Protocol ID is not in the Table */
    if(fl_ProtoIndex == NO_OF_CHANNEL_USED)
    {
        fl_ret_val = PERIODIC_INVALID_PROTOCOL_ID;
    }
    else
    {
        /*
        * verify for buffer full
        */

        if(local_pmsg_count_hold[fl_ProtoIndex] == 10)
        {
            fl_ret_val = PERIODIC_EXCEEDED_LIMIT;
        }
        else
        {

            for(i = 0; i < c_MAX_PERIODIC_MSG; i++)
            {
                /*
                * search fr free buffer
                */

                if(local_pmsg_buf[fl_ProtoIndex][i].prmsg_id == 0)
                {
                    /* Store the Free Id  (1 to 10) */
                    local_pmsg_buf[fl_ProtoIndex][i].prmsg_id = i + 1;
		
	                  /* Update Id for response */
		    if(p_msg_ptr->protocol_id == DOIP_PROTOCOL_ID)
		    {
			p_msg_ptr->prmsg_id = local_pmsg_buf[fl_ProtoIndex][i].prmsg_id;

			    local_pmsg_buf[fl_ProtoIndex][i].u.doip_periodic_send_data.seqNum = p_msg_ptr->u.doip_periodic_send_data.seqNum;

			    local_pmsg_buf[fl_ProtoIndex][i].u.doip_periodic_send_data.lastpkt = p_msg_ptr->u.doip_periodic_send_data.lastpkt;

			    local_pmsg_buf[fl_ProtoIndex][i].u.doip_periodic_send_data.dst_laddr = p_msg_ptr->u.doip_periodic_send_data.dst_laddr;

			    memcpy(local_pmsg_buf[fl_ProtoIndex][i].u.doip_periodic_send_data.ipaddr, p_msg_ptr->u.doip_periodic_send_data.ipaddr, IPV4_STR_ADDR_LEN);

			    local_pmsg_buf[fl_ProtoIndex][i].u.doip_periodic_send_data.msg_len = p_msg_ptr->u.doip_periodic_send_data.msg_len;
			    

			    for(j = 0; j < local_pmsg_buf[fl_ProtoIndex][i].u.doip_periodic_send_data.msg_len; j++){
	                            local_pmsg_buf[fl_ProtoIndex][i].u.doip_periodic_send_data.diag_data[j] = p_msg_ptr->u.doip_periodic_send_data.diag_data[j];
				}

			    local_pmsg_buf[fl_ProtoIndex][i].periodicity = (p_msg_ptr->periodicity * TICK_PERIOD_MS);
			    
			    local_pmsg_buf[fl_ProtoIndex][i].local_periodicity = c_TX_IMMEDIATE_CNT;
		
			(local_pmsg_count_hold[fl_ProtoIndex])++;
                         periodic_cnt++;		    
		}
		    else
		    {
                    	p_msg_ptr->prmsg_id = local_pmsg_buf[fl_ProtoIndex][i].prmsg_id;

                    local_pmsg_buf[fl_ProtoIndex][i].proto_msg.tx_flags = p_msg_ptr->proto_msg.tx_flags;
                    local_pmsg_buf[fl_ProtoIndex][i].proto_msg.length = p_msg_ptr->proto_msg.length;
                    for(j = 0; j < local_pmsg_buf[fl_ProtoIndex][i].proto_msg.length; j++)
                            local_pmsg_buf[fl_ProtoIndex][i].proto_msg.data[j] = p_msg_ptr->proto_msg.data[j];

                   	 /* local_pmsg_buf[fl_ProtoIndex][i].periodicity = (p_msg_ptr->periodicity * 1000) / PERIODIC_STEPVAL; */
                    	local_pmsg_buf[fl_ProtoIndex][i].periodicity = (p_msg_ptr->periodicity * TICK_PERIOD_MS);
                    	/* Transmit first message immediately, so local periodicity shd be c_TX_IMMEDIATE_CNT */
                    	local_pmsg_buf[fl_ProtoIndex][i].local_periodicity = c_TX_IMMEDIATE_CNT;
                   	(local_pmsg_count_hold[fl_ProtoIndex])++;
                    	periodic_cnt++;
		    }
                    fl_ret_val = PERIODIC_SUCCESS;
                    /* Increment the count of periodic message for the channel */
                    break;
                }
				else{
					/* do nothing */
				}
            }
        }
    }
    return fl_ret_val;
}



static uint8_t periodic_stop_pmsg( uint8_t p_pmsg_id,uint32_t p_protocol_id)
{
    uint8_t fl_ret_val = PERIODIC_FAILED,fl_ProtoIndex,i;

    /* find the Protocol Table Index using the Protocol ID */
    for(fl_ProtoIndex=0;fl_ProtoIndex<NO_OF_CHANNEL_USED;fl_ProtoIndex++)
    {
        if(p_protocol_id==GarudaProID_Used[fl_ProtoIndex])
	    {
	         /* The Protocol ID Matched @fl_ProtoIndex*/
             break;
	    }
    }
    /* The Protocol ID is not in the Table */
    if(fl_ProtoIndex==NO_OF_CHANNEL_USED)
    {
        fl_ret_val = PERIODIC_INVALID_PROTOCOL_ID;
    }
    else
    {
        /*
         * verifies for valid periodic msg id
         */

        if((p_pmsg_id < 1) || (p_pmsg_id > 10))
        {
            fl_ret_val = PERIODIC_INVALID_MSG_ID;
        }
        else
        {
            for(i=0; i<c_MAX_PERIODIC_MSG; i++)
            {
                 if(local_pmsg_buf[fl_ProtoIndex][i].prmsg_id == p_pmsg_id)
                 {
                    local_pmsg_buf[fl_ProtoIndex][i].prmsg_id = 0;
                    (local_pmsg_count_hold[fl_ProtoIndex])--;
                    if(periodic_cnt)
                        periodic_cnt--;
                    fl_ret_val = PERIODIC_SUCCESS;
                 }
            }
            if( fl_ret_val!= PERIODIC_SUCCESS)
            {

                fl_ret_val = PERIODIC_INVALID_MSG_ID;
            }
        }
    }
    return fl_ret_val;
}


uint8_t periodic_suspend_pmsg(uint32_t p_protocol_id)
{

    uint8_t fl_ret_val = PERIODIC_FAILED,fl_ProtoIndex,i;

    /* find the Protocol Table Index using the Protocol ID */
    for(fl_ProtoIndex=0;fl_ProtoIndex<NO_OF_CHANNEL_USED;fl_ProtoIndex++)
    {
        if(p_protocol_id==GarudaProID_Used[fl_ProtoIndex])
	    {
	         /* The Protocol ID Matched @fl_ProtoIndex*/
             break;
	    }
    }
    /* The Protocol ID is not in the Table */
    if(fl_ProtoIndex==NO_OF_CHANNEL_USED)
    {
        fl_ret_val = PERIODIC_INVALID_PROTOCOL_ID;
    }
    else
    {
        if((local_pmsg_count_hold[fl_ProtoIndex])!= 0)
        {
            for(i = 0; i < c_MAX_PERIODIC_MSG; i++)
            {
                local_pmsg_buf[fl_ProtoIndex][i].prmsg_id = 0;
            }
            local_pmsg_count_hold[fl_ProtoIndex]=0;
            fl_ret_val = PERIODIC_SUCCESS;
        }
        else
        {
            fl_ret_val = PERIODIC_FAILED;
        }
    }
    return fl_ret_val;
}

static uint8_t periodic_update_new_pmsg (PERIODIC_MSG  *p_msg_ptr)
{
    uint8_t fl_ret_val = PERIODIC_FAILED,fl_ProtoIndex,i,j;

    /* find the Protocol Table Index using the Protocol ID */
    for(fl_ProtoIndex=0;fl_ProtoIndex<NO_OF_CHANNEL_USED;fl_ProtoIndex++)
    {
        if(p_msg_ptr->protocol_id==GarudaProID_Used[fl_ProtoIndex])
        {
            /* The Protocol ID Matched @fl_ProtoIndex*/
            break;
        }
	else{
			/* do nothing */
	}
    }

    /* The Protocol ID is not in the Table */
    if(fl_ProtoIndex==NO_OF_CHANNEL_USED)
    {
        fl_ret_val = PERIODIC_INVALID_PROTOCOL_ID;
    }
    else
    {
        if((p_msg_ptr->prmsg_id < 1) || (p_msg_ptr->prmsg_id > 10))
        {
            fl_ret_val = PERIODIC_INVALID_MSG_ID;
        }
        else
        {
            /**< Disable Timer Interrupt */
            /**< __disable_interrupt(); */
            //Disable_Timer_Irq();

            for(i=0; i<c_MAX_PERIODIC_MSG; i++)
            {
                if(local_pmsg_buf[fl_ProtoIndex][i].prmsg_id == p_msg_ptr->prmsg_id)
                {


		    if(p_msg_ptr->protocol_id == DOIP_PROTOCOL_ID)
                    {
                            local_pmsg_buf[fl_ProtoIndex][i].u.doip_periodic_send_data.seqNum = p_msg_ptr->u.doip_periodic_send_data.seqNum;

                            local_pmsg_buf[fl_ProtoIndex][i].u.doip_periodic_send_data.lastpkt = p_msg_ptr->u.doip_periodic_send_data.lastpkt;

                            local_pmsg_buf[fl_ProtoIndex][i].u.doip_periodic_send_data.dst_laddr = p_msg_ptr->u.doip_periodic_send_data.dst_laddr;

                            memcpy(local_pmsg_buf[fl_ProtoIndex][i].u.doip_periodic_send_data.ipaddr, p_msg_ptr->u.doip_periodic_send_data.ipaddr, IPV4_STR_ADDR_LEN);

                            local_pmsg_buf[fl_ProtoIndex][i].u.doip_periodic_send_data.msg_len = p_msg_ptr->u.doip_periodic_send_data.msg_len;

                            for(j = 0; j < local_pmsg_buf[fl_ProtoIndex][i].u.doip_periodic_send_data.msg_len; j++)
                                    local_pmsg_buf[fl_ProtoIndex][i].u.doip_periodic_send_data.diag_data[j] = p_msg_ptr->u.doip_periodic_send_data.diag_data[j];



                            local_pmsg_buf[fl_ProtoIndex][i].periodicity = (p_msg_ptr->periodicity * TICK_PERIOD_MS);

                            local_pmsg_buf[fl_ProtoIndex][i].local_periodicity = c_TX_IMMEDIATE_CNT;
                    }
                    else
                    {

                   	 /**< Copy Tx Flags */
                   	 local_pmsg_buf[fl_ProtoIndex][i].proto_msg.tx_flags =
                   	 p_msg_ptr->proto_msg.tx_flags;

                   	 /**< Copy Message Length */
                   	 local_pmsg_buf[fl_ProtoIndex][i].proto_msg.length =
                   	 p_msg_ptr->proto_msg.length;

                   	 /**< Copy Data */
                   	 for(j = 0; j < local_pmsg_buf[fl_ProtoIndex][i].proto_msg.length; j++)
                 		 local_pmsg_buf[fl_ProtoIndex][i].proto_msg.data[j] = p_msg_ptr->proto_msg.data[j];

	                 /**< Copy Periodicity and local Periodicity */
           		 local_pmsg_buf[fl_ProtoIndex][i].periodicity = (p_msg_ptr->periodicity * portTICK_PERIOD_MS);
               	    /* local_pmsg_buf[fl_ProtoIndex][i].local_periodicity = local_pmsg_buf[fl_ProtoIndex][i].periodicity; */
        	         local_pmsg_buf[fl_ProtoIndex][i].local_periodicity = c_TX_IMMEDIATE_CNT;
	
                	    /**< Handling required */
                	     //PERIODIC_handler();
	           }
                    fl_ret_val = PERIODIC_SUCCESS;
                }
		else{
					/* do nothing */
            	}
            	/**< Enable Timer Interrupt */
            	/**< __enable_interrupt(); */
            	//Enable_Timer_Irq();
        	}
	}
    }
    return fl_ret_val;
}


uint8_t PERIODIC_task_msg_cmd(PERIODIC_MSG *p_msg_ptr, uint8_t p_periodic_cmd)
{
    uint8_t fl_ret_val = PERIODIC_FAILED;

    switch(p_periodic_cmd)
    {
        case PERIODIC_STARTNEW_PMSG:
        {
            if ((p_msg_ptr->periodicity >= 5) && (p_msg_ptr->periodicity <= 65535))
            {
              fl_ret_val = periodic_startnew_pmsg(p_msg_ptr);
            }
            else
            {
                fl_ret_val = PERIODIC_INVALID_TIME_INTERVAL;
            }
              break;
        }

        case PERIODIC_STOP_PMSG :
        {
	      fl_ret_val = periodic_stop_pmsg(p_msg_ptr->prmsg_id, p_msg_ptr->protocol_id);
              break;
        }

        case PERIODIC_SUSPEND_PMSG:
        {
              fl_ret_val = periodic_suspend_pmsg(p_msg_ptr->protocol_id);
              break;
        }

        case PERIODIC_UPDATE_PMSG:
        {
              if ((p_msg_ptr->periodicity >= 5) &&
              (p_msg_ptr->periodicity <= 65535))
              {
                  fl_ret_val = periodic_update_new_pmsg(p_msg_ptr);
              }
              else
              {
                  fl_ret_val = PERIODIC_INVALID_TIME_INTERVAL;
              }
              break;              
        }

        case PERIODIC_CHANGE_PERIOD_PMSG :
        {
              /* Do nothing */
              break;
        }
        default :
        {
              fl_ret_val = PERIODIC_FAILED;
              break;
        }
    }
    return fl_ret_val;
}




static gboolean timer_10ms_elapsed(GIOChannel *source, GIOCondition cond, gpointer user_data) {
        int tfd = g_io_channel_unix_get_fd(source);
        uint64_t expirations = 0;
        static uint64_t iter;
        ssize_t r = read(tfd, &expirations, sizeof(expirations));
        if (r < 0) {
                if (errno == EINTR || errno == EAGAIN) return TRUE;
                g_warning("read(timerfd) failed: %s", g_strerror(errno));
                return TRUE;
        }
    // ----  catch up on all missed expirations ----
        for (iter = 0; iter < expirations; iter++) {
		PERIODIC_task_handler();
        }

    return TRUE; // keep the watch active
}


int periodic_init()
{


	int tfd = timerfd_create(CLOCK_MONOTONIC, TFD_CLOEXEC | TFD_NONBLOCK);
        if (tfd < 0) { perror("timerfd_create"); return 1; }

	struct itimerspec its = {0};
	

	its.it_value.tv_sec = 0; its.it_value.tv_nsec = 10 * 1000 * 1000;   // first in 10ms
        its.it_interval = its.it_value;                            // periodic 10ms
        timerfd_settime(tfd, 0, &its, NULL);


	ch_periodic = g_io_channel_unix_new(tfd);
        g_io_add_watch(ch_periodic, G_IO_IN, timer_10ms_elapsed, NULL);


	return 0;
}



