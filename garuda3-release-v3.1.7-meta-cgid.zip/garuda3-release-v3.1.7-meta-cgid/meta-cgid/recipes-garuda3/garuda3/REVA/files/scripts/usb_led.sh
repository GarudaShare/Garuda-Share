#!/bin/sh

check_usb_led()
{
	while true; do
		if [ "$(cat /sys/devices/platform/ahb/300000.gadget/udc/300000.gadget/is_selfpowered)" = "0" ]; then
			echo 1 > /sys/class/leds/usb-led/brightness
		else
			echo 0 > /sys/class/leds/usb-led/brightness
		fi
	done
}
check_usb_led
