#!/bin/sh
#
# Copyright (c) 2023-2024, Capgemini - Intelligent Devices
#

GADGET_DIR=/sys/kernel/config/usb_gadget
GADGET_DEV=g1
# UDC Name for SAMA5D29C
UDC_NAME="300000.gadget"
# UDC Name for Raspberry Pi 5
#UDC_NAME="1000480000.usb"
HIDDESC=/tmp/hiddesc.bin
USB_VID=0x03eb
USB_PID=0x5746
USB_VERSION=0x0320
USB_DEVICEVERSION=0x0100
USB_SRNO="1234567890"
USB_MANF="Capgemini"
USB_PRODUCT="Garuda 3"
VERBOSE=${VERBOSE:=0}

minfo()
{
	if [ ${VERBOSE} == 1 ]; then
		echo $*
	fi
}

gadget_setup_configurations()
{
	# Setup the configurations and strings directories
	if [ ! -d "configs/c.1" ]; then
		mkdir "configs/c.1"
		minfo "configs/c.1 created."
	fi

	if [ ! -d "configs/c.1/strings/0x409" ]; then
		mkdir "configs/c.1/strings/0x409"
		minfo "configs/c.1/strings/0x409 created."
	fi
}

gadget_setup_hid()
{
	echo "HID+RNDIS+CDC-ACM" > configs/c.1/strings/0x409/configuration
	echo 250 > configs/c.1/MaxPower
	echo 0x80 > configs/c.1/bmAttributes

	# HID Function
	if [ ! -d "functions/hid.usb0" ]; then
		mkdir "functions/hid.usb0"
		minfo "hid.usb0 created."
	fi

	echo -ne \\x06\\xA0\\xFF\\x09\\x01\\xA1\\x01\\x09 > $HIDDESC
	echo -ne \\x02\\x09\\x03\\x15\\x00\\x26\\xFF\\x00 >> $HIDDESC
	echo -ne \\x75\\x08\\x96\\x00\\x02\\x81\\x00\\x09 >> $HIDDESC
	echo -ne \\x04\\x09\\x05\\x15\\x00\\x26\\xFF\\x00 >> $HIDDESC
	echo -ne \\x75\\x08\\x96\\x00\\x02\\x91\\x00\\x09 >> $HIDDESC
	echo -ne \\x06\\x09\\x07\\x15\\x00\\x26\\xFF\\x00 >> $HIDDESC
	echo -ne \\x75\\x08\\x95\\x04\\xB1\\x02\\xC0 >> $HIDDESC

	echo 1 > functions/hid.usb0/protocol
	echo 1 > functions/hid.usb0/subclass
	echo 513 > functions/hid.usb0/report_length
	cat $HIDDESC > functions/hid.usb0/report_desc

	ln -s functions/hid.usb0 configs/c.1
}

gadget_setup_rndis()
{
	# RNDIS function
	echo "1" > os_desc/use
	echo "0xcd" > os_desc/b_vendor_code
	echo "MSFT100" > os_desc/qw_sign

	if [ ! -d "functions/rndis.usb0" ]; then
		mkdir "functions/rndis.usb0"
		minfo "rndis.usb0 created."
	fi

	RNDIS_IF=functions/rndis.usb0/os_desc/interface.rndis
	echo "RNDIS" > ${RNDIS_IF}/compatible_id
	echo "5162001" > ${RNDIS_IF}/sub_compatible_id

	ln -s functions/rndis.usb0 configs/c.1
	ln -s configs/c.1 os_desc
}

gadget_setup_acm()
{
	# ACM function
	if [ ! -d "functions/acm.usb0" ]; then
		mkdir "functions/acm.usb0"
		minfo "acm.usb0 directory created."
	fi

	ln -s functions/acm.usb0 configs/c.1
}

gadget_create()
{
	if [ ! -d ${GADGET_DIR} ]; then
		modprobe libcomposite
	fi

	if [ ! -d "${GADGET_DIR}/${GADGET_DEV}" ]; then
		mkdir "${GADGET_DIR}/${GADGET_DEV}"
		minfo "${GADGET_DEV} created."
	fi

	cd ${GADGET_DIR}/${GADGET_DEV}

	echo $USB_VID > idVendor
	echo $USB_PID > idProduct
	echo ${USB_VERSION} > bcdUSB
	echo ${USB_DEVICEVERSION} > bcdDevice

	if [ ! -d "strings/0x409" ]; then
		mkdir "strings/0x409"
		minfo "strings/0x409 created."
	fi

	echo "${USB_SRNO}" > strings/0x409/serialnumber
	echo "${USB_MANF}" > strings/0x409/manufacturer
	echo "${USB_PRODUCT}" > strings/0x409/product

	gadget_setup_configurations
	# RNDIS has to be the first device
	gadget_setup_rndis
	gadget_setup_hid
	gadget_setup_acm
}

gadget_enable()
{
	echo ${UDC_NAME} > UDC
}

gadget_disable()
{
	pushd . 2>&1 > /dev/null
	cd ${GADGET_DIR}/${GADGET_DEV}
	echo "" > UDC
	popd 2>&1 > /dev/null
}

gadget_remove()
{
	pushd . 2>&1 > /dev/null

	cd ${GADGET_DIR}/${GADGET_DEV}
	# Remove functions from configurations
	rm configs/c.1/acm.usb0
	rm configs/c.1/hid.usb0
	rm configs/c.1/rndis.usb0
	rm os_desc/c.1
	# Remove strings from configurations
	if [ -d configs/c.1/strings/0x409 ]; then
		rmdir configs/c.1/strings/0x409
	fi
	# Remove configurations
	if [ -d configs/c.1 ]; then rmdir configs/c.1; fi
	# Remove functions
	rmdir functions/*
	# Remote gadget strings
	if [ -d strings/0x409 ]; then rmdir strings/0x409; fi
	# Remote the gadget
	cd ..
	if [ -d ${GADGET_DEV} ]; then rmdir ${GADGET_DEV}; fi

	popd 2>&1 > /dev/null
}

display_usage()
{
	echo "$0 [create|remove]"
}

ID=`id -u`
if [ "${ID}" != "0" ]; then
	echo "This script must be run as root!"
	exit 1
fi

if [ $# -eq 0 ]; then
	gadget_create
	gadget_enable
	exit 0
fi

while [ $# -gt 0 ]; do
	case $1 in
	"create")
		gadget_create
		gadget_enable
		shift
		;;
	"remove")
		gadget_disable
		gadget_remove
		shift
		;;
	*)
		echo "Unknown command $1"
		display_usage
		exit 1
		;;
	esac
done

