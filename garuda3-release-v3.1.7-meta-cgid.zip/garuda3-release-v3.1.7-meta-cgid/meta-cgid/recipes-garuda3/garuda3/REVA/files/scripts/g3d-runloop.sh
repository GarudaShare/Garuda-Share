#!/bin/sh

CMD=/usr/sbin/g3d

while true; do
#        echo " Run g3d"
        $CMD
        echo "KILL G3D"
        killall -9 $CMD
#        sleep 1
done

