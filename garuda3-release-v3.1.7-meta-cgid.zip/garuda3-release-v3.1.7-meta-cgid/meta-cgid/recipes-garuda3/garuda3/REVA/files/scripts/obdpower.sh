#!/bin/sh

GPIO=30
GPIONAME=PA30
ETHIF=eth0
CANIF_0=can0
CANIF_1=can1

if [ ! -d /sys/class/gpio/${GPIONAME} ]; then
    echo $GPIO > /sys/class/gpio/export
fi

# Set as input
echo in > /sys/class/gpio/${GPIONAME}/direction

# Read initial state
# $(cat /sys/class/gpio/${GPIONAME}/value)
prev_obdpowered=0

while true; do
    obdpowered=$(cat /sys/class/gpio/${GPIONAME}/value)
    if [ ${obdpowered} != ${prev_obdpowered} ]; then
    	# OBD power changed state
    	if [ ${obdpowered} == 1 ]; then
	        echo "OBD Power (PA30) went from 0 to 1 → restarting ${ETHIF}"
    		ifconfig ${ETHIF} down
		rmmod macb micrel
	        modprobe macb micrel
		ip link set ${CANIF_0} up type can bitrate 500000 sample-point 0.875 restart-ms 200
		ip link set ${CANIF_1} up type can bitrate 500000 sample-point 0.875 restart-ms 200
    		ifconfig ${ETHIF} up
    	else
	        echo "OBD Power (PA30) went from 1 to 0 → downing ${ETHIF}"
		ip link set ${CANIF_0} down
		ip link set ${CANIF_1} down
    		ifconfig ${ETHIF} down
    		rmmod macb micrel
    	fi
    	prev_obdpowered=${obdpowered}
    fi
    sleep 1
done

