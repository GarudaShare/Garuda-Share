


#include <unistd.h>
#include <glib.h>
#include <termios.h>
#include <time.h>
#include <sys/timerfd.h>

#include <fcntl.h>
#include <errno.h>
#include <sys/stat.h>
#include <stdio.h>
#include "kwp_if.h"


#define FALSE 0
#define TRUE  1


guint KWP_timeout_id;
guint KWP_watch_id;
GIOChannel *channel;
GIOChannel *ch;

/*Counter to Timer conversion*/
#define TIME_COUNTER_TO_MS (timer_counter*1000)



/******************************************************************************
*                   P R I V A T E   V A R I A B L E S
*******************************************************************************/

UARTContext *Global_uart_ctx = NULL;

struct T_GPIO_context	GPIO_KWP_TXD;
struct T_GPIO_context	GPIO_KLINE_LLINE_SLCT;
struct T_GPIO_context	GPIO_KLINE_PULLUP_SLCT;
struct T_GPIO_context	GPIO_LLINE_ISO_SLCT;
struct T_GPIO_context	GPIO_KLINE_ISO_SLCT;
struct T_GPIO_context	GPIO_KW_TX_5BAUD;

/* Init Link Information */
static volatile ISO9141_14230_LinkInit_S l_ISO9141_14230LinkInit_S;

/* Init Link Return information */
static volatile ISO9141_14230_LinkInitRet_S l_ISO9141_14230LinkInitRet_S;

/* ISO 9141 / 14230 Parameters */

static uint32_t l_5BaudIdleTime;	/* 5 Baud idle time - W0 or W5 */
static uint32_t l_loopback;	/* Loopback enabled? 1- Yes, 0 - NO */
static uint32_t l_P1MAX;	/* P1 max timing parameter */
static uint32_t l_P3MIN;	/* P3 min timing parameter */
static uint32_t l_P4MIN;	/* P4 min timing parameter */
static uint32_t l_W0;		/* W0 idle time */
static uint32_t l_W1;		/* W1 timing parameter */
static uint32_t l_W2;		/* W2 timing parameter */
static uint32_t l_W3;		/* W3 timing parameter */
static uint32_t l_W4;		/* W4 timing parameter */
static uint32_t l_W5;		/* W5 idle time */
static uint32_t l_TIDLE;	/* Idle time for Fast init */
static uint32_t l_TINIL;	/* Low time for Fast init pattern */
static uint32_t l_TWUP;		/* Wakeup time for Fast init pattern */
static uint32_t l_BaudRate;	/* Baud rate for UART */
static volatile uint16_t l_UARTIntrTxIndex;	/* UART Interrupt Tx length calculation */
static volatile uint16_t l_RxLength;	/* Receive message length */
static volatile uint16_t l_TxLength;	/* Transmit message length */
static volatile uint16_t l_TxIndex;	/* Tx byte index */
static uint32_t l_ProtocolId;	/* Protocol Id */
static uint8_t l_Parity;	/* Parity configuration */
static uint8_t l_DataBits;	/* Number of data bits */
static uint8_t l_FiveBaudMod;	/* Five baud mode */
static volatile uint8_t l_InitStatus;	/* Status of Initialization of link */
static volatile uint8_t l_BitPos;	/* Bit position for 5 Baud or Fast Init */
static uint8_t l_ConnectFlags;	/* Connect Flags */
static uint16_t l_LengthByte;	/* Length byte index */
static uint16_t l_PktLength;	/* Defines the packet length of Handling data wrt length */
static uint32_t l_P1MAX_ExtendedTimeout;	/* Extended P1Max to find the maximum timeout for P1_Max */

/* Kwp_int */
static int fd =0;

/* Queue variables */


static volatile bool l_P3MINTimeout;	/* P3Min timeout indication */
static volatile bool l_MsgReceived;	/* Message Received Indication */
static volatile bool l_TxComp;	/* Tx completion indication */
static uint8_t l_InitTimer;	/* ISO 9141 / 14230 Timer for
				   Initialization */

/* FreeRTOS's returned timer handler, used for uart time guard and receive time out */

static int baudrate;
static int dataLength;
const char *devicePath;
static uint32_t ISO_9141_OR_14230 = 0; // kwp_ch
static uint32_t timer_counter = 0;    //kwp_add

/* KWP Timer handler variables */
static bool timer_handler_flag;
static bool timer_init_flag = FALSE;
timeout_param_s timeout_param_s_var;

static bool fastinit_start_comm_req_start_flag = 0;
static bool fastinit_start_comm_req_end_flag = 0;

static bool Txtask_data_sent_start_flag = 0;
static bool Txtask_data_sent_end_flag  = 0;
static bool l_p4min_timeout = false;

uint8_t loopcontrol = 0;

static ISO9141_14230_QTYPE buffer_type;
static uint16_t kwp_buffer_length;

/* RxMsg and TxMsg handle variable */
bool kwp_RxMsg_received = FALSE;
bool kwp_RxMsg_buffer_updated = FALSE;
bool kwp_TxMsg_received = FALSE;

ISO9141_14230_RxMsg_S ISO9141_14230_RxMsg_S_Buffer;

/* extern variable define here */
ISO9141_14230_TxMsg_S ISO9141_14230_TxMsg_S_Buffer;

/* PassThruReadMsgResp_KWP variable */
static uint8_t l_KWPRX_SegTrnsfr=0;
static uint16_t data_indx = 1;


static uint8_t l_processData = 0;

unsigned int Kwp_init_timeout;
unsigned int state;
/* Function declarations */
static void ISO9141_14230_LinkInit(void);
static uint8_t ISO9141_14230_GetChecksum(const uint8_t * , uint16_t , uint8_t);
static bool ISO9141_14230_GetParity(void);
static uint16_t ISO9141_14230_Get_Data_Length( uint8_t , uint16_t* );
static void uart_send_data(UARTContext *ctx, char data);
static void uart_send_dataarray(UARTContext *ctx, char *data, int size);

/************************************************************************************************************
 Function name            : KWP_reset_TimeOut()
 Function Parameters type : void
 Short Description        : Function handles the Reset process of timer
 Return		          : void 
*************************************************************************************************************/
void KWP_reset_TimeOut(void)
{
	timer_handler_flag = false;
	timer_counter = 0;
}

/************************************************************************************************************
 Function name            : KWP_Set_TimeOut()
 Function Parameters type : uint32, enum TIMER_WAIT
 Short Description        : Function handles the timer set
 Return                   : void 
*************************************************************************************************************/

void KWP_Set_TimeOut(uint32_t Timer_variable,TIMER_WAIT timer_wait_var )
{
	timer_handler_flag = true;
	timeout_param_s_var.timer_param  = Timer_variable;
	timeout_param_s_var.wait_param_e = timer_wait_var; 
}

/************************************************************************************************************
 Function name            : KWP_TimeOut_handle()
 Function Parameters type : void
 Short Description        : Function handles the after timeout process
 Return                   : void 
*************************************************************************************************************/

void KWP_TimeOut_handle(void) 
{
	uint8_t txData;
	
	/*Init state timeout */
	if(l_InitStatus == LINKINIT_PENDING)
	{ 	
		/*Init 5baud timeout */
		if(l_ISO9141_14230LinkInit_S.InitType == FIVE_BAUD_INIT)
		{
			if (timer_handler_flag == true)
			{					
				if(TIME_COUNTER_TO_MS >= timeout_param_s_var.timer_param )
				{	
					/* print error code */
					switch (timeout_param_s_var.wait_param_e){

					case PATTERN_BYTE_WAIT:
							/* pattern byte error */
							
							/* reset timer_count */
							KWP_reset_TimeOut();
							
							l_RxLength = 0;
							l_TxComp = !FALSE;
							l_P3MINTimeout = !FALSE;
							l_InitStatus = LINKINIT_FAIL;
							
							/* reset the five baud idle time flag */
							timer_init_flag = false;
							
							
							// error handler
							App_ErrHandler(l_ProtocolId,PATTERN_BYTE_TIMEOUT);
							break;
					case KB1_WAIT:
							/*KB1 error*/
							
							/* reset timer_count */
							KWP_reset_TimeOut();
							
							l_RxLength = 0;
							l_TxComp = !FALSE;
							l_P3MINTimeout = !FALSE;
							
							l_InitStatus == LINKINIT_FAIL;
							
							/* reset the five baud idle time flag */
							timer_init_flag = false;
							
							// error handler
							App_ErrHandler(l_ProtocolId, KEY_BYTE1_TIMEOUT);
							break;
					case KB2_WAIT:
							/*KB2 error*/
						
							/* reset timer_count */
							KWP_reset_TimeOut();
							
							l_RxLength = 0;
							l_TxComp = !FALSE;
							l_P3MINTimeout = !FALSE;
	
							l_InitStatus == LINKINIT_FAIL;
							
							/* reset the five baud idle time flag */
							timer_init_flag = false;
							
							// error handler
							App_ErrHandler(l_ProtocolId, KEY_BYTE2_TIMEOUT);
							break;
					case INV_KB2_WAIT:
							
							/* sent tx msg */ 
							if((l_RxLength == ADDRESS_BYTE_INV_POS) && (l_TxLength != 0))
							{
								txData = l_ISO9141_14230LinkInitRet_S.Data[2] ^ 0xFF;
							
								// call tx sent msg function
								uart_send_data(Global_uart_ctx,(char)txData);
								
								if(l_FiveBaudMod == FIVEBAUD_MODE_ZERO)
								{
									/* reset timer_count */
									KWP_reset_TimeOut();
									KWP_Set_TimeOut(W4_MAX_TIME,INV_ADDR_WAIT);
									
								}
								else
								{
									/* do nothing */
								}
							}
							else
							{
								/*do nothing */
							}
							break;
					case INV_ADDR_WAIT:        		
							/*inverse addr byte error */
							/* reset timer_count */
							KWP_reset_TimeOut();
							
							l_RxLength = 0;
							l_TxComp = !FALSE;
							l_P3MINTimeout = !FALSE;
	
							l_InitStatus == LINKINIT_FAIL;
							
							/* reset the five baud idle time flag */
							timer_init_flag = false;
							
							// error handler
							App_ErrHandler(l_ProtocolId, ADDRESS_BYTE_TIMEOUT);
							
							break;
					default:
							break;
					}
				}
				/* waiting for time out */
				else
				{
					//do nothing
				}
			}
			/* waiting for  */
			else
			{
				/*do nothing */
			}
		}

		/*Init FAST INIT timeout */
		else
		{
			if (timer_handler_flag == true)
			{
				
				if(TIME_COUNTER_TO_MS >= timeout_param_s_var.timer_param )
				{	
					
					/* Send Fast init data bytes at every P4MIN elapsed  */
				        /* P3min wait condition not yet required becuase from fast int (timehandler it was set)but now not set like that */ 
					if((timeout_param_s_var.wait_param_e == P3MIN_WAIT)||(timeout_param_s_var.wait_param_e == P4MIN_WAIT)){
						
						/* send start communication service request message */
						if(data_indx < l_TxLength ){

							txData = l_ISO9141_14230LinkInit_S.Data[data_indx] ;
							uart_send_data(Global_uart_ctx,(char)txData);
							data_indx++;
							KWP_reset_TimeOut();
							KWP_Set_TimeOut((l_P4MIN),(P4MIN_WAIT));
						}
						else{
						
						}
						if(data_indx == l_TxLength )
						{
							KWP_reset_TimeOut();
							fastinit_start_comm_req_end_flag = !FALSE;
							
						}
						else
						{
							/* Do nothing */
						}
					
					}
					/* Receiving ECU response for FastInit */
					else{

						if (l_RxLength != 0) {
							/* End of frame indication */

							/* Update the length information */
						
							kwp_buffer_length = l_RxLength;

							/* Reset Rx Length */
							l_RxLength = 0;

							/* Indicate Message received */
							l_MsgReceived = !FALSE;

							/* If P3 min is less than P1max then next Tx could be started immediately else wait for P3min - P1max */
							if (l_P3MIN < l_P1MAX) {

								/* Update the status of P3min timeout */
								l_P3MINTimeout = !FALSE;

							}

							else {
								/* should update the l_InitStatus = LINKINIT_DONE before elasped the time*/

								/* reset timer_count */
								KWP_reset_TimeOut();
								
								KWP_Set_TimeOut(l_P3MIN, P3MIN_WAIT); 

							}
						}

						else {

							/* Timeout on Fast Init ECU reponse */
							/* Call application error handler */

						        App_ErrHandler(l_ProtocolId,FASTINIT_RESP_TIMEOUT);


							/* Set Link Init failure */
							l_InitStatus = LINKINIT_FAIL;

							/* Update the status of P3min timeout - Could load the Tx bytes */
							l_P3MINTimeout = !FALSE;
						}
						
						
					}
				}
				else
				{
						/* do nothing */
				}
			}
		}
	}

	/* Normal Operation - Timeout */
	else if((l_InitStatus == LINKINIT_DONE) || (l_InitStatus == NO_LINKINIT) || (l_InitStatus == LINKINIT_FAIL))
	{
		if (timer_handler_flag == true)
		{

			if(TIME_COUNTER_TO_MS >= timeout_param_s_var.timer_param )
			{

				if(timeout_param_s_var.wait_param_e != P4MIN_WAIT )
				{
					/* Rx message not yet received full packet length */
					if (l_MsgReceived == FALSE) 
					{	
						if (l_RxLength != 0) 
						{		
							if (KWP_PROTOCOL_ID == l_ProtocolId ) 
							{
								/*Rx first byte received but full packet length not received then set extended timeout */
								if( (l_RxLength != l_PktLength) && (l_P1MAX_ExtendedTimeout == false))
								{

							 		l_P1MAX_ExtendedTimeout = true ;

									KWP_reset_TimeOut();	
									KWP_Set_TimeOut(l_P1MAX,P1MAX_WAIT);


								}
								/* Packetlength not received after extended time elapsed*/
								else {
									l_P1MAX_ExtendedTimeout = false;
								
									/* call error handler */
                                                                        App_ErrHandler(l_ProtocolId,ECU_RESP_TIMEOUT);
                                                                        KWP_reset_TimeOut();

								}
							}
							else {
							
							}

						}
						/* RX message not received from ECU */ 	
						else {

							/* Timeout on ECU reponse for Tester request */
							/* Call application error handler */
					       		 App_ErrHandler(l_ProtocolId,ECU_RESP_TIMEOUT); 

							/* Minimum time P3min has elapsed. Next Tx can be started */
							l_P3MINTimeout = !FALSE;
							/* reset timer_count */
							KWP_reset_TimeOut();	

						}
					}

					/* Rx message recieved full packet length */
					else {

						l_P3MINTimeout = !FALSE;
				
                           	        /* it's changed from RX/TX buffer clear IOCTL case to here, Due to before P3 timeout this variable have set FALSE by IOCTL buffer clear call */

                                                              
						/* reset timer_count */
						KWP_reset_TimeOut();
						l_MsgReceived = FALSE; //gowtham

				     	}
				}

				/* Normal Tx consecutive bytes send when P4MIN!=0.First byte send at TXtask */
				else
				{
					if (Txtask_data_sent_start_flag == true ) {
                               			 if (l_TxIndex < l_TxLength) {                                                

                                                	/* Start loading 2 nd byte Tx data onto the UART */

							txData = ISO9141_14230_TxMsg_S_Buffer.Data[l_TxIndex];
                                                        /* Load to UART Tx */
                                                        uart_send_data(Global_uart_ctx,(char)txData);
                                                        /* set P4MIN Time */
                                                        KWP_reset_TimeOut();
                                                        KWP_Set_TimeOut((l_P4MIN),P4MIN_WAIT);
                                                        /* Increment Index */
                                                        l_TxIndex++;
        
                               			 }
					       	else {
					
						}
					 
				       		if (l_TxIndex == l_TxLength) {

							Txtask_data_sent_end_flag = true; 
					 	 }
					 	else {
					       	
					       	}
					}
					else {
						KWP_reset_TimeOut();
					}

				}
			}
			/* Waiting for timeout */
			else {
				/* Do nothing */
			}
		}
		/* Waiting for timer flag set (timer not yet set) */
		else{
			/* Do nothing */
		}	
	}
	else
	{
		/*Do nothing*/
	}
}
/************************************************************************************************************
 Function name             : KWP_Timer_handler()
 Function Parameters type  : void
 Short Description         : Function handles FIVE Baud and FAST Initialisation
			     TimerFd invokes the KWP_Timer_Handler() in expiration of each 1ms
 Return                    : void 
*************************************************************************************************************/

void KWP_Timer_Handler()
{
	uint16_t fl_Cnt;
	uint8_t fl_ChkSum = CHECKSUM_OK;

	/* Determine the status of Init Link */
	if (l_InitStatus == LINKINIT_PENDING) {
			
		timer_counter++;

		/* Determine the type of initialization */
		if (l_ISO9141_14230LinkInit_S.InitType == FIVE_BAUD_INIT) {
			
			
			/* 5 Baud Initialization */
			
			/* Check if the Bus was idle for W5 or W0. If idle perform 5 Baud initialization else wait till W5 or W0 */
			if(TIME_COUNTER_TO_MS >= l_5BaudIdleTime) { 
				timer_init_flag = true;
 
			}
			if (timer_init_flag == true) {

				/* Start bit (if and elseif can handle start bit check and send address bytes)*/ 
				if (l_BitPos == START_BIT_POS) {
					
					/* UART process Disabled*/
					l_processData = 0;

					/* Set K LINE low */
		  	                 T_gpio_PIN_set(&GPIO_KW_TX_5BAUD, 0);                               

					/* Timer counter reset for set FIVE baud time(200ms) */
					timer_counter = 0;

					/* Increment Bit position to Transmit the next bit */
					l_BitPos++;
				}

				/* Send Address byte */

				/* Check if the Bit position neither in Start nor Stop bit position and also check if FIVE Baud time has elapsed since the transmission of Start bit */
				else if ((l_BitPos > START_BIT_POS) && (l_BitPos < STOP_BIT_POS) && (TIME_COUNTER_TO_MS >= FIVE_BAUD_TIME)) {

					/* Transmit address bits till the Bit position reaches MSB */
					if (l_BitPos <= l_DataBits) {

						/* Address decoding - Check if the bit is 0 or 1 */
						if (CHECK_BITU8(l_ISO9141_14230LinkInit_S.Data[0],(l_BitPos - 1)) != FALSE) {
							
							/* Bit is 1 - Set K Line */
							T_gpio_PIN_set(&GPIO_KW_TX_5BAUD, 1); 
						}
						else {	
							/* Bit is 0 - Reset K Line */
			                               	T_gpio_PIN_set(&GPIO_KW_TX_5BAUD, 0); 
						}
						/* Increment the bit position to transmit the next bit */
						l_BitPos++;

						/* Timer counter reset for set FIVE baud time(200ms) */
						timer_counter = 0;

					}

					/* If MSB is transmitted check for Parity bits */

					/* Check for No Parity */
					else if (l_Parity == NO_PARITY) {

						/* When there is no parity increment the bit position to point to the Stop bit based on the Data Bits */
						if (l_DataBits == EIGHT_BITS) {
							
							/* Increment the bit position to transmit the stop bit */
							l_BitPos = l_BitPos + 1;

						}
						else {
							/* Increment the bit position to transmit the stop bit */
							l_BitPos = l_BitPos + 2;
						}

					}
					/* If Parity is configured then Transmit the Parity bit */
					else {

						/* Based on the Parity configuration determine if the Parity bit is 0 or 1 */
						if (ISO9141_14230_GetParity() != FALSE) {

							/* Parity Bit is 1 - Set K Line */
							T_gpio_PIN_set(&GPIO_KW_TX_5BAUD, 1); 
						}

						else {

							/* Parity Bit is 0 - Reset K Line */
				                        T_gpio_PIN_set(&GPIO_KW_TX_5BAUD, 0); 
						}

						/* After transmission of Parity bit, increment the bit position to point to the Stop bit based on the Data Bits */
						if (l_DataBits == EIGHT_BITS) {

							/* Increment the bit position to transmit the stop bit */
							l_BitPos = l_BitPos + 1;
						}

						else {
							/* Increment the bit position to transmit the stop bit */
							l_BitPos = l_BitPos + 2;
						}

						/* Timer counter reset for set FIVE baud time(200ms) */
						timer_counter = 0;
					}
				}

				/* Should not enter else */
				else {

					/* Do nothing */
				}


				/* Stop bit(this if and else can handle the stop bit check and FIVE baud modes) */

				/* Transmit Stop bit if the Bit position is in the Stop bit position and also check if the Five baud time has elapsed since the transmission of Last bit of address/parity */
				if ((l_BitPos == STOP_BIT_POS) && (TIME_COUNTER_TO_MS >= FIVE_BAUD_TIME)) {

					/* Stop Bit */
			                T_gpio_PIN_set(&GPIO_KW_TX_5BAUD, 1); 

					/* Timer counter reset for set FIVE baud time(200ms) */
					timer_counter = 0;
					 
					/* Increment bit position to indicate no more bits - All bits are sent */
					l_BitPos++;
				}

				/* Perform operations after transmission of Stop bit */
				else if ((l_BitPos == (STOP_BIT_POS + 1)) && (TIME_COUNTER_TO_MS >= FIVE_BAUD_TIME)) {
					
					/* Check if L line was configured. If yes then disable */
					if (CHECK_BITU8(l_ConnectFlags, BIT_LINECONF) == FALSE) {

						/* Disable L line after Initialization ?????? */
				              //  T_gpio_PIN_set(&GPIO_KLINE_LLINE_SLCT, 0); /* we are using only KLINE, Not even configure GPIO_KLINE_LLINE_SLCT.*/
					}
					
					/* reset timer_count */
					KWP_reset_TimeOut();	
					KWP_Set_TimeOut(l_W1, PATTERN_BYTE_WAIT);

					/* Increment bit position */
					l_BitPos++;
					
					/* UART process Enabled */
					l_processData = 1;
				}

				/* Check for Rx bytes from ECU after completion of Stop bit */
				else if (l_BitPos > (STOP_BIT_POS + 1)) {

					/* Buffer length getting update from ECU response */
					l_ISO9141_14230LinkInitRet_S.Length = kwp_buffer_length ;
					
					if (l_ISO9141_14230LinkInitRet_S.Length != 0) {
						/* Check if Length has reached Address byte position - Key bytes received */
						if (l_ISO9141_14230LinkInitRet_S.Length == ADDRESS_BYTE_INV_POS) {
							
							/* Based on the 5 Baud configuration perform operations upon reception of Key bytes */
							if ((l_FiveBaudMod == FIVEBAUD_MODE_ZERO) || (l_FiveBaudMod == FIVEBAUD_MODE_ONE))
							{
								/* In this FIVEBAUD_MODE_ZERO, receive ECU Pattern and Key bytes, Transmit KeyByte inverse and then Receive Address Inverse byte */

								/* In this FIVEBAUD_MODE_ONE, receive ECU Pattern and Key bytes, Transmit KeyByte inverse No reception of Address Inverse byte */

								/* Set the Tx length to indicate Tx byte */
								l_TxLength = 1;

								/* Load Rx timeout W4 before Tx of KB2 inverse */
								/* initially it was l_w4 Since it is not time out Changed the timing limit shud be 25 to 50 ms- if changed to only l_W4 5Baud will not work */
								/* reset timer_count */
								KWP_reset_TimeOut();
								KWP_Set_TimeOut(l_W4 - 19500, INV_KB2_WAIT);
								
								
							}
							else if (l_FiveBaudMod == FIVEBAUD_MODE_TWO)
							{
								/* In this Mode, receive ECU Pattern and Key bytes and receive the Address inverse- No transmission of Key byte 2 inverse */

								/* Clear the Tx length to indicate no Tx byte */
								l_TxLength = 0;

								/* Load Max Rx timeout for Address inverse byte W4 - RETTO */
								
								/* reset timer_count */
								KWP_reset_TimeOut();
								KWP_Set_TimeOut(W4_MAX_TIME, INV_ADDR_WAIT);
							}

							else if (l_FiveBaudMod == FIVEBAUD_MODE_THREE)
							{
								/* In this Mode, receive ECU Pattern and Key bytes - No Tx of Key byte 2 inverse and no Rx of address inverse byte */

								/* Clear the Tx length to indicate no Tx byte */
								l_TxLength = 0;

								/* Clear Rx Length */
								l_RxLength = 0;

								/* Store Protocol Id */
								l_ISO9141_14230LinkInitRet_S.ProtocolId = l_ProtocolId;

								/* Store Init type */
								l_ISO9141_14230LinkInitRet_S.IOCtlId = FIVE_BAUD_INIT;

								/* Store Only Key Bytes - Store the Keybytes at 0th and 1st element of the array and modify length to indicate only Keybytes */
								l_ISO9141_14230LinkInitRet_S.Data[0] = l_ISO9141_14230LinkInitRet_S.Data[1];
								l_ISO9141_14230LinkInitRet_S.Data[1] = l_ISO9141_14230LinkInitRet_S.Data[2];
								l_ISO9141_14230LinkInitRet_S.Length = 2;

								/* Report to the Call Back function */
								App_InitData((void *)&l_ISO9141_14230LinkInitRet_S);

								/* Set the Link Init Status to Done */
								l_InitStatus = LINKINIT_DONE;
								
								/* reset the five baud idle time flag */
							        timer_init_flag = FALSE;

								/* Indicate response bytes received */
								l_MsgReceived = !FALSE;

								/* Load P3 min timeout for minimum time before Data transmission */
								/* reset timer_count */
								KWP_reset_TimeOut();
								KWP_Set_TimeOut(l_P3MIN, P3MIN_WAIT);
							}

							else {

								/* Should not enter else */
							}
							
							/* length reset */
							kwp_buffer_length = 0;	
						}

						/* Check if length has exceeded Address byte position - Address byte inverse received */
						else if (l_ISO9141_14230LinkInitRet_S.Length > ADDRESS_BYTE_INV_POS) {

							/* Store the Address byte inverse after Key bytes */

							/* Based on the 5 Baud configuration perform operations upon reception of Address inverse byte */
							if (l_FiveBaudMod == FIVEBAUD_MODE_ZERO || l_FiveBaudMod == FIVEBAUD_MODE_TWO) {

								/* In this FIVEBAUD_MODE_ZERO, receive ECU Pattern and Key bytes, Transmit KeyByte inverse and then Receive Address Inverse byte */

								/* In this FIVEBAUD_MODE_TWO, receive ECU Pattern and Key bytes and receive the Address inverse - No transmission of Key byte 2 inverse */

								/* Store Protocol Id */
								l_ISO9141_14230LinkInitRet_S.ProtocolId = l_ProtocolId;

								/* Store Init type */
								l_ISO9141_14230LinkInitRet_S.IOCtlId = FIVE_BAUD_INIT;

								/* Store Only Key Bytes - Store the Keybytes at 0th and 1st element of the array and modify length to indicate only Keybytes */
								l_ISO9141_14230LinkInitRet_S.Data[0] = l_ISO9141_14230LinkInitRet_S.Data[1];
								l_ISO9141_14230LinkInitRet_S.Data[1] = l_ISO9141_14230LinkInitRet_S.Data[2];
								l_ISO9141_14230LinkInitRet_S.Length = 2;

								/* Report to the Call Back function */
								App_InitData((void *)&l_ISO9141_14230LinkInitRet_S);

								/* Set the Link Init Status to Done */
								l_InitStatus = LINKINIT_DONE;
								timer_init_flag = FALSE;

								/* Indicate response bytes received */
								l_MsgReceived = !FALSE;

								/* Load P3 min timeout for minimum time before Data transmission */	
								/* reset timer_count */
								KWP_reset_TimeOut();
								KWP_Set_TimeOut(l_P3MIN, P3MIN_WAIT);
								
								/* length reset */
								kwp_buffer_length = 0;
								
							}
							else {
								/* Do nothing */
							}
						}
						else {
							/* do nothing */
						}
					}
					/* Waiting for ECU response to update Length */
					else {
						/* Do nothing */
					}
				}
				else {
					/* Do nothing */
				}
			}
			/* Waiting for Idle time elapse */
			else {
		
			}	
		}

		/* Type of Init - FAST Init */
		else {	

			/* Check if the Bus was idle for TIdle. If idle perform Fast initialization else wait till TIdle */
			if (TIME_COUNTER_TO_MS >= l_TIDLE) {
				timer_init_flag = true;
			}

			if(timer_init_flag == true) {

					/* Generate Wakeup Pattern */
				if (l_BitPos == WKUP_TINIL) {
						
					/* To avoid unwanted UART interupt during Initialisation */
					l_processData = 0;
					data_indx = 1; 
					/* TiniL pattern */
					T_gpio_PIN_set(&GPIO_KW_TX_5BAUD, 0);
						
					/* Timer counter reset for set FAST init time (25ms) */
					timer_counter = 0;

					/* Increment l_BitPos to perform rest of the pattern */
					l_BitPos++;

				}
				else if ((l_BitPos == WKUP_TWUP) && (TIME_COUNTER_TO_MS >= l_TINIL)) {

					/* TWup - TiniL pattern */
					T_gpio_PIN_set(&GPIO_KW_TX_5BAUD, 1);

					/* Increment l_BitPos to indicate end of wakeup pattern */
					l_BitPos++;

				}
				else if (((l_BitPos == WKUP_STARTREQ) && (TIME_COUNTER_TO_MS >= l_TWUP)) || (fastinit_start_comm_req_start_flag == TRUE)){
				
					/* Check if L line was configured. If yes then disable */
					if (CHECK_BITU8(l_ConnectFlags, BIT_LINECONF) == FALSE) {
						
							/* Disable L line after Initialization ?????? */
						//	T_gpio_PIN_set(&GPIO_KLINE_LLINE_SLCT, 0); /* we are using only KLINE, Not even configure GPIO_KLINE_LLINE_SLCT.*/

					}							
					
					/* Send first byte of Fast init request message here, remaining consecutive bytes send at timeout function  */
					if(( loopcontrol == 0)){
						
						/* GARUDA2 implentation */
						/* If P3 min is less than P1max then limit the time to P1max as P1 max is the minimum time to determine the end of frame else load P3min */
						if (l_P3MIN < l_P1MAX) {
							
							/* reset timer_count */
							KWP_reset_TimeOut();
							KWP_Set_TimeOut(l_P1MAX, P1MAX_WAIT);		
						}
						else {
							/* reset timer_count */
							KWP_reset_TimeOut();
							//KWP_Set_TimeOut(l_P3MIN, P3MIN_WAIT);

						}

						l_TxLength = l_ISO9141_14230LinkInit_S.Length;
						
						/* To avoid unwanted UART interupt during Initialisation */
						l_processData = 1;
						
 						/* First byte of data sent */
						uart_send_data(Global_uart_ctx,(char)l_ISO9141_14230LinkInit_S.Data[0]);
                                                KWP_reset_TimeOut();
						/* Minium time gap between two bytes of request message */
                                                KWP_Set_TimeOut((l_P4MIN),(P4MIN_WAIT));

					}
					
					/* flags set for send consective byte  */
					fastinit_start_comm_req_start_flag = TRUE;
					if(fastinit_start_comm_req_end_flag == TRUE)
					{
						/* Send all bytes of fast init request message */ 
						l_BitPos++;
						fastinit_start_comm_req_end_flag   = FALSE;
						fastinit_start_comm_req_start_flag = FALSE;
					}
					/* waiting for send remaining consective request message bytes */ 
					else
					{	
						/* Do nothing */
					}
					loopcontrol = 1;
				
				}	

				else if (l_BitPos > WKUP_STARTREQ) {					

					loopcontrol = 0;
					l_ISO9141_14230LinkInitRet_S.Length = kwp_buffer_length;
					if(l_ISO9141_14230LinkInitRet_S.Length != 0) {
							
						/* Verify checksum if configured */
						if (CHECK_BITU8(l_ConnectFlags,BIT_CHKSUM) == FALSE) {

							/* Obtain the checksum for Init data */
							fl_ChkSum = ISO9141_14230_GetChecksum((void *)l_ISO9141_14230LinkInitRet_S.Data, l_ISO9141_14230LinkInitRet_S.Length, CHKSUM_RXDATA);
							
							/* If Checksum is ok */
							if (fl_ChkSum == CHECKSUM_OK) {

								/* Update length */
								l_ISO9141_14230LinkInitRet_S.Length--;

								/* Remove the checksum byte */
								l_ISO9141_14230LinkInitRet_S.Data [l_ISO9141_14230LinkInitRet_S.Length]= 0;

								/* Set the status of Fast Init */
								l_InitStatus = LINKINIT_DONE;
									
								/*reset init timer flag*/
								timer_init_flag = false;

								/* Store Protocol Id */
								l_ISO9141_14230LinkInitRet_S.ProtocolId = l_ProtocolId;

								/* Store Init type */
								l_ISO9141_14230LinkInitRet_S.IOCtlId = FAST_INIT;

								/* Report to the Call Back function */
								App_InitData((void *)&l_ISO9141_14230LinkInitRet_S);
							}

							/* Report Checksum error */
							else {
								/* Set the status of Fast Init */
								l_InitStatus = LINKINIT_FAIL;
									
								/*reset init timer flag*/
								timer_init_flag = false;
								

								/* Call application error handler */
								App_ErrHandler(l_ProtocolId,ECU_RESPCHKSUM_ERROR);
							}



						}

						/* If no checksum configured */
						else {

							/* Set the status of Fast Init */
							l_InitStatus = LINKINIT_DONE;
								
							/*reset init timer flag*/
							timer_init_flag = false;

							/* Store Protocol Id */
							l_ISO9141_14230LinkInitRet_S.ProtocolId = l_ProtocolId;

							/* Store Init type */
							l_ISO9141_14230LinkInitRet_S.IOCtlId = FAST_INIT;

							/* Report to the Call Back function */
							App_InitData((void *)&l_ISO9141_14230LinkInitRet_S);

						}	
						kwp_buffer_length = 0;               // doubt, not sure.
					}
					/* Waiting for ECU response for request message */
					else {
						/* Do nothing */
					}
				}
				else {
					/* Do nothing */
				}
			}
			/* Waiting for Idle time Elapse */
			else {
	
			}
		}
	}
	/*l_InitStatus is not PENDING */
	else {
		timer_counter++;
	}

	/* check TimeOut periodically */
	KWP_TimeOut_handle();
	
	/*check RxTask periodically*/
	ISO9141_14230_RxTask();

	/* check response sent periodically */
	PassThruReadMsgResp_KWP ();	

	/*check TxTask periodically*/
	ISO9141_14230_TxTask();

}

/************************************************************************************************************
 Function name             : KWP_uart_rx_callback()
 Function Parameters type  : GIOChannel, GIOCondition, gpointer
 Short Description         : Function handles UART RX interrupt call back
			     Glib invokes the KWP_uart_rx_callback when RX triggered
 Return                    : True
*************************************************************************************************************/
gboolean KWP_uart_rx_callback(GIOChannel *source, GIOCondition condition, gpointer data)
{

	if(condition & G_IO_IN)
	{

		uint16_t fl_Cnt;
		uint32_t fl_CurrTime;
		uint8_t fl_UARTRxByte, fl_TxByte ;
		gchar l_buffer_recev = 0;


		/* UART_Receive */		
		gsize read_byte;
		GError *error = NULL;
		

		GIOStatus status ;
		status = g_io_channel_read_chars(source, &l_buffer_recev ,1, &read_byte,&error);


		if(l_processData == 0)
		{	
			return;
		}
		if(error)
		{
			//g_print("Error");
			return;
		}


		if(status == G_IO_STATUS_NORMAL && read_byte > 0  )
		{
			/*Byte read*/
			/*copy the data to necessary buffer*/
				
		}
	
		/* check if the UART Rx Interrupt due to loop back of TX data */

		/* If l_TxLength non zero then byte obtained is the byte transmitted */
		if (l_TxLength != 0) {
			
			/* Determine the Tx byte from the type of Tx data */

			/* Check if Init Tx Data */
			if (l_InitStatus == LINKINIT_PENDING) {

				/* Determine the type of Init */

				/* FIVE Baud Init */
				if (l_ISO9141_14230LinkInit_S.InitType == FIVE_BAUD_INIT) {

					/* Tx byte of Five baud Keybyte_2 inverse byte */
					fl_TxByte = l_ISO9141_14230LinkInitRet_S.Data[2] ^ 0xFF;
				}
				/* Fast Init  */
				else {
					/* Tx byte of Fast init request message */
					fl_TxByte = l_ISO9141_14230LinkInit_S.Data [l_UARTIntrTxIndex];
				}
			}

			/* Normal Tx data byte */
			else {
				buffer_type = ISO9141_14230_TX_Q;
				fl_TxByte   = ISO9141_14230_TxMsg_S_Buffer.Data[l_UARTIntrTxIndex];
			}


			/* Check for Corruption on the bus */

			/* Compare Received byte with Transmitted byte */
			fl_UARTRxByte = (uint8_t)l_buffer_recev;
			
			/* Tx data byte corrupted */
			if (fl_UARTRxByte != fl_TxByte) {
	
				/* Corruption on the Bus */
				/* Abort Transmission - Flush buffers */

				/* Call application error handler */
				App_ErrHandler(l_ProtocolId, MSG_CORRUPTED); 

				/* If Tx byte is from Initialization set status to failure */
				if (l_InitStatus == LINKINIT_PENDING) {
					
	 				l_InitStatus = LINKINIT_FAIL;
					timer_init_flag = false ;
				}

				/* reset timer_count */
				KWP_reset_TimeOut();
					
				/* Reset Lengths */
				l_UARTIntrTxIndex = 0;
				l_TxLength = 0;

				/* Indicate TxComp */
				l_TxComp = !FALSE;
				l_P3MINTimeout = !FALSE;
			}

			/* Tx data bytes not corrupted */
			else {
				
				/* Increment the Tx length to check next byte */
				l_UARTIntrTxIndex++;

				/* Check if Last byte is received */
				if (l_UARTIntrTxIndex == l_TxLength) {
				
					/* Configure Rx Timeout - Only when not in Initialisation phase */
					if (l_InitStatus != LINKINIT_PENDING) {

						/* Load the timeout of P2MAX (Time gap between one request to response) */
						KWP_reset_TimeOut();
						KWP_Set_TimeOut(P2_MAX_TIME,P2_MAX_TIME_WAIT);//gowtham

						/* Update the P3min Timeout indication in order to wait for time P3min before next Txn */
						/* Once P3min timeout elapsed then make it l_P3MINTimeout true */
						l_P3MINTimeout = FALSE;

						/* Initialize Message received status */
						/* Once all response message bytes received then make it l_MsgReceived true */ 
						l_MsgReceived = FALSE;
	

					}

					/* For Five Baud Mode 1 indicate Init Done */
					else if ((l_InitStatus == LINKINIT_PENDING) && (l_ISO9141_14230LinkInit_S.InitType == FIVE_BAUD_INIT) && (l_FiveBaudMod == FIVEBAUD_MODE_ONE)) {

						/* In this Mode, receive ECU Pattern and Key bytes, Transmit KeyByte inverse No reception of Address Inverse byte */

						/* Set the Link Init Status to Done */
						l_InitStatus = LINKINIT_DONE;
  							
  						/* reset the five baud idle time flag */
						timer_init_flag = false; 
							
						/* Store Protocol Id */
						l_ISO9141_14230LinkInitRet_S.ProtocolId = l_ProtocolId;

						/* Store Init type */
						l_ISO9141_14230LinkInitRet_S.IOCtlId = FIVE_BAUD_INIT;

						/* Store Only Key Bytes - Store the Keybytes at 0th and 1st element of the array and modify length to indicate only Keybytes */
						l_ISO9141_14230LinkInitRet_S.Data[0] = l_ISO9141_14230LinkInitRet_S.Data[1];
						l_ISO9141_14230LinkInitRet_S.Data[1] = l_ISO9141_14230LinkInitRet_S.Data[2];
						l_ISO9141_14230LinkInitRet_S.Length = 2;

						/* Report Link init done to the Call Back function */
						App_InitData((void *) &l_ISO9141_14230LinkInitRet_S); 
						
						/* Indication of Message received status */
						l_MsgReceived = !FALSE;

						/* Load P3 min timeout for minimum time before Data transmission */
						
						/* reset timer_count */
						KWP_reset_TimeOut();
						KWP_Set_TimeOut(l_P3MIN, P3MIN_WAIT);  
							
						l_P3MINTimeout = FALSE; // doubt
					}

					/*Fast Init */
					else if ((l_InitStatus == LINKINIT_PENDING) && (l_ISO9141_14230LinkInit_S.InitType == FAST_INIT)){
						
                                                /* Load the timeout of P2MAX (Time gap between one request to response) for receiving ECU response  */
						KWP_reset_TimeOut();
						KWP_Set_TimeOut(P2_MAX_TIME,P2_MAX_TIME_WAIT);
					}
					else {
						/* No operation */
						l_TxComp = l_TxComp;
					}

					/* Last Tx byte received - Reset Lengths */
					l_UARTIntrTxIndex = 0;
					l_TxLength = 0;

					/* Indicate Tx Completion */
					l_TxComp = !FALSE;
					
				}

				/* Waiting for Last byte of TX received */
				else {
					/* No operation */
				}
				
			}
		}

                /* Check if the UART RX interrupt is due to Request message response */
		else {
			/* Check if the RX (ECU Response) for Initialisation phase  */
			if (l_InitStatus == LINKINIT_PENDING) {

				/* RX (ECU Response) for Initialisation phase - FIVE baud */
				if (l_ISO9141_14230LinkInit_S.InitType == FIVE_BAUD_INIT) {

					/* Determine the byte received - Load corresponding timeouts */
					if (l_RxLength == PATTERN_BYTE_POS) {
							
						l_ISO9141_14230LinkInitRet_S.Data[l_RxLength] = (uint8_t)l_buffer_recev;
							
						/* Received the pattern byte - Increment the length */
						l_RxLength++;

						/* Load the Receive timeout W2 - RETTO */
						/* reset timer_count */
						KWP_reset_TimeOut();
						KWP_Set_TimeOut(l_W2,KB1_WAIT);
	
					}
					else if (l_RxLength == KEY_BYTE1_POS) {

						l_ISO9141_14230LinkInitRet_S.Data[l_RxLength] = (uint8_t) l_buffer_recev;
						
						/* Received the Key byte 1 - Increment the length */
						l_RxLength++;

						/* Load the Receive timeout W3 - RETTO */
						/* reset timer_count */
						KWP_reset_TimeOut();
							
						KWP_Set_TimeOut(l_W3, KB2_WAIT);        
							
					}
					else if (l_RxLength == KEY_BYTE2_POS) {

						l_ISO9141_14230LinkInitRet_S.Data[l_RxLength] = (uint8_t) l_buffer_recev;

						/* Received the Key byte 2 - Increment the length */
						l_RxLength++;

						/* adding length in buffer */
						kwp_buffer_length = l_RxLength;
														
						/* reset timer_count */
						KWP_reset_TimeOut();                                   
							
					}
					else if (l_RxLength == ADDRESS_BYTE_INV_POS) {

						l_ISO9141_14230LinkInitRet_S.Data[l_RxLength] = (uint8_t) l_buffer_recev;
							
						/* Received the Address byte inverse - Increment the length */
						l_RxLength++;
							
						/* adding length in buffer */
						kwp_buffer_length = l_RxLength;

						/* Reset Rx Length */
						l_RxLength = 0;
							
						/* reset timer_count */
						KWP_reset_TimeOut();                             
					}
					else {
						/* Do nothing */
					}
				}

				/* RX (ECU Response) for Initialisation phase - FAST Init */
				else {
					/* If First byte received */
					if (l_RxLength == 0) {
						
						/* reset timer_count */
						KWP_reset_TimeOut();	
						KWP_Set_TimeOut(l_P1MAX, P1MAX_WAIT);  


						/* Call back function */
						/* RA Consultant recomended code */
						//App_FirstByteRxd(l_ProtocolId,fl_CurrTime);  //Gowtham

						/* Initialize Message received status */
						l_MsgReceived = FALSE;
					}
					
					l_ISO9141_14230LinkInitRet_S.Data[l_RxLength] = (uint8_t) l_buffer_recev;
					
					/* Received ECU response byte - Increment length */
					l_RxLength++;

				}
			}

			/* Check if the RX (ECU Response) interrupt for Tester request */
			else if ((l_InitStatus == LINKINIT_DONE) || (l_InitStatus == NO_LINKINIT) || (l_InitStatus == LINKINIT_FAIL)) {

				/* If First byte received */
				if (l_RxLength == 0) {
						
					/* Received first response byte so Reset P2 Max time */
					KWP_reset_TimeOut();
						
					l_LengthByte = 0;
					l_PktLength = 0;
						
					/* clear ISO9141_14230_RxMsg_S_Buffer structure */
					memset((void*)&ISO9141_14230_RxMsg_S_Buffer,0,sizeof(ISO9141_14230_RxMsg_S_Buffer));
						
					if(KWP_PROTOCOL_ID == l_ProtocolId ) {
						
						/* Get Response data packet length */
						l_PktLength = ISO9141_14230_Get_Data_Length(l_buffer_recev, &l_LengthByte);
					}		

					/* First byt received indication */
					/* Call back function */
					App_FirstByteRxd(l_ProtocolId,fl_CurrTime);  

					/* Initialize Message received status */
					l_MsgReceived = FALSE;

				}
				else if (l_RxLength == l_LengthByte) {
					
					if (KWP_PROTOCOL_ID == l_ProtocolId) {

						/* Get Response data packet length */
						l_PktLength = ISO9141_14230_Get_Data_Length(l_buffer_recev, &l_LengthByte);
					}
				}

				else {
					//Do nothing    
				}

				/* Received ECU response byte - Increment length */	

				/* store Rx data in RxMsg_s Buffer */
				ISO9141_14230_RxMsg_S_Buffer.Data[l_RxLength] = (uint8_t) l_buffer_recev;
					
				l_RxLength++;
					
				/* reset timer_count */
				KWP_reset_TimeOut();
					
				/* set P1 MAX for every byte receiving from ECU */
				KWP_Set_TimeOut(l_P1MAX,P1MAX_WAIT); 
					
					
				if (l_RxLength == l_PktLength) {

					/* reset timer_count */
					KWP_reset_TimeOut();  

						/* Complete packet received */
						/* Any byte not received it can Handled at timeout functionalities */
						l_PktLength = 0;
			
						/* adding length in buffer */
						kwp_buffer_length = l_RxLength;
						
						/* Rx message fully received flag for RX task() */
						kwp_RxMsg_received = !FALSE ;
						
						/* adding length to RxMsg_s Buffer */
						ISO9141_14230_RxMsg_S_Buffer.Length = l_RxLength;
						
						/* Reset Rx Length */
						l_RxLength = 0;

						/* Indicate Message received */
						l_MsgReceived = !FALSE;

						/* Check P3min to load additional timeout starting from P1max */
						/* If P3 min is less than P1max then next Tx could be started immediately else wait for P3min - P1max */
						if (l_P3MIN < l_P1MAX) {

							/* Update the status of P3min timeout */
							l_P3MINTimeout = !FALSE;
	                         
	                         			/* reset timer_count */
							KWP_reset_TimeOut();
						}
						else {  
 						        /*   below commands mentioned in Garuda_2 */
							/* - This was an Error which we had face in REVA for Diagnostic Tester Application
							   - We had Changed the implementation of KWP Packet handling based on the Length.
							   - So we were not maintaining the delay of 55 mses for response to request (P3_Min) timeout.
							   - We shouldn't subtract the l_P1MAX timeout from l_P3MIN, (55-20) = 35 msecs delay, which is wrong. 
							 */
	
							/* reset timer_count */
							KWP_reset_TimeOut();
							KWP_Set_TimeOut(l_P3MIN,P3MIN_WAIT);
							
							
						}
				
				}
			}

			/* If there is Link Init failure */
			else {
				/* Do nothing */
			}
		} 
		

	}

	/*If there is UART failure */
	else {
		/* Do nothing */
	}		
					
	return TRUE;
}

/************************************************************************************************************
 Function name             : uart_send_data()
 Function Parameters type  : UARTContext, char
 Short Description         : Function handles UART Write for byte by byte
 Return                    : void
*************************************************************************************************************/

static void uart_send_data(UARTContext *ctx, char data)
{
	gsize byte_written;
	GError *error = NULL;
	int ret;
	if(ctx->channel != NULL)
	{
		g_io_channel_write_chars(ctx->channel , &data, 1, &byte_written , &error);
		g_io_channel_flush(ctx->channel, &error);
		if(error)
		{
			g_print("UART Write Error\n");
		}
		else
		{
			/* UART Write success */
		}

	}
	else
	{

	}
	
}

/************************************************************************************************************
 Function name             : uart_send_dataarray()
 Function Parameters type  : UARTContext, char* ,int 
 Short Description         : Function handles UART Write for array of data
 Return                    : void
*************************************************************************************************************/

static void uart_send_dataarray(UARTContext *ctx, char *data, int size)
{
	gsize byte_written;
       	GError *error = NULL;
       	int ret;
        if(ctx->channel != NULL)
        {

                g_io_channel_write_chars(ctx->channel , data, size, &byte_written , &error);
                g_io_channel_flush(ctx->channel, &error);
                if(error)
                {
                        g_print("UART Write Error\n");
                }
                else
                {
			/* UART write success */
                }


        }
        else
        {

        }

}
/************************************************************************************************************
 Function name             : on_timerfd_ready()
 Function Parameters type  : GIOChannel*, GIOCondition, gpointer 
 Short Description         : This function calls the every 1ms sec of Fd timer 
 Return                    : gboolean
************************************************************************************************************/
static gboolean on_timerfd_ready(GIOChannel *source, GIOCondition cond, gpointer user_data) {
	int tfd = g_io_channel_unix_get_fd(source);
	uint64_t expirations = 0;
	static uint64_t iter;
	ssize_t r = read(tfd, &expirations, sizeof(expirations));
	if (r < 0) {
		if (errno == EINTR || errno == EAGAIN) return TRUE;
		g_warning("read(timerfd) failed: %s", g_strerror(errno));
		return TRUE;
	}

  	/* catch up on all missed expirations */
	for (iter = 0; iter < expirations; iter++) {
		KWP_Timer_Handler();
	}

    return TRUE; // keep the watch active
}

/************************************************************************************************************
 Function name             : kwp_init()
 Function Parameters type  : void 
 Short Description         : This function handles the fd timer and UART and GPIO init 
 Return                    : gboolean
************************************************************************************************************/
int kwp_init(void)
{
	
	const char *uart_dev = "/dev/ttyS2"; 
	struct termios options;

	int tfd = timerfd_create(CLOCK_MONOTONIC, TFD_CLOEXEC | TFD_NONBLOCK);
	if (tfd < 0) { perror("timerfd_create"); return 1; }

	// Arm a 1ms periodic timer
	struct itimerspec its = {0};
	its.it_value.tv_sec = 0; its.it_value.tv_nsec = 1000000;   // first in 1ms
	its.it_interval = its.it_value;                            // periodic 1ms
	timerfd_settime(tfd, 0, &its, NULL);

	fd = open(uart_dev, O_RDWR);
	if (fd < 0) {
        	perror("UART open failed");
        	return 1;
	
	}


	ioctl(fd,ATMEL_IOCTL_RAW_mode,NULL);


	close(fd);

	fd = open(uart_dev, O_RDWR);
        if (fd < 0) {
                perror("UART open failed");
                return 1;

        }


        ioctl(fd,ATMEL_IOCTL_RAW_mode,NULL);

	/* configure uart */
/* 
	if(tcgetattr(fd, &options) != 0)
	{
		perror("UART GET ATTR failed");
		return 1;
	}


	options.c_iflag = 0;
	options.c_oflag = 0;
	options.c_lflag = 0;
	options.c_cflag = 0;

	options.c_cflag |= (CLOCAL | CREAD);
	options.c_iflag &= ~(IXON | IXOFF | IXANY);

	options.c_cflag &= ~(CSIZE | PARENB | CSTOPB | CRTSCTS);
	options.c_cflag |= (CS8 | CREAD | CLOCAL);

	 options.c_cc[VTIME] = 1; // read timeout 10*100ms
	 options.c_cc[VMIN] = 0;

	 cfsetispeed(&options, B115200);
	 cfsetospeed(&options, B115200);

	 tcflush(fd, TCIFLUSH);
	 if(tcsetattr(fd, TCSANOW, &options) !=0)
	 {
	 	perror("UART SET ATTR failed");
		return 1;
	 }

*/

	// Configure UART (termios setup omitted for brevity)
	
	channel = g_io_channel_unix_new(fd);
	g_io_channel_set_encoding(channel, NULL, NULL); // Binary mode
	g_io_channel_set_flags(channel,  G_IO_FLAG_NONBLOCK, NULL);
	
        g_io_channel_set_buffered(channel, FALSE);              // <- important
        g_io_channel_set_close_on_unref(channel, TRUE);	
	Global_uart_ctx = g_new(UARTContext ,1);
	Global_uart_ctx->channel = channel;

	KWP_watch_id = g_io_add_watch(channel, G_IO_IN | G_IO_HUP | G_IO_ERR | G_IO_PRI | G_IO_NVAL, KWP_uart_rx_callback, Global_uart_ctx);

	ch = g_io_channel_unix_new(tfd);
	g_io_add_watch(ch, G_IO_IN, on_timerfd_ready, NULL);
	
	
	/* Configure GPIO  */

        GPIO_KW_TX_5BAUD.gpio_number = 34;
        GPIO_KW_TX_5BAUD.direction = GPIO_DIRECTION_OUT;


        GPIO_KLINE_ISO_SLCT.gpio_number = 32;
        GPIO_KLINE_ISO_SLCT.direction = GPIO_DIRECTION_OUT;

        /* Configure GPIOs as O/P */

        T_gpio_PIN_config(&GPIO_KW_TX_5BAUD);

        T_gpio_PIN_set(&GPIO_KW_TX_5BAUD, 1);
        T_gpio_PIN_config(&GPIO_KLINE_ISO_SLCT);



        T_gpio_PIN_set(&GPIO_KLINE_ISO_SLCT, 1);



	return 0;
	
}

/************************************************************************************************************
 Function name             : kwp_deinit()
 Function Parameters type  : void 
 Short Description         : This function handles the deinitialisation of KWP
 Return                    : gboolean
************************************************************************************************************/
int kwp_deinit(void)
{
	g_source_remove(KWP_timeout_id);
	g_source_remove(KWP_watch_id);
	g_io_channel_unref(channel);
	return 0;
}

/************************************************************************************************************
 Function name             : ISO9141_14230_GetChecksum()
 Function Parameters type  : const uint8_t, uint16_t, uint8_t
 Short Description         : This function handles the checksum for TX and RX
 Return                    : uint8_t 
************************************************************************************************************/
static uint8_t ISO9141_14230_GetChecksum(const uint8_t * p_Data, uint16_t p_Length, uint8_t p_TxRx)
{
	uint8_t fl_Ret = 0;
	uint16_t fl_Cnt = 0;

	/* Calculate the checksum by adding all the bytes till Length - 1 */
	for (fl_Cnt = 0; fl_Cnt < (p_Length - 1); fl_Cnt++) {

		/* Add the bytes */
		fl_Ret = fl_Ret + p_Data[fl_Cnt];
	}

	/* Based on Tx or Rx data determine or verify the checksum respectively */
	if (p_TxRx == CHKSUM_TXDATA) {

		/* For Tx data calculate checksum - Add the last byte as well */
		fl_Ret = fl_Ret + p_Data[p_Length - 1];
	}

	else {

		/* For Rx data verify checksum - Compare with the last byte */
		if (fl_Ret == p_Data[p_Length - 1]) {

			/* For Rx data return 0 if there is no checksum error */
			fl_Ret = CHECKSUM_OK;
		}

		else {

			/* For Rx data return 1 if there is checksum error */
			fl_Ret = CHECKSUM_ERROR;
		}
	}

	/* Return checksum or checksum verification status */
	return fl_Ret;
}

/************************************************************************************************************
 Function name             : ISO9141_14230_Init()
 Function Parameters type  : const ISO9141_14230_Init_S
 Short Description         : This function handles the global variable init and timer value init 
 Return                    : void
************************************************************************************************************/
void ISO9141_14230_Init(const ISO9141_14230_Init_S * p_ISO9141_14230Init_S)
{
	/* UART structure */

	/* Queue variables */

	/* IOCTL_Return status variables */
	int Ioctl_Baud_Ret_status = 0;
	int Ioctl_Parity_Ret_status = 0;
	
	
	/* Save all the default values to ISO 9141 / 14230 parameters */
	l_ProtocolId = p_ISO9141_14230Init_S->ProtocolId;
	l_BaudRate = p_ISO9141_14230Init_S->Baudrate;
	l_ConnectFlags = 0;
	l_Parity = NO_PARITY;
	l_DataBits = EIGHT_BITS;
	l_P1MAX = 20000;
	l_P3MIN = 55000;// gowtham 
			/* P3 min is assumed to be used as T4 in case
				   of ISO 9141. T4 specifies the minimum
				   time for diag data request after
				   initialization */
	l_P4MIN = 5000 ;  // gowtham 5000;
	l_W0 = 300000;
	l_W1 = 300000;
	l_W2 = 20000;
	l_W3 = 20000;
	l_W4 = 49500;		/* Minimum Time of 50ms is not possible
				   because of the delay in trasnmission
				   and the max time being 50ms as well */
	l_W5 = 300000;
	l_TIDLE = 300000;
	l_TINIL = 25000; 
	l_TWUP = 50000;  
	l_FiveBaudMod = FIVEBAUD_MODE_ZERO;
	l_BitPos = 0;
	l_RxLength = 0;
	l_TxLength = 0;
	l_TxIndex = 0;
	l_UARTIntrTxIndex = 0;
	l_P3MINTimeout = !FALSE;


	/* Bit code the Connect flags specific to ISO 9141 / 14230 */

	/* K Line only flag */
	if (CHECK_BITU32(p_ISO9141_14230Init_S->Flags,ISO9141_K_LINE_ONLY_BIT_POS) != FALSE) {

		/* Bit 0 */
		SET_BITU8(l_ConnectFlags, BIT_LINECONF);
	}

	/* Checksum flag:to ensure that the correct data is received and that the ECU is not damaged by corrupted messages. */
	if (CHECK_BITU32 (p_ISO9141_14230Init_S->Flags,ISO9141_NO_CHECKSUM_BIT_POS) != FALSE) {

		/* Bit 1 */
		SET_BITU8(l_ConnectFlags, BIT_CHKSUM);
	}


	Ioctl_Baud_Ret_status   = Set_Baudrate(l_BaudRate);
	Ioctl_Parity_Ret_status = Set_Parity(PARITY_DISABLE);


	l_processData = 1;

	/* Update the Init Link status */
	l_InitStatus = NO_LINKINIT;

	
}
/************************************************************************************************************
 Function name             : ISO9141_14230_Command()
 Function Parameters type  : ISO9141_14230_Cmd_S
 Short Description         : This function handles the IOCTL commands 
 Return                    : ISO9141_14230_RETCODE
************************************************************************************************************/
ISO9141_14230_RETCODE ISO9141_14230_Command(ISO9141_14230_Cmd_S * p_ISO9141_14230Cmd_SP)
{
	ISO9141_14230_RETCODE fl_RetCode = NO_ERROR;
	uint8_t fl_ChkSum = CHECKSUM_OK;

	/* IOCTL_Return status variables */
	int Ioctl_Baud_Ret_status = 0;
	int Ioctl_Parity_Ret_status = 0;
	

	/* Switch to the appropriate Command based on the IOCtl Id */
	/* All P and W time parameters are in us with resolution applied */

	switch (p_ISO9141_14230Cmd_SP->IOCtlId) {

	case GET_CONFIG:		/* Get Config */

		switch (p_ISO9141_14230Cmd_SP->ParamId) {
		
		case DATA_RATE:
				/* Obtain the Baud rate and load it onto the command data location */
				*(p_ISO9141_14230Cmd_SP->pData) = l_BaudRate;
				break;
		case LOOPBACK:
				*(p_ISO9141_14230Cmd_SP->pData) = l_loopback;
				break;
		case P1_MAX:
				/* Obtain P1 max and load it onto the command data location */
				*(p_ISO9141_14230Cmd_SP->pData) =
				    (uint32_t) l_P1MAX / 500;
				
				break;
		case P3_MIN:
				/* Obtain P3 min and load it onto the command data location */
				*p_ISO9141_14230Cmd_SP->pData = l_P3MIN / 500;
				break;
		case P4_MIN:
				/* Obtain P4 min and load it onto the command data location */
				*p_ISO9141_14230Cmd_SP->pData = l_P4MIN / 500;
				break;
		case W0:
				/* Obtain W0 and load it onto the command data location */
				*p_ISO9141_14230Cmd_SP->pData = l_W0 / 1000;
				break;
		case W1:
				/* Obtain W1 and load it onto the command data location */
				*p_ISO9141_14230Cmd_SP->pData = l_W1 / 1000;
				break;
		case W2:
				/* Obtain W2 and load it onto the command data location */
				*p_ISO9141_14230Cmd_SP->pData = l_W2 / 1000;
				break;
		case W3:
				/* Obtain W3 and load it onto the command data location */
				*p_ISO9141_14230Cmd_SP->pData = l_W3 / 1000;
				break;
		case W4:
				/* Obtain W4 and load it onto the command data location */
				*p_ISO9141_14230Cmd_SP->pData = l_W4 / 1000;
				break;
		case W5:
				/* Obtain W5 and load it onto the command data location */
				*p_ISO9141_14230Cmd_SP->pData = l_W5 / 1000;
				break;
		case TIDLE:
				/* Obtain TIDLE and load it onto the command data location */
				*p_ISO9141_14230Cmd_SP->pData = l_TIDLE / 1000;
				break;
		case TINIL:
				/* Obtain TINIL and load it onto the command data location */
				*p_ISO9141_14230Cmd_SP->pData = l_TINIL / 1000;
				break;
		case TWUP:
				/* Obtain TWUP and load it onto the command data location */
				*p_ISO9141_14230Cmd_SP->pData = l_TWUP / 1000;
				break;
		case PARITY:
				/* Obtain the Parity and load it onto the command data location */
				*p_ISO9141_14230Cmd_SP->pData = l_Parity;
				break;
		case DATA_BITS:
				/* Obtain the Data Bits and load it onto the command data location */
				if (l_DataBits == EIGHT_BITS) {
					*p_ISO9141_14230Cmd_SP->pData = 0;
				}

				else {
					*p_ISO9141_14230Cmd_SP->pData = 1;
				}
				break;
		case FIVE_BAUD_MOD:
				/* Obtain the Five Baud Mode and load it onto the command data location */
				*p_ISO9141_14230Cmd_SP->pData = l_FiveBaudMod;
				break;
		default:
				/* Invalid Param Id */
				fl_RetCode = INVALID_PARAMETERID;
				break;
		}
		break;

	case SET_CONFIG:	/* Set Config */

		switch (p_ISO9141_14230Cmd_SP->ParamId) {
		case DATA_RATE:

				/* Set the Baud rate */
				l_BaudRate = *p_ISO9141_14230Cmd_SP->pData;

				/* Clear temporary Tx and Rx variable */
				

				/* Clear Intermediate Rx byte length ????? */
				l_RxLength = 0;

				/* Clear Tx length ????? */
				l_TxLength = 0;
				l_MsgReceived = FALSE;
				l_P3MINTimeout = !FALSE;
				l_TxComp = FALSE;

				/* Configure UART baud rate */


				Ioctl_Baud_Ret_status = Set_Baudrate(l_BaudRate);
				
				break;
		case LOOPBACK:
				l_loopback = *(p_ISO9141_14230Cmd_SP->pData);
				break;
		case P1_MAX:
				
				/* Set P1 max */
				l_P1MAX = *p_ISO9141_14230Cmd_SP->pData * 500;

				break;
		case P3_MIN:
				/* Set P3 min */
				l_P3MIN = *p_ISO9141_14230Cmd_SP->pData * 500;
				break;
		case P4_MIN:
				/* Set P4 min */
				l_P4MIN = 0;	/* To Increase Flashing Speed */

				/*l_P4MIN = *p_ISO9141_14230Cmd_SP->pData * 2000;*/
				break;
		case W0:
				/* Set W0 */
				l_W0 = *p_ISO9141_14230Cmd_SP->pData * 1000;
				break;
		case W1:
				/* Set W1 */
				l_W1 = *p_ISO9141_14230Cmd_SP->pData * 1000;
				break;
		case W2:
				/* Set W2 */
				l_W2 = *p_ISO9141_14230Cmd_SP->pData * 1000;
				break;
		case W3:
				/* Set W3 */
				l_W3 = *p_ISO9141_14230Cmd_SP->pData * 1000;
				break;
		case W4:
				/* Set W4 */
				l_W4 = *p_ISO9141_14230Cmd_SP->pData * 1000;
				break;
		case W5:
				/* Set W5 */
				l_W5 = *p_ISO9141_14230Cmd_SP->pData * 1000;
				break;
		case TIDLE:
				/* Set TIDLE */
				l_TIDLE = *p_ISO9141_14230Cmd_SP->pData * 1000;
				break;
		case TINIL:
				/* Set TINIL */
				l_TINIL = *p_ISO9141_14230Cmd_SP->pData * 1000;
				break;
		case TWUP:
				/* Set TWUP */
				l_TWUP = *p_ISO9141_14230Cmd_SP->pData * 1000;
				break;
		case PARITY:
				/* Set Parity */
				l_Parity = *p_ISO9141_14230Cmd_SP->pData;

				/* Clear intermediate frame bytes if any */
				l_UARTIntrTxIndex = 0;

				/* Clear Intermediate Rx byte length ???? */
				l_RxLength = 0;

				/* Clear Tx length ???? */
				l_TxLength = 0;
				l_MsgReceived = FALSE;

				//l_P3MINTimeout = !FALSE;
				l_TxComp = FALSE;

				/* Configure UART Parity */
				
				if (l_Parity == ODD_PARITY) {
				
					Ioctl_Parity_Ret_status = Set_Parity(PARITY_ODD);
				}
				else if (l_Parity == EVEN_PARITY) {
				
					Ioctl_Parity_Ret_status = Set_Parity(PARITY_EVEN);
				}
				else {
				
					Ioctl_Parity_Ret_status = Set_Parity(PARITY_DISABLE);
				}
				break;
		case DATA_BITS:
				/* Clear temporary Tx and Rx variable */
	
				break;
		case FIVE_BAUD_MOD:
				/* Set Five Baud mode */
				l_FiveBaudMod = *p_ISO9141_14230Cmd_SP->pData;
				break;
		default:

				/* Invalid Param Id */
				fl_RetCode = INVALID_PARAMETERID;
		}
		break;

	case FIVE_BAUD_INIT:
	case FAST_INIT:	/* Link Initialization - FIVE_BAUD_INIT or FAST_INIT */

		/* Load the init information from the Cmd structure to the Link
		   init structure */

		/* Update the Init type */
		l_ISO9141_14230LinkInit_S.InitType = p_ISO9141_14230Cmd_SP->IOCtlId;

		/* Update init data Length */
		l_ISO9141_14230LinkInit_S.Length = p_ISO9141_14230Cmd_SP->Length;

		/* Update the Init Data  */
		memcpy((void *)&l_ISO9141_14230LinkInit_S.Data, (uint8_t *) p_ISO9141_14230Cmd_SP->pData,sizeof(uint8_t) * l_ISO9141_14230LinkInit_S.Length);

		
		/* Update checksum if configured */
		if ((CHECK_BITU8(l_ConnectFlags, BIT_CHKSUM) == FALSE) && (l_ISO9141_14230LinkInit_S.InitType == FAST_INIT)) {

			/* Obtain the checksum for Init data */
			
			fl_ChkSum = ISO9141_14230_GetChecksum((void *) l_ISO9141_14230LinkInit_S.Data, l_ISO9141_14230LinkInit_S.Length, CHKSUM_TXDATA);

			/* Store the checksum as the last byte */
			l_ISO9141_14230LinkInit_S.Data  [l_ISO9141_14230LinkInit_S.Length] = fl_ChkSum;

			/* Update the length for the checksum */
			l_ISO9141_14230LinkInit_S.Length++;
		}
		

		/* Call the init function to perform the initialization of the  communication link */
		ISO9141_14230_LinkInit();	//To initialize communication link parameters for 5 Baud / Fast Init in Linux, we can use the stty command in the terminal.
		break;
	
	case CLEAR_TX_BUFFER:	/* Clear Tx Buffers */

		/* Set Length to 0 */
		p_ISO9141_14230Cmd_SP->Length = 0;

		/* Clear all Tx Queues and Structures */
		memset((void *)&ISO9141_14230_TxMsg_S_Buffer, 0, sizeof(ISO9141_14230_TxMsg_S));
		
		/* Clear intermediate frame bytes if any */
		l_UARTIntrTxIndex = 0;

		l_TxComp = FALSE;

		/* Clear Intermediate Rx byte length */
		l_RxLength = 0;

		/* Clear Tx length */
		l_TxLength = 0;

		/* Clear Tx Index */
		l_TxIndex = 0;


		break;
	case CLEAR_RX_BUFFER:	/* Clear Rx Buffers */
		/* Set Length to 0 */
		p_ISO9141_14230Cmd_SP->Length = 0;

		/* Clear Reception Queue */
		memset((void *)&ISO9141_14230_RxMsg_S_Buffer, 0, sizeof(ISO9141_14230_RxMsg_S));

		/* Clear intermediate frame bytes if any */
		l_UARTIntrTxIndex = 0;

		/* Clear Intermediate Rx byte length */
		l_RxLength = 0;

		/* Clear Tx length */
		l_TxLength = 0;
		

		break;
	
	default:
		/* Invalid command id */
		fl_RetCode = INVALID_COMMAND;
	}

	return fl_RetCode;
}
/************************************************************************************************************
 Function name             : ISO9141_14230_Command_init()
 Function Parameters type  : ISO9141_14230_Cmd_init_S
 Short Description         : This function handles the Five baud and Fast init IOCTL command 
 Return                    : ISO9141_14230_RETCODE
************************************************************************************************************/
ISO9141_14230_RETCODE ISO9141_14230_Command_init(ISO9141_14230_Cmd_init_S * p_ISO9141_14230Cmd_init_SP)
{
	ISO9141_14230_RETCODE fl_RetCode = NO_ERROR;
	uint8_t fl_ChkSum = CHECKSUM_OK;
	
	
	if((p_ISO9141_14230Cmd_init_SP->IOCtlId == FIVE_BAUD_INIT ) || (p_ISO9141_14230Cmd_init_SP->IOCtlId == FAST_INIT ) )
	{
	
		l_ISO9141_14230LinkInit_S.InitType = p_ISO9141_14230Cmd_init_SP->IOCtlId;

		/* Update init data Length */
		l_ISO9141_14230LinkInit_S.Length = p_ISO9141_14230Cmd_init_SP->Length;

		/* Update the Init Data  */
		memcpy((void *)&l_ISO9141_14230LinkInit_S.Data, (uint8_t *) p_ISO9141_14230Cmd_init_SP->pData,sizeof(uint8_t) * l_ISO9141_14230LinkInit_S.Length);

		
		/* Update checksum if configured */
		if ((CHECK_BITU8(l_ConnectFlags, BIT_CHKSUM) == FALSE) && (l_ISO9141_14230LinkInit_S.InitType == FAST_INIT)) {

			/* Obtain the checksum for Init data */
			
			fl_ChkSum = ISO9141_14230_GetChecksum((void *) l_ISO9141_14230LinkInit_S.Data, l_ISO9141_14230LinkInit_S.Length, CHKSUM_TXDATA);

				/* Store the checksum as the last byte */
				l_ISO9141_14230LinkInit_S.Data  [l_ISO9141_14230LinkInit_S.Length] = fl_ChkSum;
	
			

			/* Update the length for the checksum */
			l_ISO9141_14230LinkInit_S.Length++;
		}
		


		/* Call the init function to perform the initialization of the  communication link */
		ISO9141_14230_LinkInit();
		
	}
	


}
/************************************************************************************************************
 Function name             : ISO9141_14230_LinkInit()
 Function Parameters type  : void
 Short Description         : This function handles the init the initstatus and TX,RX length 
 Return                    : void 
************************************************************************************************************/
static void ISO9141_14230_LinkInit(void)
{

	/* Initialize the Value of Bit position for 5 Baud Init */
	l_BitPos = 0;
	if (l_ProtocolId == KWP_PROTOCOL_ID) {
		l_5BaudIdleTime = l_W5;
	}

	else {

		/* Do Nothing */
	}

	/* Determine the Line configuration */
	if (CHECK_BITU8(l_ConnectFlags, BIT_LINECONF) != FALSE) {

		/* K Line only for initialization */
//	        Set_Pin_Low(KLINE_LLINE_SLCT);
	}

	else {

		/* Use both K and L line for initialization */
//              Set_Pin_High(KLINE_LLINE_SLCT);
	}

	
	/* Clear the RxLength */
	l_RxLength = 0;
	l_MsgReceived = FALSE;
	l_P3MINTimeout = FALSE;
	l_TxComp = FALSE;

	/* Clear the TxLength, Tx index and UART interrupt Tx index */
	l_TxLength = 0;
	l_TxIndex = 0;
	l_UARTIntrTxIndex = 0;


	/* ISO9141_14230_RxMsg_S_Buffer initialize */
	memset((void*)&ISO9141_14230_RxMsg_S_Buffer,0,sizeof(ISO9141_14230_RxMsg_S_Buffer));
	
	/* Initialization status - Pending */
	l_InitStatus = LINKINIT_PENDING;
}
/************************************************************************************************************
 Function name             : ISO9141_14230_GetParity()
 Function Parameters type  : void
 Short Description         : This function handles the parity check
 Return                    : bool 
************************************************************************************************************/
static bool ISO9141_14230_GetParity(void)
{
	uint8_t fl_Msk = 0;
	uint8_t fl_CntOne = 0;
	bool fl_Ret = FALSE;

	/* Count the number of 1s in the address byte */
	for (fl_Msk = 0; fl_Msk < l_DataBits; fl_Msk++) {

		/* Check if 1 or 0 */
		if (CHECK_BITU8(l_ISO9141_14230LinkInit_S.Data[0], fl_Msk) != FALSE) {
			fl_CntOne++;
		}
	}

	/* If the Count is Odd and if the Parity is Odd parity return TRUE */
	if ((fl_CntOne % 2) != 0) {
		if (l_Parity == ODD_PARITY) {
			fl_Ret = !FALSE;
		}
	}

	/* Count is Even and if the Parity is Even parity return TRUE */
	else if (l_Parity == EVEN_PARITY) {
		fl_Ret = !FALSE;
	}

	else {

		/* Do nothing */
	}
	return fl_Ret;
}
/************************************************************************************************************
 Function name             : ISO9141_14230_WriteMsg()
 Function Parameters type  : void
 Short Description         : This function handles the calculating checksum and initiate TX
 Return                    : ISO9141_14230_RETCODE
************************************************************************************************************/
ISO9141_14230_RETCODE ISO9141_14230_WriteMsg(void)
{
	

	ISO9141_14230_RETCODE fl_RetCode = NO_ERROR;
	//ISO9141_14230_QSTATUS fl_TxQStatus;
	uint8_t fl_ChkSum;

	/* Calculate checksum if configured */
	if (CHECK_BITU8(l_ConnectFlags, BIT_CHKSUM) == FALSE) {

		/* Obtain the checksum for Tx data */
		fl_ChkSum = ISO9141_14230_GetChecksum(ISO9141_14230_TxMsg_S_Buffer.Data, ISO9141_14230_TxMsg_S_Buffer.Length, CHKSUM_TXDATA);

		/* Store the checksum as the last byte */
		ISO9141_14230_TxMsg_S_Buffer.Data[ISO9141_14230_TxMsg_S_Buffer.Length] = fl_ChkSum;

		/* Update the length for the checksum */
		ISO9141_14230_TxMsg_S_Buffer.Length++;
	}

	/* Add the message to be transmitted to the Queue */
	
	kwp_TxMsg_received = !FALSE;
	
	#if 0

	/* Restore the Tx frame if checksum is configured */
	if (CHECK_BITU8(l_ConnectFlags, BIT_CHKSUM) == FALSE) {

		/* Nullify the changes due to checksum */
		ISO9141_14230_TxMsg_S_Buffer.Length--;
		ISO9141_14230_TxMsg_S_Buffer.Data[ISO9141_14230_TxMsg_S_Buffer.Length] = 0;
	}
	#endif 
	/* Update Tx Timestamp */
	//get_time_stamp(timestamp_id[GARUDA_KWP_CH1], &p_ISO9141_14230TxMsg_SP->Timestamp);
	//get_data_logging_time_stamp(&p_ISO9141_14230TxMsg_SP->Timestamp);
	//  get_time_stamp(&p_ISO9141_14230TxMsg_SP->Timestamp);                               //here updating timestamp
	/* Check if the queue is Full */
#if 0	
	if (ISO9141_14230_Q_FULL == fl_TxQStatus) {

		/* Send Return Code */
		fl_RetCode = ISO9141_14230_TXQ_FULL;
	}
#endif


	/* Return code */
	return fl_RetCode;
}

/************************************************************************************************************
 Function name             : ISO9141_14230_TxTask()
 Function Parameters type  : void
 Short Description         : This function handles the TX
 Return                    : void
************************************************************************************************************/

void ISO9141_14230_TxTask(void)
{
	static int iter = 0;
	static int Tx_sendLength = 1;

	/* Check if transmission completed during non-init to remove the Tx frame from Buffer */
	if ((l_InitStatus != LINKINIT_PENDING) && (l_TxComp != FALSE)) {
		

		if (l_loopback) {

			ISO9141_14230_TxMsg_S_Buffer.Flags = 0x00000001;
			
			memset((void*)&ISO9141_14230_RxMsg_S_Buffer,0,sizeof(ISO9141_14230_RxMsg_S)) ;
			memcpy(&ISO9141_14230_TxMsg_S_Buffer,&ISO9141_14230_RxMsg_S_Buffer,sizeof(ISO9141_14230_RxMsg_S));


		}
		else{
			
		}
		
			/* Clear TxMsg buffer */		
			memset((void*)&ISO9141_14230_TxMsg_S_Buffer,0,sizeof(ISO9141_14230_TxMsg_S)) ;
			
			/* reset Txcompletion flag */
			l_TxComp = FALSE;
			kwp_TxMsg_received = FALSE;
	}

	/* Read a frame from buffer iF (The initialization is not in the pending state AND
        The minimum time between ECU response and tester request has elapsed P3min  AND
        the previous frame is loaded to UART for transmission OR the Tx frame length is nonzero AND
	Index has not reached the Tx frame length) ) */
	if (((l_InitStatus != LINKINIT_PENDING) && (((l_P3MINTimeout != FALSE) && (l_TxLength == 0)) || ((l_TxLength != 0) && (l_TxIndex < l_TxLength)))) && (l_RxLength == 0))

	{	
		if(kwp_TxMsg_received == !FALSE)
		{

			/* Initialize Index for Tx bytes when a new frame is to be transmitted */
			if ((l_TxLength == 0) && (l_TxIndex != 0)) {
				

				/* New frame - Restart Index */
				l_TxIndex = 0;
			}
			

			/* Load the Tx bytes onto UART */
			
			/* Save the Tx frame length and Load Tx Interbyte time for the new frame */
			if (l_TxIndex == 0) {
					

					/* Save Tx Length */
					l_TxLength = ISO9141_14230_TxMsg_S_Buffer.Length;

					
					/* Start loading 1st byte Tx data onto the UART when P4MIN is 5ms */
					if(l_P4MIN != 0 )
					{
						uart_send_data(Global_uart_ctx,(char)ISO9141_14230_TxMsg_S_Buffer.Data[l_TxIndex]);
						l_TxIndex++;
						KWP_reset_TimeOut();
						KWP_Set_TimeOut((l_P4MIN),P4MIN_WAIT);
					}
					/* Start loading 1st byte Tx data onto the UART when P4MIN is 0ms */
					else
					{
						/* TX length is less than 32bytes  */
						if(l_TxLength > 32)
						{

							Tx_sendLength = 32;
						}
						/* TX length is greater than 32bytes  */
						else
						{
							Tx_sendLength = l_TxLength;
						}

						KWP_reset_TimeOut();

						/*UART send (For safe send max 32 bytes)*/
						uart_send_dataarray(Global_uart_ctx,(char *)&ISO9141_14230_TxMsg_S_Buffer.Data[l_TxIndex],Tx_sendLength);
					                            			
						/* indx increment for next 32 bytes*/
						if(l_TxLength > 32)
                                                {
							l_TxIndex += 32;

                                                }
                                                else
                                                {
                                                       l_TxIndex = l_TxLength;
                                                }

					}
					
					
			}
			else
			{	
				/* When P4MIN is Zero */
				/* Increasing flashing speed */

				if (l_P4MIN == 0) {

					if (l_TxIndex < l_TxLength) {

						
						/* TX length is greater than 32bytes */ 
						if(l_TxLength >= (l_TxIndex + 32))
                                                {

							Tx_sendLength = 32;
                                                }
						/* TX length reaches last 32 bytes */
                                                else
                                                {
                                                        Tx_sendLength = l_TxLength - l_TxIndex;
                                                }
                                                KWP_reset_TimeOut();

						/*UART Send 32bytes */
                                                uart_send_dataarray(Global_uart_ctx,(char *)&ISO9141_14230_TxMsg_S_Buffer.Data[l_TxIndex],Tx_sendLength);
                                               
						/* indx increament for next 32bytes */
						if(l_TxLength > (l_TxIndex + 32))
                                                {
                                                        l_TxIndex += 32;
                                                }
                                                else
                                                {
                                                       l_TxIndex = l_TxLength;
                                                }
			
					}
					else
					{

					}
				}



			}
			
			/*Normal Tx send Flags set */
			/*When P4MIN is 5ms,sending Tx at KWP_timeout() */			
			if (l_P4MIN != 0 ) {
				Txtask_data_sent_start_flag = true;
				if (Txtask_data_sent_end_flag == true) {
			
					Txtask_data_sent_start_flag = false;
					Txtask_data_sent_end_flag   = false;
				}

				else{

 				}

			}
			
		}
		else{
			/*Do nothing*/
		}
	}
}
/************************************************************************************************************
 Function name             : ISO9141_14230_RxTask()
 Function Parameters type  : void
 Short Description         : This function handles the RX
 Return                    : void
************************************************************************************************************/
void ISO9141_14230_RxTask(void)
{

	uint8_t fl_ChkSum;
	uint16_t l_Chk78Length = 0, l_Chk78Frame = 0, l_Chk78Index = 0;
	bool l_Rxd78 = FALSE;
	
	ISO9141_14230_RxMsg_S_Buffer.Flags = 0;
	
	/* Poll the Length Queue only if not in Fast or Five Baud Initialization */
    	if(l_InitStatus != LINKINIT_PENDING)
	{

		/* checking RxMSg received flag */
		if(kwp_RxMsg_received != FALSE)
		{

			if(CHECK_BITU8(l_ConnectFlags, BIT_CHKSUM) == FALSE)
			{
				/* Obtain the checksum for Rx data */
				fl_ChkSum = ISO9141_14230_GetChecksum(ISO9141_14230_RxMsg_S_Buffer.Data,ISO9141_14230_RxMsg_S_Buffer.Length,CHKSUM_RXDATA);
				
				/* If Checksum is ok */
				if(fl_ChkSum == CHECKSUM_OK)
				{
					/* Update length */
					ISO9141_14230_RxMsg_S_Buffer.Length--;

					   /* Remove the checksum byte - Update only data*/
					ISO9141_14230_RxMsg_S_Buffer.Data[ISO9141_14230_RxMsg_S_Buffer.Length] = 0;

					   /* Update the Rx timestamp to the Rx frame */
			    //             ISO9141_14230_DelFromQ(ISO9141_14230_TIME_Q,(ISO9141_14230_Q_S *) &fl_ISO9141_14230Rx_S.Timestamp);
		#if 0
					   /* Check if the message qualifies for the filter */
					   if(J2534_checkFilter(&fl_ISO9141_14230Rx_S.Data[0], fl_ISO9141_14230Rx_S.Length,GARUDA_KWP_CH1) == J2534_PASS)
					   {
						   /* Store the message onto the Rx queue */
						   fl_RxQStatus = ISO9141_14230_AddToQ(ISO9141_14230_RX_Q
							   , (const ISO9141_14230_Q_S *)&fl_ISO9141_14230Rx_S,
							   0);
							   
							kwp_RxMsg_buffer_updated = true;

						   /* Report error if RxQ full */
						   if(ISO9141_14230_Q_FULL == fl_RxQStatus)
						   {
							   /* Set Error Code and report to Call back function */
							   App_ErrHandler(l_ProtocolId, RXQ_OVERFLOW);
						   }
					   }
					   else
					   {
					   
					   }
		#endif				//printf("checksum_ok\n");
						/* after checkfilter implementation, this statement moves to if condition */
						kwp_RxMsg_buffer_updated = !FALSE;
					
				}
				/* If checksum not Ok, reported checksum error*/
				else
				{
					/* call error handler,reported checksum error */
					App_ErrHandler(l_ProtocolId, ECU_RESPCHKSUM_ERROR); 
					
					if(l_ProtocolId == KWP_PROTOCOL_ID)
					{
					   	/* Save the total length */
                       			     	l_Chk78Length = ISO9141_14230_RxMsg_S_Buffer.Length;
                       				l_Chk78Frame = 0;
					
					
						/* Check for the response $78 */
						
						/* doubt this for LOOP requied */
						for(l_Chk78Index = 0;l_Chk78Index  < l_Chk78Length; l_Chk78Index++)
						{
								/* Search if 7F and 78 are in the response */
								if( (ISO9141_14230_RxMsg_S_Buffer.Data[l_Chk78Index] == 0x7F) && (ISO9141_14230_RxMsg_S_Buffer.Data[l_Chk78Index+2] == 0x78))
								{
									/* Received 78 response */
									l_Rxd78 = !FALSE;
								   
								}
						}
						/* Check for positive response after 78 */
						if((l_Rxd78 != FALSE) && (l_Chk78Frame < l_Chk78Length))
						{
						   
						}
		                		/* If no 78 detected report error */
						if(l_Chk78Frame == 0)
						{
								
						}

					}
					else{
						 /* Call application error handler */
					}
					
				}
			}
			/* If no checksum configured */
			else
			{
				/* Update the Rx timestamp to the Rx frame */
			//	ISO9141_14230_DelFromQ(ISO9141_14230_TIME_Q,(ISO9141_14230_Q_S *) &fl_ISO9141_14230Rx_S.Timestamp);
	#if 0
		       			/* Check if the message qualifies for the filter */
			       if(J2534_checkFilter(&fl_ISO9141_14230Rx_S.Data[0],fl_ISO9141_14230Rx_S.Length,GARUDA_KWP_CH1) == J2534_PASS)
			       {
				   /* Store the message onto the Rx queue */
				//   fl_RxQStatus = ISO9141_14230_AddToQ(ISO9141_14230_RX_Q ,(const ISO9141_14230_Q_S *)&fl_ISO9141_14230Rx_S,0);
							
				 	kwp_RxMsg_buffer_updated = true;
							
				   /* Report error if RxQ full */
				   if(ISO9141_14230_Q_FULL == fl_RxQStatus)
				   {
				       /* Set Error Code and report to Call back function */
				       App_ErrHandler(l_ProtocolId, RXQ_OVERFLOW);
				   }
			       }
				else
				{
					   
				}
	#endif		
				
				kwp_RxMsg_buffer_updated = !FALSE;
			}
			
		}
		else 
		{
			/* do nothing */
		}	
	}
	else
	{
		/*do nothing */
	}

}
/************************************************************************************************************
 Function name             : App_FirstByteRxd()
 Function Parameters type  : uint32_t, uint32_t
 Short Description         : This function handles the First Byte received 
 Return                    : void
************************************************************************************************************/
void App_FirstByteRxd(uint32_t l_ProtocolId, uint32_t p_timestamp)
{

        uint8_t usb_tx[512] = {0};


        //usb_tx[0] = l_ProtocolId;
        usb_tx[0] = (l_ProtocolId >> 0) & 0xFF;
    	usb_tx[1] = (l_ProtocolId >> 8) & 0xFF;
    	usb_tx[2] = (l_ProtocolId >> 16) & 0xFF;
    	usb_tx[3] = (l_ProtocolId >> 24) & 0xFF;
    
        
        usb_tx[4] = 0x0A;
        usb_tx[5] = 0;
        usb_tx[6] = 0;
        usb_tx[7] = 0;
        usb_tx[8] = 0;
        usb_tx[9] = 2;
        usb_tx[10] = 0;
        usb_tx[11] = 0;
        usb_tx[12] = 0;
        usb_tx[13] = (uint8_t)(p_timestamp & 0xFF);
        usb_tx[14] = (uint8_t)((p_timestamp >> 8) & 0xFF);
        usb_tx[15] = (uint8_t)((p_timestamp >> 16) & 0xFF);
        usb_tx[16] = (uint8_t)((p_timestamp >> 24) & 0xFF);
        usb_tx[17] = 0;
        
        (void)host_write((void *)usb_tx, 18);
        
}
/************************************************************************************************************
 Function name             : PassThruReadMsgResp_KWP()
 Function Parameters type  : void
 Short Description         : This function handles to send the ECU Rx response to upper layer
 Return                    : void
************************************************************************************************************/
void PassThruReadMsgResp_KWP (void)
{

    static uint16_t fl_KWPRX_LocalLen;
    static uint8_t fl_KWPRX_SegNo=0;

    uint8_t fl_USB_tx_data_U8A[512] ;
    uint16_t fl_IdxLen;
    uint32_t current_time_stamp = 0;

    if(0 == fl_KWPRX_SegNo)
    {
        /* Update the Error Code based on the return */
        if(kwp_RxMsg_buffer_updated != FALSE)
        {

            /* Determine the Response */
            //fl_USB_tx_data_U8A[0] = get_ISO9141_or_14230();//HFCP.c
            fl_USB_tx_data_U8A[0]= (l_ProtocolId >> 0) & 0xFF;
            fl_USB_tx_data_U8A[1]= (l_ProtocolId >> 8) & 0xFF;
            fl_USB_tx_data_U8A[2]= (l_ProtocolId >> 16) & 0xFF;
            fl_USB_tx_data_U8A[3]= (l_ProtocolId >> 24) & 0xFF;
            fl_USB_tx_data_U8A[4] = KWP_Receive_msg;
            fl_USB_tx_data_U8A[5] = fl_KWPRX_SegNo;
            fl_USB_tx_data_U8A[6] = STATUS_NOERROR;

            /* Store the read message */
            fl_USB_tx_data_U8A[7] = (uint8_t)((ISO9141_14230_RxMsg_S_Buffer.Length )      & 0xFF);
            fl_USB_tx_data_U8A[8] = (uint8_t)((ISO9141_14230_RxMsg_S_Buffer.Length >> 8)  & 0xFF);

            fl_USB_tx_data_U8A[9] = (uint8_t)((ISO9141_14230_RxMsg_S_Buffer.Flags )      & 0xFF);
            fl_USB_tx_data_U8A[10] = (uint8_t)((ISO9141_14230_RxMsg_S_Buffer.Flags >> 8)  & 0xFF);
            fl_USB_tx_data_U8A[11] = (uint8_t)((ISO9141_14230_RxMsg_S_Buffer.Flags >> 16) & 0xFF);
            fl_USB_tx_data_U8A[12] = (uint8_t)((ISO9141_14230_RxMsg_S_Buffer.Flags >> 24) & 0xFF);

            current_time_stamp = ISO9141_14230_RxMsg_S_Buffer.Timestamp;
            fl_USB_tx_data_U8A[13] = (uint8_t)((current_time_stamp )      & 0xFF);
            fl_USB_tx_data_U8A[14] = (uint8_t)((current_time_stamp >> 8)  & 0xFF);
            fl_USB_tx_data_U8A[15] = (uint8_t)((current_time_stamp >> 16) & 0xFF);
            fl_USB_tx_data_U8A[16] = (uint8_t)((current_time_stamp >> 24) & 0xFF);
            /* Make the Local Length as 0 As it first frame*/
            fl_KWPRX_LocalLen = 0;
            /* 50 bytes of Space in this USB Frame */
            
            /* size needs to check */
            for(fl_IdxLen = 0;fl_IdxLen < ISO9141_14230_RxMsg_S_Buffer.Length;fl_IdxLen++)
            {
                fl_USB_tx_data_U8A[17+fl_IdxLen]  =  ISO9141_14230_RxMsg_S_Buffer.Data[fl_IdxLen];
                fl_KWPRX_LocalLen++;
            }

            	/* Reset RxMsg buffer variable */
                kwp_RxMsg_received = FALSE;
		kwp_RxMsg_buffer_updated = FALSE;
		
		/* Reset RxMsg struct */
		memset((void*)&ISO9141_14230_RxMsg_S_Buffer,0,sizeof(ISO9141_14230_RxMsg_S_Buffer)) ;



            (void)host_write((void *)fl_USB_tx_data_U8A, 60);// gowtham
       
        }
    }
 
    else
    {
        /* Do Nothing */
    }
}

/************************************************************************************************************
 Function name             : ISO9141_14230_Reset()
 Function Parameters type  : void
 Short Description         : This function handles the reset of global variables and timer values and flags
 Return                    : void
************************************************************************************************************/
void ISO9141_14230_Reset(void)
{
	/* Reset UART communication */

	memset((void *)&ISO9141_14230_TxMsg_S_Buffer, 0, sizeof(ISO9141_14230_TxMsg_S_Buffer));
	memset((void *)&ISO9141_14230_RxMsg_S_Buffer, 0, sizeof(ISO9141_14230_RxMsg_S_Buffer));
	
	/* Initializuint8_te Link Init structure */
	memset((void *)&l_ISO9141_14230LinkInit_S, 0, sizeof(ISO9141_14230_LinkInit_S));

	/* Initialize Init Return data structure */
	memset((void *)&l_ISO9141_14230LinkInitRet_S, 0, sizeof(ISO9141_14230_LinkInitRet_S));


	timer_init_flag = FALSE;
	fastinit_start_comm_req_start_flag = FALSE;
	fastinit_start_comm_req_end_flag = FALSE;
	kwp_RxMsg_received = FALSE;
	kwp_RxMsg_buffer_updated = FALSE;
	kwp_TxMsg_received = FALSE;

	l_p4min_timeout = false;

	/* Reset all the ISO 9141 / 14230 parameters to default values */
	l_Parity = NO_PARITY;
	l_DataBits = EIGHT_BITS;
	l_ConnectFlags = 0;
	l_loopback = 0;
	l_P1MAX = 20000; 
	l_P3MIN = 55000;
	l_P4MIN = 10000;
	l_W0 = 300000;
	l_W1 = 300000;
	l_W2 = 20000;
	l_W3 = 20000;
	l_W4 = 49500;		/* Minimum Time of 50ms is not possible
				   because of the delay in trasnmission
				   and the max time being 50ms as well */
	l_W5 = 300000;
	l_TIDLE = 300000;
	l_TINIL = 25000;
	l_TWUP = 50000;
	l_FiveBaudMod = FIVEBAUD_MODE_ZERO;
	l_RxLength = 0;
	l_TxLength = 0;
	l_TxIndex = 0;
	l_BitPos = 0;
	l_InitStatus = NO_LINKINIT;
	l_UARTIntrTxIndex = 0;
	l_P3MINTimeout = !FALSE;
	l_MsgReceived = FALSE;
	l_TxComp = FALSE;

}
/************************************************************************************************************
 Function name             : App_InitData()
 Function Parameters type  : ISO9141_14230_LinkInitRet_S
 Short Description         : This function handles to send the init status acknowledgement to the upper layer
 Return                    : void
************************************************************************************************************/
void App_InitData(ISO9141_14230_LinkInitRet_S *p_InitData_SP)
{

    uint16_t loop_count;

    hfcpResp_kwp_t * usb_tx = (hfcpResp_kwp_t*)malloc(sizeof(hfcpResp_kwp_t));    


    /* Prepare the USB transmit frame */
  
    usb_tx->resp_proto_id = l_ProtocolId;
    usb_tx->resp_command  = IOCTL_COMMAND;
    usb_tx->un.kwp_ioctl_resp_init.ioctl_ack = IOCTL_COMMAND; // check ack also same value, need to create one macro for ack
    usb_tx->un.kwp_ioctl_resp_init.status = STATUS_NOERROR;
    usb_tx->un.kwp_ioctl_resp_init.length = p_InitData_SP->Length ;
  /*
    usb_tx->un.kwp_ioctl_resp_init.paramId = p_InitData_SP->IOCtlId;

    for(loop_count=0; loop_count < p_InitData_SP->Length; loop_count++)
    {
        usb_tx->un.kwp_ioctl_resp_init.data[loop_count] = p_InitData_SP->Data[loop_count];
    }
*/
    usb_tx->un.kwp_ioctl_resp_init.paramId = p_InitData_SP->IOCtlId;
    usb_tx->un.kwp_ioctl_resp_init.data[0] = p_InitData_SP->Data[0];
    usb_tx->un.kwp_ioctl_resp_init.data[1] = p_InitData_SP->Data[1];
    usb_tx->un.kwp_ioctl_resp_init.data[2] = p_InitData_SP->Data[2];
    usb_tx->un.kwp_ioctl_resp_init.data[3] = p_InitData_SP->Data[3];
    usb_tx->un.kwp_ioctl_resp_init.data[4] = p_InitData_SP->Data[4];
    usb_tx->un.kwp_ioctl_resp_init.data[5] = p_InitData_SP->Data[5];



    (void)host_write((void *) usb_tx, ((sizeof(hfcpResp_kwp_t) - sizeof(usb_tx->un)) + sizeof(usb_tx->un.kwp_ioctl_resp_init)));

}
/************************************************************************************************************
 Function name             : App_ErrHandler()
 Function Parameters type  : uint32_t, uint8_t
 Short Description         : This function handles the error handling messages to upper layer
 Return                    : void
************************************************************************************************************/
void App_ErrHandler(uint32_t protocol_id, uint8_t error_code)
{

     uint8_t usb_tx[512] = {0};

    /* Prepare the USB transmit frame */

    usb_tx[0] = (protocol_id >> 0) & 0xFF;
    usb_tx[1] = (protocol_id >> 8) & 0xFF;
    usb_tx[2] = (protocol_id >> 16) & 0xFF;
    usb_tx[3] = (protocol_id >> 24) & 0xFF;

    /* Report Init error */
    switch(error_code) {
    	case PATTERN_BYTE_TIMEOUT:
    	case KEY_BYTE1_TIMEOUT:
    	case KEY_BYTE2_TIMEOUT:
    	case ADDRESS_BYTE_TIMEOUT:
    		usb_tx[4] = IOCTL_COMMAND;
      		usb_tx[5] = FIVE_BAUD_INIT;
       		usb_tx[6] = ERR_FAILED; 
       		(void)host_write((void *)usb_tx, 7);
       		break;
       	case FASTINIT_RESP_TIMEOUT:
       	case FASTINIT_RESPCHKSUM_ERROR:
       		usb_tx[4] = IOCTL_COMMAND;
      		usb_tx[5] = FAST_INIT;
       		usb_tx[6] = ERR_FAILED; 
       		(void)host_write((void *)usb_tx, 7);
       		break;
       	case MSG_CORRUPTED:
       		usb_tx[4] = SND_MSG_CORRUPTED;
      		usb_tx[5] = MSG_CORRUPTED;
       		usb_tx[6] = ERR_FAILED; 
       		(void)host_write((void *)usb_tx, 7);
       		break;
       	case ECU_RESP_TIMEOUT:
       		usb_tx[4] = SND_ECU_RESP;
      		usb_tx[5] = ECU_RESP_TIMEOUT;
       		usb_tx[6] = ERR_FAILED; 
       		(void)host_write((void *)usb_tx, 7);
       		break;
       	case ECU_RESPCHKSUM_ERROR:
       		usb_tx[4] = SND_ECU_RESPCHKSUM;
      		usb_tx[5] = ECU_RESPCHKSUM_ERROR;
       		usb_tx[6] = ERR_FAILED; 
       		(void)host_write((void *)usb_tx, 7);
       		break;	
       	default:

		usb_tx[4] = ERR_FAILED;
		(void)host_write((void *)usb_tx,4);
       		break;
  		
    }
   
}
/************************************************************************************************************
 Function name             : Set_Baudrate()
 Function Parameters type  : uint32_t
 Short Description         : This function handles the set baudrate
 Return                    : int
************************************************************************************************************/
int Set_Baudrate(uint32_t fl_BaudRate)
{
	int fl_Ret;
	fl_Ret = ioctl(fd,ATMEL_IOCTL_SET_KWP_BAUD ,&fl_BaudRate);
	
	return fl_Ret;
}

/************************************************************************************************************
 Function name             : Set_Parity()
 Function Parameters type  : Parity_t
 Short Description         : This function handles the set parity
 Return                    : int
************************************************************************************************************/
int Set_Parity(Parity_t fl_Parity)
{
	int fl_Ret;
	ioctl(fd,ATMEL_IOCTL_SET_PARITY ,&fl_Parity);
	
	return fl_Ret;
}

/************************************************************************************************************
 Function name             : ISO9141_14230_Get_Data_Length()
 Function Parameters type  : uint16_t
 Short Description         : This function handles to get the data length from ECU response
 Return                    : uint16_t
************************************************************************************************************/
static uint16_t ISO9141_14230_Get_Data_Length( uint8_t recvdData, uint16_t* lengthIndex)
{
	uint8_t frameAddrModeInfo = ADDRESS_PRESENT;
	uint16_t pktlength=0;
	
	if(*lengthIndex == 0)
	{
		
		if( (recvdData & FRAME_FORMAT_MODE_BITS) == 0)
		{
			frameAddrModeInfo = NO_ADDRESS;
		}
		else
		{
			frameAddrModeInfo = ADDRESS_PRESENT;
		}
		
		if( (recvdData & FRAME_FORMAT_HDR_LENGTH_BITS) != FRAME_FORMAT_HDR_LEN_ZERO)
		{
			pktlength = ( (recvdData & FRAME_FORMAT_HDR_LENGTH_BITS) + ((frameAddrModeInfo == ADDRESS_PRESENT) ? HDR_FRM_TA_SA_CK : HDR_FRM_CK));
			*lengthIndex =0;
		}
		else
		{
			*lengthIndex = ((frameAddrModeInfo == ADDRESS_PRESENT) ? LENGTH_INDEX_WITH_ADDR : LENGTH_INDEX_WO_ADDR);
		}
	}
	else
	{
		pktlength = recvdData + ((frameAddrModeInfo == ADDRESS_PRESENT) ? HDR_FRM_TA_SA_LEN_CK : HDR_FRM_LEN_CK);
		*lengthIndex =0;
	}
	return (pktlength);
}
/************************************************************************************************************
 Function name             : kwp_MessageIdle()
 Function Parameters type  : void 
 Short Description         : This function handles to check kwp_TxMsg_received flag idle
 Return                    : bool
************************************************************************************************************/
bool kwp_MessageIdle(void)
{
	return kwp_TxMsg_received; 
}

/************************************************************************************************************/
