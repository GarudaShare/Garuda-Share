#ifndef _PERIODIC_IF_H_
#define	_PERIODIC_IF_H_

#include	<glib.h>
#include	"g3d.h"
#include        "hfcp.h"
#include        "ioctl_common.h"
#include 	"j2534_periodic.h"
#include        <stdbool.h>


int periodic_init(void);
void PERIODIC_task_handler(void);
uint8_t PERIODIC_task_msg_cmd(PERIODIC_MSG *p_msg_ptr, uint8_t p_periodic_cmd);
uint8_t periodic_suspend_pmsg(uint32_t p_protocol_id);


#endif /* _CAN_IF_H_ */


