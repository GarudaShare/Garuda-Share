#!/bin/sh

# Export PC14 (GPIO 78)
echo 78 > /sys/class/gpio/export
echo 75 > /sys/class/gpio/export

# Set direction to output
echo out > /sys/class/gpio/PC14/direction
echo out > /sys/class/gpio/PC11/direction

# Drive it HIGH
echo 1 > /sys/class/gpio/PC14/value
echo 0 > /sys/class/gpio/PC11/value


