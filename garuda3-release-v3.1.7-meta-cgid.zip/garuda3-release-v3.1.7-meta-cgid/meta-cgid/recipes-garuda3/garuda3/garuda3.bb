SUMMARY = "Garuda-3 Application"
SECTION = "net"
LICENSE = "CLOSED"
LIC_FILES_CHKSUM = ""

DEPENDS += "glib-2.0 glib-2.0-native"
RDEPENDS_${PN} += "glib-2.0 glib-2.0-native bash"
RDEPENDS_${PN} += "/bin/dash"

G3D_REVISION ?= "REVA"

FILESEXTRAPATHS:prepend := "${THISDIR}/${G3D_REVISION}/files:"

SRC_URI = "file://app_iso14230.c \
           file://can.c \
           file://can_if.c \
           file://can_nl_if.c \
           file://data_logger.c \
           file://g3d.c \
           file://hfcp.c \
           file://j2534_filter.c \
           file://j2534_periodic.c \
           file://usbhid.c \
           file://net_if.c \
           file://net.c \
           file://led.c \
           file://g3d.h \
           file://app_iso14230.h \
           file://can.h \
           file://data_logger.h \
           file://hfcp.h \
           file://j2534_filter.h \
           file://j2534_periodic.h \
           file://can_if.h \
           file://can_nl_if.h \
           file://usbhid.h \
           file://net_if.h \
           file://net.h \
           file://gpio_App.c \
           file://gpio_App.h \
           file://kwp_if.c \
           file://kwp_if.h \
           file://periodic_if.c \
           file://periodic_if.h \
           file://led.h \
           file://doip_cli.c \
           file://doip_cli.h \
           file://doip.h \
           file://doip_if.c \
           file://doip_if.h \
           file://ioctl_common.h \
           file://Makefile \
	   file://scripts/run-g3d.sh \
	   file://scripts/run_wifi.sh \
	   file://scripts/fwupdate.sh \
	   file://scripts/obdpower.sh \
	   file://scripts/PC14_HIGH.sh\
           file://scripts/hid.sh \
           file://scripts/usbbridge.sh \
	   file://scripts/Disablebridge.sh \
	   file://scripts/wifi_mod_para.conf \
	   file://scripts/unload_wifi_modules.sh \
           file://scripts/run_wifi.sh \
	   file://scripts/g3-wlan.config \
	   file://scripts/g3-hostapd-param.conf \
	   file://scripts/g3-dhcpconfig.sh \
	   file://scripts/g3d-runloop.sh \
	   file://scripts/wifi_usb_run.sh \
	   file://scripts/g3-dhcp.conf \
	   file://scripts/usb_led.sh \
	   file://scripts/candown.sh"

S = "${WORKDIR}"

CFLAGS  += "`${bindir}/pkg-config --cflags glib-2.0 gio-2.0`"
LDFLAGS += "`${bindir}/pkg-config --libs glib-2.0 gio-2.0`"
LDFLAGS += "-L${S}/recipe-sysroot/usr/lib"
CFLAGS  += "-I${S}"
CFLAGS  += "--sysroot=${STAGING_DIR_TARGET}"
CFLAGS += "-Wall -O2 -Wstrict-prototypes"
#CFLAGS += "-DDEBUG"
#CFLAGS += "-DCONFIG_GPIO"
CFLAGS += "-DCONFIG_LED"
CFLAGS += "-DCONFIG_USBHID"
CFLAGS += "-DCONFIG_WIFI"
CFLAGS += "-DCONFIG_NETIF"
CFLAGS += "-DCONFIG_CAN"
CFLAGS += "-DCONFIG_NET"
CFLAGS += "-DBCM_SUPPORT"
CFLAGS += "-DCONFIG_DOIP"
CFLAGS += "-DCONFIG_PERIODIC"
CFLAGS += "-DCONFIG_KWP"

# Other CFLAGS
# 1. CAN_RAW_RECV_OWN_MSGS_ENABLE
# 2. DEBUG_HEXDUMP_TO_FILE

TARGET_CC_ARCH += "${LDFLAGS}"

do_compile() {
    #echo "### COMPILE :${D}, #### ${bindir}"
    oe_runmake -e g3d
}

do_install() {
    #echo "### INSTALL :${D}, #### ${bindir}, ${libdir}" 
    install -d ${D}${sysconfdir}/init.d
    install -d ${D}${sysconfdir}/rcS.d
    install -d ${D}${sysconfdir}/rc1.d
    install -d ${D}${sysconfdir}/rc2.d
    install -d ${D}${sysconfdir}/rc3.d
    install -d ${D}${sysconfdir}/rc4.d
    install -d ${D}${sysconfdir}/rc5.d
    install -d ${D}${sbindir}
    install -d ${D}${sysconfdir}
    install -m 0755 ${S}/g3d ${D}${sbindir}
    install -m 0755 ${S}/scripts/g3d-runloop.sh ${D}${sbindir}
    install -m 0755 ${S}/scripts/fwupdate.sh ${D}${sbindir}
    install -m 0755 ${S}/scripts/candown.sh ${D}${sbindir}
    install -m 0755 ${S}/scripts/usbbridge.sh ${D}${sbindir}
    install -m 0755 ${S}/scripts/Disablebridge.sh ${D}${sbindir}
#   install -m 0755 ${S}/autostart.sh  ${D}${sysconfdir}/init.d/
    install -m 0755 ${S}/scripts/run-g3d.sh    ${D}${sysconfdir}/init.d/
    install -m 0755 ${S}/scripts/PC14_HIGH.sh    ${D}${sysconfdir}/init.d/
    install -m 0755 ${S}/scripts/obdpower.sh    ${D}${sysconfdir}/init.d/
    install -m 0755 ${S}/scripts/usb_led.sh    ${D}${sysconfdir}/init.d/
    install -m 0755 ${S}/scripts/hid.sh        ${D}${sysconfdir}/init.d/ 
    install -m 0755 ${S}/scripts/g3-dhcp.conf        ${D}${sysconfdir}/
    install -m 0755 ${S}/scripts/run_wifi.sh        ${D}${sysconfdir}/init.d/
    install -m 0755 ${S}/scripts/wifi_usb_run.sh        ${D}${sysconfdir}/init.d/
    install -m 0755 ${S}/scripts/g3-dhcpconfig.sh       ${D}${sysconfdir}/
    install -m 0755 ${S}/scripts/g3-hostapd-param.conf        ${D}${sysconfdir}/
    install -m 0755 ${S}/scripts/g3-wlan.config        ${D}${sysconfdir}/
    install -m 0755 ${S}/scripts/unload_wifi_modules.sh        ${D}${sysconfdir}/init.d/
    install -m 0755 ${S}/scripts/wifi_mod_para.conf        ${D}${sysconfdir}/
#    ln -sf ${D}${sysconfdir}/init.d/autostart.sh    ${D}${sysconfdir}/rcS.d/S90autostart.sh
#    ln -sf ${D}${sysconfdir}/init.d/run-g3d.sh      ${D}${sysconfdir}/rc1.d/K90run-g3d.sh
#    ln -sf ${D}${sysconfdir}/init.d/run-g3d.sh      ${D}${sysconfdir}/rc2.d/K90run-g3d.sh
#    ln -sf ${D}${sysconfdir}/init.d/run-g3d.sh      ${D}${sysconfdir}/rc3.d/K90run-g3d.sh
#    ln -sf ${D}${sysconfdir}/init.d/run-g3d.sh      ${D}${sysconfdir}/rc4.d/K90run-g3d.sh
    ln -sf ../init.d/run-g3d.sh      ${D}${sysconfdir}/rc5.d/S90run-g3d.sh    
}


FILES_${PN} += "${bindir}"
FILES_${PN} += "${libdir}"
FILES_${PN} += "/etc/init.d"
FILES_${PN} += "${sysconfdir}/init.d"
FILES_${PN} += "${sysconfdir}"
