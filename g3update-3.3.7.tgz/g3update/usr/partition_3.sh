#!/bin/bash

DEVICE="/dev/mmcblk0"
P3="/dev/mmcblk0p3"
SECTOR_SIZE=512
START_SECTOR=$((1024*1024*1024 / SECTOR_SIZE))   # 1GB offset = 2097152
SIZE=""  # size of p3 

if [ -b "$P3" ]; then
    echo "Partition p3 already exists. Nothing to do."
    exit 0
fi

echo "Creating p3 at 1GB offset..."
echo -e "n\np\n3\n$START_SECTOR\n$SIZE\nw" | fdisk $DEVICE
reboot


