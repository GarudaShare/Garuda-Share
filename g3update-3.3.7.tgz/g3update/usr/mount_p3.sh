#!/bin/sh
P3="/dev/mmcblk0p3"
MOUNT_POINT="/data"
MAX_WAIT=15   # seconds to wait before giving up

# Wait until device appears, but don't wait forever
echo "Waiting for partition..."
count=0
while [ ! -b "$P3" ]; do
    sleep 1
    count=$((count+1))
    if [ "$count" -ge "$MAX_WAIT" ]; then
        echo "Partition $P3 not found after ${MAX_WAIT}s, skipping."
        exit 1
    fi
done

# Check if already formatted
blkid $P3 | grep -q "ext4"
if [ $? -ne 0 ]; then
    echo "Formatting partition..."
    mkfs.ext4 $P3
else
    echo "Partition already formatted."
fi

# Create mount point
mkdir -p $MOUNT_POINT

# Mount if not already mounted
mount | grep -q "$P3"
if [ $? -ne 0 ]; then
    echo "Mounting partition..."
    mount $P3 $MOUNT_POINT
fi

# Add to fstab if not already present
grep -q "$P3" /etc/fstab
if [ $? -ne 0 ]; then
    echo "Adding to fstab..."
    echo "$P3  $MOUNT_POINT  ext4  defaults  0  2" >> /etc/fstab
fi

echo "Partition ready and mounted at $MOUNT_POINT"
