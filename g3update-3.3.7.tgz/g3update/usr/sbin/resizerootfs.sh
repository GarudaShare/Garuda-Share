#!/bin/sh

RESIZE_FLAG="/var/lib/g3_resize_done"
# Get size of the existing rootfs
ROOTDEVICE="/dev/mmcblk0"
ROOTPARTITION="/dev/mmcblk0p2"
ROOTFSNAME="/dev/root"
ROOTFSSIZE=`df | grep "${ROOTFSNAME}" | awk '{ print $2 }'`
LOWFSSIZE=$((256*1024))
#NEWSIZE="+512M"

TARGET_MB=512
SECTOR_SIZE=512

echo "ROOTFSSIZE=${ROOTFSSIZE}"
echo "LOWFSSIZE=${LOWFSSIZE}"
BOOT_DIR="/boot"

# Step 0: Clean /boot (delete everything except .itb and .itb.prev)
if [ -d "$BOOT_DIR" ]; then
    echo "Cleaning /boot, preserving .itb and .itb.prev files..."
    find "$BOOT_DIR" -maxdepth 1 -type f ! -name "*.itb" ! -name "*.itb.prev" -exec rm -f {} \;
fi
sync

#Step 1: If resize has already been done, run resize2fs
if [ -f "${RESIZE_FLAG}" ]; then
    echo "Running resize2fs on ${ROOTPARTITION}..."
    resize2fs ${ROOTPARTITION}
    rm -f ${RESIZE_FLAG}
    echo "Filesystem resized successfully."
    exit 0
fi


#Step 2: If rootfs is smaller than threshold, extend partition

if [ ${ROOTFSSIZE} -le ${LOWFSSIZE} ]; then
	START_SECTOR=$(fdisk -l ${ROOTDEVICE} | awk '$1 ~ /mmcblk0p2/ {print $4}')
	echo "START_SECTOR=$START_SECTOR"
	SIZE_SECTORS=$((TARGET_MB * 1024 * 1024 / SECTOR_SIZE))
	END_SECTOR=$((START_SECTOR + SIZE_SECTORS - 1))
	sync
	echo -e "d\n2\nn\np\n2\n$START_SECTOR\n$END_SECTOR\nw\n" | fdisk ${ROOTDEVICE}
	
	sync
	touch ${RESIZE_FLAG}
fi

