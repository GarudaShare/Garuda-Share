/*
 * GccApplication2.c
 *
 * Created: 27-11-2026 12:11:48
 * Author : sysadmin
 */ 


#include "sam.h"


int main(void)
{
    /* Initialize the SAM system */
    SystemInit();

    /* Replace with your application code */
    while (1) 
    {
    }
}
