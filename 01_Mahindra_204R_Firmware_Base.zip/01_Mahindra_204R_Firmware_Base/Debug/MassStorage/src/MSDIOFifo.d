MassStorage/src/MSDIOFifo.d MassStorage/src/MSDIOFifo.o: \
 ../MassStorage/src/MSDIOFifo.c ../MassStorage/include/MSDIOFifo.h

../MassStorage/include/MSDIOFifo.h:
