Application/src/Mass_Storage.d Application/src/Mass_Storage.o: \
 ../Application/src/Mass_Storage.c ../Board/board.h ../BSP/chip.h \
 ../BSP/same70n20.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stdint.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\stdint.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\_default_types.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\features.h \
 ../BSP/include/cmsis/CMSIS/Include/core_cm7.h \
 ../BSP/include/cmsis/CMSIS/Include/core_cmInstr.h \
 ../BSP/include/cmsis/CMSIS/Include/core_cmFunc.h \
 ../BSP/include/cmsis/CMSIS/Include/core_cmSimd.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/system_same70.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/acc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/aes.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/afec.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/chipid.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/dacc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/efc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/gmac.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/gpbr.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/hsmci.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/icm.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/isi.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/matrix.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/mcan.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/pio.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/pmc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/pwm.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/qspi.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/rstc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/rswdt.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/rtc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/rtt.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/spi.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/ssc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/supc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/tc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/trng.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/twihs.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/uart.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/usart.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/usbhs.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/utmi.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/wdt.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/xdmac.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/hsmci.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/ssc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/spi0.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/tc0.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/twihs0.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/twihs1.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/pwm0.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/usart0.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/usart1.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/usart2.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/mcan0.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/mcan1.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/usbhs.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/afec0.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/dacc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/acc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/icm.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/isi.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/gmac.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/tc3.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/spi1.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/pwm1.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/twihs2.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/afec1.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/aes.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/trng.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/xdmac.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/qspi.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/matrix.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/utmi.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/pmc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/uart0.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/chipid.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/uart1.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/efc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/pioa.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/piob.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/piod.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/rstc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/supc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/rtt.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/wdt.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/rtc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/gpbr.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/rswdt.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/uart2.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/uart3.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/uart4.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/pio/same70n20.h \
 ../BSP/compiler.h ../BSP/include/same70/include/same70.h \
 ../BSP/include/same70/include/same70n20.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stddef.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\stdlib.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\ieeefp.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\_ansi.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\newlib.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\config.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\reent.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\_ansi.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\_types.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\_types.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\lock.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\stdlib.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\alloca.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stdbool.h \
 ../BSP/include/acc.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\assert.h \
 ../BSP/include/aes.h ../BSP/include/afec.h ../BSP/include/efc.h \
 ../BSP/include/pio.h ../BSP/include/pio_it.h ../BSP/include/pio.h \
 ../BSP/include/rstc.h ../BSP/include/mpu.h ../BSP/include/gmac.h \
 ../BSP/include/gmacd.h ../BSP/include/video.h ../BSP/include/icm.h \
 ../BSP/include/isi.h ../BSP/include/exceptions.h \
 ../BSP/include/pio_capture.h ../BSP/include/rtc.h ../BSP/include/rtt.h \
 ../BSP/include/tc.h ../BSP/include/timetick.h ../BSP/include/twi.h \
 ../BSP/include/flashd.h ../BSP/include/pmc.h ../BSP/include/pwmc.h \
 ../BSP/include/mcan.h ../BSP/include/supc.h ../BSP/include/usart.h \
 ../BSP/include/uart.h ../BSP/include/hsmci.h ../BSP/include/ssc.h \
 ../BSP/include/trng.h ../BSP/include/wdt.h ../BSP/include/spi.h \
 ../BSP/include/qspi.h ../BSP/include/trace.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\stdio.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stdarg.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\types.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\types.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\stdio.h \
 ../BSP/include/xdmac.h ../utils/utility.h \
 ../BSP/include/xdma_hardware_interface.h ../BSP/include/xdmad.h \
 ../BSP/include/mcid.h ../BSP/include/twid.h ../BSP/include/spi_dma.h \
 ../BSP/include/qspi_dma.h ../BSP/include/uart_dma.h \
 ../BSP/include/usart_dma.h ../BSP/include/afe_dma.h \
 ../BSP/include/usbhs.h ../BSP/include/USBD_Config.h \
 ../Board/include/board_lowlevel.h ../Board/include/led.h \
 ../Board/include/syscalls.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\stat.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\time.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\time.h \
 ../Board/include/dbg_console.h ../FreeRTOS/Source/include/FreeRTOS.h \
 ../FreeRTOS/Demo/FreeRTOSConfig.h ../FreeRTOS/Source/include/projdefs.h \
 ../FreeRTOS/Source/include/portable.h \
 ../FreeRTOS/Source/include/deprecated_definitions.h \
 ../FreeRTOS/Source/portable/GCC/SAMV71/portmacro.h \
 ../FreeRTOS/Source/include/mpu_wrappers.h \
 ../FreeRTOS/Source/include/queue.h ../FreeRTOS/Source/include/task.h \
 ../FreeRTOS/Source/include/list.h ../FreeRTOS/Source/include/semphr.h \
 ../FreeRTOS/Source/include/queue.h \
 ../FreeRTOS/Source/include/event_groups.h \
 ../FreeRTOS/Source/include/timers.h ../FreeRTOS/Source/include/task.h \
 ../Application/include/HFCP.h ../BSP/Proj_Config.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\string.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include-fixed\sys\cdefs.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\string.h \
 ../Wrapper/include/CAN_Mid.h ../BSP/Pin_Config.h \
 ../BSP/include/mcan_config.h ../Application/include/Led_Handler.h \
 ../Application/include/Data_Logger.h ../Fatfs/libfatfs/inc/ff.h \
 ../Fatfs/libfatfs/inc/integer.h ../Fatfs/libfatfs/inc/ffconf.h \
 ../Fatfs/libfatfs/inc/..\fatfs_config.h ../Fatfs/libfatfs/inc/integer.h \
 ../Fatfs/libfatfs/inc/diskio.h ../Fatfs/libfatfs/fatfs_config.h \
 ../Application/include/Mass_Storage.h ../Wrapper/include/USB_MSD_Mid.h \
 ../Fatfs/libstoragemedia/include/sdmmc/sdmmc_cmd.h

../Board/board.h:

../BSP/chip.h:

../BSP/same70n20.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stdint.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\stdint.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\_default_types.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\features.h:

../BSP/include/cmsis/CMSIS/Include/core_cm7.h:

../BSP/include/cmsis/CMSIS/Include/core_cmInstr.h:

../BSP/include/cmsis/CMSIS/Include/core_cmFunc.h:

../BSP/include/cmsis/CMSIS/Include/core_cmSimd.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/system_same70.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/acc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/aes.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/afec.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/chipid.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/dacc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/efc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/gmac.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/gpbr.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/hsmci.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/icm.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/isi.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/matrix.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/mcan.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/pio.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/pmc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/pwm.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/qspi.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/rstc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/rswdt.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/rtc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/rtt.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/spi.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/ssc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/supc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/tc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/trng.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/twihs.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/uart.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/usart.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/usbhs.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/utmi.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/wdt.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/xdmac.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/hsmci.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/ssc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/spi0.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/tc0.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/twihs0.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/twihs1.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/pwm0.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/usart0.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/usart1.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/usart2.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/mcan0.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/mcan1.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/usbhs.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/afec0.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/dacc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/acc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/icm.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/isi.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/gmac.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/tc3.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/spi1.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/pwm1.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/twihs2.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/afec1.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/aes.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/trng.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/xdmac.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/qspi.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/matrix.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/utmi.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/pmc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/uart0.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/chipid.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/uart1.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/efc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/pioa.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/piob.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/piod.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/rstc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/supc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/rtt.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/wdt.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/rtc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/gpbr.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/rswdt.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/uart2.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/uart3.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/uart4.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/pio/same70n20.h:

../BSP/compiler.h:

../BSP/include/same70/include/same70.h:

../BSP/include/same70/include/same70n20.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stddef.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\stdlib.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\ieeefp.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\_ansi.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\newlib.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\config.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\reent.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\_ansi.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\_types.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\_types.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\lock.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\stdlib.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\alloca.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stdbool.h:

../BSP/include/acc.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\assert.h:

../BSP/include/aes.h:

../BSP/include/afec.h:

../BSP/include/efc.h:

../BSP/include/pio.h:

../BSP/include/pio_it.h:

../BSP/include/pio.h:

../BSP/include/rstc.h:

../BSP/include/mpu.h:

../BSP/include/gmac.h:

../BSP/include/gmacd.h:

../BSP/include/video.h:

../BSP/include/icm.h:

../BSP/include/isi.h:

../BSP/include/exceptions.h:

../BSP/include/pio_capture.h:

../BSP/include/rtc.h:

../BSP/include/rtt.h:

../BSP/include/tc.h:

../BSP/include/timetick.h:

../BSP/include/twi.h:

../BSP/include/flashd.h:

../BSP/include/pmc.h:

../BSP/include/pwmc.h:

../BSP/include/mcan.h:

../BSP/include/supc.h:

../BSP/include/usart.h:

../BSP/include/uart.h:

../BSP/include/hsmci.h:

../BSP/include/ssc.h:

../BSP/include/trng.h:

../BSP/include/wdt.h:

../BSP/include/spi.h:

../BSP/include/qspi.h:

../BSP/include/trace.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\stdio.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stdarg.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\types.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\types.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\stdio.h:

../BSP/include/xdmac.h:

../utils/utility.h:

../BSP/include/xdma_hardware_interface.h:

../BSP/include/xdmad.h:

../BSP/include/mcid.h:

../BSP/include/twid.h:

../BSP/include/spi_dma.h:

../BSP/include/qspi_dma.h:

../BSP/include/uart_dma.h:

../BSP/include/usart_dma.h:

../BSP/include/afe_dma.h:

../BSP/include/usbhs.h:

../BSP/include/USBD_Config.h:

../Board/include/board_lowlevel.h:

../Board/include/led.h:

../Board/include/syscalls.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\stat.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\time.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\time.h:

../Board/include/dbg_console.h:

../FreeRTOS/Source/include/FreeRTOS.h:

../FreeRTOS/Demo/FreeRTOSConfig.h:

../FreeRTOS/Source/include/projdefs.h:

../FreeRTOS/Source/include/portable.h:

../FreeRTOS/Source/include/deprecated_definitions.h:

../FreeRTOS/Source/portable/GCC/SAMV71/portmacro.h:

../FreeRTOS/Source/include/mpu_wrappers.h:

../FreeRTOS/Source/include/queue.h:

../FreeRTOS/Source/include/task.h:

../FreeRTOS/Source/include/list.h:

../FreeRTOS/Source/include/semphr.h:

../FreeRTOS/Source/include/queue.h:

../FreeRTOS/Source/include/event_groups.h:

../FreeRTOS/Source/include/timers.h:

../FreeRTOS/Source/include/task.h:

../Application/include/HFCP.h:

../BSP/Proj_Config.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\string.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include-fixed\sys\cdefs.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\string.h:

../Wrapper/include/CAN_Mid.h:

../BSP/Pin_Config.h:

../BSP/include/mcan_config.h:

../Application/include/Led_Handler.h:

../Application/include/Data_Logger.h:

../Fatfs/libfatfs/inc/ff.h:

../Fatfs/libfatfs/inc/integer.h:

../Fatfs/libfatfs/inc/ffconf.h:

../Fatfs/libfatfs/inc/..\fatfs_config.h:

../Fatfs/libfatfs/inc/integer.h:

../Fatfs/libfatfs/inc/diskio.h:

../Fatfs/libfatfs/fatfs_config.h:

../Application/include/Mass_Storage.h:

../Wrapper/include/USB_MSD_Mid.h:

../Fatfs/libstoragemedia/include/sdmmc/sdmmc_cmd.h:
