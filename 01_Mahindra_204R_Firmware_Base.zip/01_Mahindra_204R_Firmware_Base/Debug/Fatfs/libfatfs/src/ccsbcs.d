Fatfs/libfatfs/src/ccsbcs.d Fatfs/libfatfs/src/ccsbcs.o: \
 ../Fatfs/libfatfs/src/ccsbcs.c ../Fatfs/libfatfs/inc/ff.h \
 ../Fatfs/libfatfs/inc/integer.h ../Fatfs/libfatfs/inc/ffconf.h \
 ../Fatfs/libfatfs/inc/..\fatfs_config.h ../Fatfs/libfatfs/inc/integer.h \
 ../Fatfs/libfatfs/inc/diskio.h ../Fatfs/libfatfs/fatfs_config.h

../Fatfs/libfatfs/inc/ff.h:

../Fatfs/libfatfs/inc/integer.h:

../Fatfs/libfatfs/inc/ffconf.h:

../Fatfs/libfatfs/inc/..\fatfs_config.h:

../Fatfs/libfatfs/inc/integer.h:

../Fatfs/libfatfs/inc/diskio.h:

../Fatfs/libfatfs/fatfs_config.h:
