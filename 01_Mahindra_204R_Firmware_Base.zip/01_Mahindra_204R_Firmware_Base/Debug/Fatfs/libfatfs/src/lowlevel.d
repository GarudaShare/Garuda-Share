Fatfs/libfatfs/src/lowlevel.d Fatfs/libfatfs/src/lowlevel.o: \
 ../Fatfs/libfatfs/src/lowlevel.c
