Fatfs/libstoragemedia/src/sdmmc.d Fatfs/libstoragemedia/src/sdmmc.o: \
 ../Fatfs/libstoragemedia/src/sdmmc.c \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\assert.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\_ansi.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\newlib.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\config.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\ieeefp.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\features.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\string.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\reent.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\_ansi.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stddef.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\_types.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\_types.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\_default_types.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\lock.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include-fixed\sys\cdefs.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\string.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stdint.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\stdint.h \
 ../FreeRTOS/Source/include/FreeRTOS.h ../FreeRTOS/Demo/FreeRTOSConfig.h \
 ../FreeRTOS/Source/include/projdefs.h \
 ../FreeRTOS/Source/include/portable.h \
 ../FreeRTOS/Source/include/deprecated_definitions.h \
 ../FreeRTOS/Source/portable/GCC/SAMV71/portmacro.h \
 ../FreeRTOS/Source/include/mpu_wrappers.h \
 ../FreeRTOS/Source/include/task.h ../FreeRTOS/Source/include/list.h \
 ../BSP/Proj_Config.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stdbool.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\stdio.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stdarg.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\types.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\types.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\stdio.h \
 ../Fatfs/libstoragemedia/include/sdmmc/libsdmmc.h \
 ../Fatfs/libstoragemedia/include/sdmmc/sdmmc_cmd.h \
 ../Fatfs/libstoragemedia/include/sdmmc/sdmmc.h \
 ../Fatfs/libstoragemedia/include/sdmmc/sdmmc_hal.h ../BSP/compiler.h \
 ../BSP/include/same70/include/same70.h \
 ../BSP/include/same70/include/same70n20.h \
 ../BSP/include/cmsis/CMSIS/Include/core_cm7.h \
 ../BSP/include/cmsis/CMSIS/Include/core_cmInstr.h \
 ../BSP/include/cmsis/CMSIS/Include/core_cmFunc.h \
 ../BSP/include/cmsis/CMSIS/Include/core_cmSimd.h \
 ../BSP/include/same70/include/system_same70.h \
 ../BSP/include/same70/include/component/acc.h \
 ../BSP/include/same70/include/component/aes.h \
 ../BSP/include/same70/include/component/afec.h \
 ../BSP/include/same70/include/component/chipid.h \
 ../BSP/include/same70/include/component/dacc.h \
 ../BSP/include/same70/include/component/efc.h \
 ../BSP/include/same70/include/component/gmac.h \
 ../BSP/include/same70/include/component/gpbr.h \
 ../BSP/include/same70/include/component/hsmci.h \
 ../BSP/include/same70/include/component/icm.h \
 ../BSP/include/same70/include/component/isi.h \
 ../BSP/include/same70/include/component/matrix.h \
 ../BSP/include/same70/include/component/mcan.h \
 ../BSP/include/same70/include/component/pio.h \
 ../BSP/include/same70/include/component/pmc.h \
 ../BSP/include/same70/include/component/pwm.h \
 ../BSP/include/same70/include/component/qspi.h \
 ../BSP/include/same70/include/component/rstc.h \
 ../BSP/include/same70/include/component/rswdt.h \
 ../BSP/include/same70/include/component/rtc.h \
 ../BSP/include/same70/include/component/rtt.h \
 ../BSP/include/same70/include/component/spi.h \
 ../BSP/include/same70/include/component/ssc.h \
 ../BSP/include/same70/include/component/supc.h \
 ../BSP/include/same70/include/component/tc.h \
 ../BSP/include/same70/include/component/trng.h \
 ../BSP/include/same70/include/component/twihs.h \
 ../BSP/include/same70/include/component/uart.h \
 ../BSP/include/same70/include/component/usart.h \
 ../BSP/include/same70/include/component/usbhs.h \
 ../BSP/include/same70/include/component/utmi.h \
 ../BSP/include/same70/include/component/wdt.h \
 ../BSP/include/same70/include/component/xdmac.h \
 ../BSP/include/same70/include/instance/hsmci.h \
 ../BSP/include/same70/include/instance/ssc.h \
 ../BSP/include/same70/include/instance/spi0.h \
 ../BSP/include/same70/include/instance/tc0.h \
 ../BSP/include/same70/include/instance/twihs0.h \
 ../BSP/include/same70/include/instance/twihs1.h \
 ../BSP/include/same70/include/instance/pwm0.h \
 ../BSP/include/same70/include/instance/usart0.h \
 ../BSP/include/same70/include/instance/usart1.h \
 ../BSP/include/same70/include/instance/usart2.h \
 ../BSP/include/same70/include/instance/mcan0.h \
 ../BSP/include/same70/include/instance/mcan1.h \
 ../BSP/include/same70/include/instance/usbhs.h \
 ../BSP/include/same70/include/instance/afec0.h \
 ../BSP/include/same70/include/instance/dacc.h \
 ../BSP/include/same70/include/instance/acc.h \
 ../BSP/include/same70/include/instance/icm.h \
 ../BSP/include/same70/include/instance/isi.h \
 ../BSP/include/same70/include/instance/gmac.h \
 ../BSP/include/same70/include/instance/tc3.h \
 ../BSP/include/same70/include/instance/spi1.h \
 ../BSP/include/same70/include/instance/pwm1.h \
 ../BSP/include/same70/include/instance/twihs2.h \
 ../BSP/include/same70/include/instance/afec1.h \
 ../BSP/include/same70/include/instance/aes.h \
 ../BSP/include/same70/include/instance/trng.h \
 ../BSP/include/same70/include/instance/xdmac.h \
 ../BSP/include/same70/include/instance/qspi.h \
 ../BSP/include/same70/include/instance/matrix.h \
 ../BSP/include/same70/include/instance/utmi.h \
 ../BSP/include/same70/include/instance/pmc.h \
 ../BSP/include/same70/include/instance/uart0.h \
 ../BSP/include/same70/include/instance/chipid.h \
 ../BSP/include/same70/include/instance/uart1.h \
 ../BSP/include/same70/include/instance/efc.h \
 ../BSP/include/same70/include/instance/pioa.h \
 ../BSP/include/same70/include/instance/piob.h \
 ../BSP/include/same70/include/instance/piod.h \
 ../BSP/include/same70/include/instance/rstc.h \
 ../BSP/include/same70/include/instance/supc.h \
 ../BSP/include/same70/include/instance/rtt.h \
 ../BSP/include/same70/include/instance/wdt.h \
 ../BSP/include/same70/include/instance/rtc.h \
 ../BSP/include/same70/include/instance/gpbr.h \
 ../BSP/include/same70/include/instance/rswdt.h \
 ../BSP/include/same70/include/instance/uart2.h \
 ../BSP/include/same70/include/instance/uart3.h \
 ../BSP/include/same70/include/instance/uart4.h \
 ../BSP/include/same70/include/pio/same70n20.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\stdlib.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\stdlib.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\alloca.h \
 ../Fatfs/libstoragemedia/include/sdmmc/sdio.h \
 ../Fatfs/libstoragemedia/include/sdmmc/sdmmc_trace.h \
 ../Application/include/time_stamps.h

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\assert.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\_ansi.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\newlib.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\config.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\ieeefp.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\features.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\string.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\reent.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\_ansi.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stddef.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\_types.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\_types.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\_default_types.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\lock.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include-fixed\sys\cdefs.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\string.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stdint.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\stdint.h:

../FreeRTOS/Source/include/FreeRTOS.h:

../FreeRTOS/Demo/FreeRTOSConfig.h:

../FreeRTOS/Source/include/projdefs.h:

../FreeRTOS/Source/include/portable.h:

../FreeRTOS/Source/include/deprecated_definitions.h:

../FreeRTOS/Source/portable/GCC/SAMV71/portmacro.h:

../FreeRTOS/Source/include/mpu_wrappers.h:

../FreeRTOS/Source/include/task.h:

../FreeRTOS/Source/include/list.h:

../BSP/Proj_Config.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stdbool.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\stdio.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stdarg.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\types.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\types.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\stdio.h:

../Fatfs/libstoragemedia/include/sdmmc/libsdmmc.h:

../Fatfs/libstoragemedia/include/sdmmc/sdmmc_cmd.h:

../Fatfs/libstoragemedia/include/sdmmc/sdmmc.h:

../Fatfs/libstoragemedia/include/sdmmc/sdmmc_hal.h:

../BSP/compiler.h:

../BSP/include/same70/include/same70.h:

../BSP/include/same70/include/same70n20.h:

../BSP/include/cmsis/CMSIS/Include/core_cm7.h:

../BSP/include/cmsis/CMSIS/Include/core_cmInstr.h:

../BSP/include/cmsis/CMSIS/Include/core_cmFunc.h:

../BSP/include/cmsis/CMSIS/Include/core_cmSimd.h:

../BSP/include/same70/include/system_same70.h:

../BSP/include/same70/include/component/acc.h:

../BSP/include/same70/include/component/aes.h:

../BSP/include/same70/include/component/afec.h:

../BSP/include/same70/include/component/chipid.h:

../BSP/include/same70/include/component/dacc.h:

../BSP/include/same70/include/component/efc.h:

../BSP/include/same70/include/component/gmac.h:

../BSP/include/same70/include/component/gpbr.h:

../BSP/include/same70/include/component/hsmci.h:

../BSP/include/same70/include/component/icm.h:

../BSP/include/same70/include/component/isi.h:

../BSP/include/same70/include/component/matrix.h:

../BSP/include/same70/include/component/mcan.h:

../BSP/include/same70/include/component/pio.h:

../BSP/include/same70/include/component/pmc.h:

../BSP/include/same70/include/component/pwm.h:

../BSP/include/same70/include/component/qspi.h:

../BSP/include/same70/include/component/rstc.h:

../BSP/include/same70/include/component/rswdt.h:

../BSP/include/same70/include/component/rtc.h:

../BSP/include/same70/include/component/rtt.h:

../BSP/include/same70/include/component/spi.h:

../BSP/include/same70/include/component/ssc.h:

../BSP/include/same70/include/component/supc.h:

../BSP/include/same70/include/component/tc.h:

../BSP/include/same70/include/component/trng.h:

../BSP/include/same70/include/component/twihs.h:

../BSP/include/same70/include/component/uart.h:

../BSP/include/same70/include/component/usart.h:

../BSP/include/same70/include/component/usbhs.h:

../BSP/include/same70/include/component/utmi.h:

../BSP/include/same70/include/component/wdt.h:

../BSP/include/same70/include/component/xdmac.h:

../BSP/include/same70/include/instance/hsmci.h:

../BSP/include/same70/include/instance/ssc.h:

../BSP/include/same70/include/instance/spi0.h:

../BSP/include/same70/include/instance/tc0.h:

../BSP/include/same70/include/instance/twihs0.h:

../BSP/include/same70/include/instance/twihs1.h:

../BSP/include/same70/include/instance/pwm0.h:

../BSP/include/same70/include/instance/usart0.h:

../BSP/include/same70/include/instance/usart1.h:

../BSP/include/same70/include/instance/usart2.h:

../BSP/include/same70/include/instance/mcan0.h:

../BSP/include/same70/include/instance/mcan1.h:

../BSP/include/same70/include/instance/usbhs.h:

../BSP/include/same70/include/instance/afec0.h:

../BSP/include/same70/include/instance/dacc.h:

../BSP/include/same70/include/instance/acc.h:

../BSP/include/same70/include/instance/icm.h:

../BSP/include/same70/include/instance/isi.h:

../BSP/include/same70/include/instance/gmac.h:

../BSP/include/same70/include/instance/tc3.h:

../BSP/include/same70/include/instance/spi1.h:

../BSP/include/same70/include/instance/pwm1.h:

../BSP/include/same70/include/instance/twihs2.h:

../BSP/include/same70/include/instance/afec1.h:

../BSP/include/same70/include/instance/aes.h:

../BSP/include/same70/include/instance/trng.h:

../BSP/include/same70/include/instance/xdmac.h:

../BSP/include/same70/include/instance/qspi.h:

../BSP/include/same70/include/instance/matrix.h:

../BSP/include/same70/include/instance/utmi.h:

../BSP/include/same70/include/instance/pmc.h:

../BSP/include/same70/include/instance/uart0.h:

../BSP/include/same70/include/instance/chipid.h:

../BSP/include/same70/include/instance/uart1.h:

../BSP/include/same70/include/instance/efc.h:

../BSP/include/same70/include/instance/pioa.h:

../BSP/include/same70/include/instance/piob.h:

../BSP/include/same70/include/instance/piod.h:

../BSP/include/same70/include/instance/rstc.h:

../BSP/include/same70/include/instance/supc.h:

../BSP/include/same70/include/instance/rtt.h:

../BSP/include/same70/include/instance/wdt.h:

../BSP/include/same70/include/instance/rtc.h:

../BSP/include/same70/include/instance/gpbr.h:

../BSP/include/same70/include/instance/rswdt.h:

../BSP/include/same70/include/instance/uart2.h:

../BSP/include/same70/include/instance/uart3.h:

../BSP/include/same70/include/instance/uart4.h:

../BSP/include/same70/include/pio/same70n20.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\stdlib.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\stdlib.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\alloca.h:

../Fatfs/libstoragemedia/include/sdmmc/sdio.h:

../Fatfs/libstoragemedia/include/sdmmc/sdmmc_trace.h:

../Application/include/time_stamps.h:
