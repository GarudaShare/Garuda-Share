BSP/src/USBDCallbacks_Resumed.d BSP/src/USBDCallbacks_Resumed.o: \
 ../BSP/src/USBDCallbacks_Resumed.c
