BSP/src/USBDCallbacks_Suspended.d BSP/src/USBDCallbacks_Suspended.o: \
 ../BSP/src/USBDCallbacks_Suspended.c
