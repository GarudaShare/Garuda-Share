BSP/src/HIDIdleRequest.d BSP/src/HIDIdleRequest.o: \
 ../BSP/src/HIDIdleRequest.c ../BSP/HIDRequests.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stdint.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\stdint.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\_default_types.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\features.h \
 ../BSP/include/USBRequests.h

../BSP/HIDRequests.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stdint.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\stdint.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\_default_types.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\features.h:

../BSP/include/USBRequests.h:
