FreeRTOS/Source/croutine.d FreeRTOS/Source/croutine.o: \
 ../FreeRTOS/Source/croutine.c ../FreeRTOS/Source/include/FreeRTOS.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stddef.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stdint.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\stdint.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\_default_types.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\features.h \
 ../FreeRTOS/Demo/FreeRTOSConfig.h ../FreeRTOS/Source/include/projdefs.h \
 ../FreeRTOS/Source/include/portable.h \
 ../FreeRTOS/Source/include/deprecated_definitions.h \
 ../FreeRTOS/Source/portable/GCC/SAMV71/portmacro.h \
 ../FreeRTOS/Source/include/mpu_wrappers.h \
 ../FreeRTOS/Source/include/task.h ../FreeRTOS/Source/include/list.h \
 ../FreeRTOS/Source/include/croutine.h

../FreeRTOS/Source/include/FreeRTOS.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stddef.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stdint.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\stdint.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\_default_types.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\features.h:

../FreeRTOS/Demo/FreeRTOSConfig.h:

../FreeRTOS/Source/include/projdefs.h:

../FreeRTOS/Source/include/portable.h:

../FreeRTOS/Source/include/deprecated_definitions.h:

../FreeRTOS/Source/portable/GCC/SAMV71/portmacro.h:

../FreeRTOS/Source/include/mpu_wrappers.h:

../FreeRTOS/Source/include/task.h:

../FreeRTOS/Source/include/list.h:

../FreeRTOS/Source/include/croutine.h:
