FreeRTOS/Source/list.d FreeRTOS/Source/list.o: ../FreeRTOS/Source/list.c \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\stdlib.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\ieeefp.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\_ansi.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\newlib.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\config.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\features.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stddef.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\reent.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\_ansi.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\_types.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\_types.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\_default_types.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\lock.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\stdlib.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\alloca.h \
 ../FreeRTOS/Source/include/FreeRTOS.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stdint.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\stdint.h \
 ../FreeRTOS/Demo/FreeRTOSConfig.h ../FreeRTOS/Source/include/projdefs.h \
 ../FreeRTOS/Source/include/portable.h \
 ../FreeRTOS/Source/include/deprecated_definitions.h \
 ../FreeRTOS/Source/portable/GCC/SAMV71/portmacro.h \
 ../FreeRTOS/Source/include/mpu_wrappers.h \
 ../FreeRTOS/Source/include/list.h

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\stdlib.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\ieeefp.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\_ansi.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\newlib.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\config.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\features.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stddef.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\reent.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\_ansi.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\_types.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\_types.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\_default_types.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\lock.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\stdlib.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\alloca.h:

../FreeRTOS/Source/include/FreeRTOS.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stdint.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\stdint.h:

../FreeRTOS/Demo/FreeRTOSConfig.h:

../FreeRTOS/Source/include/projdefs.h:

../FreeRTOS/Source/include/portable.h:

../FreeRTOS/Source/include/deprecated_definitions.h:

../FreeRTOS/Source/portable/GCC/SAMV71/portmacro.h:

../FreeRTOS/Source/include/mpu_wrappers.h:

../FreeRTOS/Source/include/list.h:
