Board/src/startup_same70.d Board/src/startup_same70.o: \
 ../Board/src/startup_same70.c \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/same70.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/same70n20.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stdint.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\stdint.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\_default_types.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\features.h \
 ../BSP/include/cmsis/CMSIS/Include/core_cm7.h \
 ../BSP/include/cmsis/CMSIS/Include/core_cmInstr.h \
 ../BSP/include/cmsis/CMSIS/Include/core_cmFunc.h \
 ../BSP/include/cmsis/CMSIS/Include/core_cmSimd.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/system_same70.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/acc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/aes.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/afec.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/chipid.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/dacc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/efc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/gmac.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/gpbr.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/hsmci.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/icm.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/isi.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/matrix.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/mcan.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/pio.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/pmc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/pwm.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/qspi.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/rstc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/rswdt.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/rtc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/rtt.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/spi.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/ssc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/supc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/tc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/trng.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/twihs.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/uart.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/usart.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/usbhs.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/utmi.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/wdt.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/xdmac.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/hsmci.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/ssc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/spi0.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/tc0.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/twihs0.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/twihs1.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/pwm0.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/usart0.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/usart1.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/usart2.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/mcan0.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/mcan1.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/usbhs.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/afec0.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/dacc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/acc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/icm.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/isi.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/gmac.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/tc3.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/spi1.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/pwm1.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/twihs2.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/afec1.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/aes.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/trng.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/xdmac.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/qspi.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/matrix.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/utmi.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/pmc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/uart0.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/chipid.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/uart1.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/efc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/pioa.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/piob.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/piod.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/rstc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/supc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/rtt.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/wdt.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/rtc.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/gpbr.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/rswdt.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/uart2.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/uart3.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/uart4.h \
 C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/pio/same70n20.h

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/same70.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/same70n20.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\lib\gcc\arm-none-eabi\4.8.4\include\stdint.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\stdint.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\machine\_default_types.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\arm\garuda_toolchain\arm-none-eabi\include\sys\features.h:

../BSP/include/cmsis/CMSIS/Include/core_cm7.h:

../BSP/include/cmsis/CMSIS/Include/core_cmInstr.h:

../BSP/include/cmsis/CMSIS/Include/core_cmFunc.h:

../BSP/include/cmsis/CMSIS/Include/core_cmSimd.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/system_same70.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/acc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/aes.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/afec.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/chipid.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/dacc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/efc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/gmac.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/gpbr.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/hsmci.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/icm.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/isi.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/matrix.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/mcan.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/pio.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/pmc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/pwm.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/qspi.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/rstc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/rswdt.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/rtc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/rtt.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/spi.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/ssc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/supc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/tc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/trng.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/twihs.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/uart.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/usart.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/usbhs.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/utmi.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/wdt.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/component/xdmac.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/hsmci.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/ssc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/spi0.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/tc0.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/twihs0.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/twihs1.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/pwm0.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/usart0.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/usart1.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/usart2.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/mcan0.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/mcan1.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/usbhs.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/afec0.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/dacc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/acc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/icm.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/isi.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/gmac.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/tc3.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/spi1.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/pwm1.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/twihs2.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/afec1.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/aes.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/trng.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/xdmac.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/qspi.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/matrix.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/utmi.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/pmc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/uart0.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/chipid.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/uart1.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/efc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/pioa.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/piob.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/piod.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/rstc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/supc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/rtt.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/wdt.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/rtc.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/gpbr.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/rswdt.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/uart2.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/uart3.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/instance/uart4.h:

C:\PROGRA~2\Atmel\ATMELT~1\ARMGCC~1\Native\4804F3~1.144\CMSIS_~1\Device\ATMEL\same70\include/pio/same70n20.h:
