/* ----------------------------------------------------------------------------
 *         SAM Software Package License 
 * ----------------------------------------------------------------------------
 * Copyright (c) 2012, Atmel Corporation
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the disclaimer below.
 *
 * Atmel's name may not be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * DISCLAIMER: THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ----------------------------------------------------------------------------
 */

/** \file
 * Declaration of the descriptors used by the HID device Transfer driver.
 */

/** \addtogroup usbd_hid_tran
 *@{
 */

/*------------------------------------------------------------------------------
 *         Headers
 *------------------------------------------------------------------------------*/

#include "board.h"
#include "include/USBD_Config.h"

#include "HIDDTransferDriver.h"
#include "HIDReports.h"
#include "MSDDriver.h"
#include "MSDescriptors.h"
#include "HFCP.h"
/*------------------------------------------------------------------------------
 *         Definitions
 *------------------------------------------------------------------------------*/

/** \addtogroup usbd_hid_trans_device_descriptor_ids HID Transfer Device Descriptor IDs
 *      @{
 *
 * \section IDs
 * - HIDDTransferDriverDescriptors_PRODUCTID
 * - HIDDTransferDriverDescriptors_VENDORID
 * - HIDDTransferDriverDescriptors_RELEASE
 */

/** Device product ID. */
#define HIDDTransferDriverDescriptors_PRODUCTID     0x5743 //0x5741
/** Device vendor ID. */
#define HIDDTransferDriverDescriptors_VENDORID      0x03EB //0x0471
/** Device release number. */
#define HIDDTransferDriverDescriptors_RELEASE       0x0100
/**      @}*/

/** Vendor ID for the Mass Storage device driver. */
#define MSDDriverDescriptors_VENDORID       USBD_VID_ATMEL
/** Product ID for the Mass Storage device driver. */
#define MSDDriverDescriptors_PRODUCTID      USBD_PID_MSD
/** Device release number for the Mass Storage device driver. */
#define MSDDriverDescriptors_RELEASE        USBD_RELEASE_1_00
/*------------------------------------------------------------------------------
 *         Macros
 *------------------------------------------------------------------------------*/

/** Returns the minimum between two values. */
#define MIN(a, b)       ((a < b) ? a : b)

/*------------------------------------------------------------------------------
 *         Internal types
 *------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------
 *         Internal variables
 *------------------------------------------------------------------------------*/
#if 1//USB_MSD

/** Mass storage driver device descriptor. */
static const USBDeviceDescriptor MSDdeviceDescriptor = {

    sizeof(USBDeviceDescriptor),
    USBGenericDescriptor_DEVICE,
    USBDeviceDescriptor_USB2_00,
    MSDeviceDescriptor_CLASS,
    MSDeviceDescriptor_SUBCLASS,
    MSDeviceDescriptor_PROTOCOL,
    CHIP_USB_ENDPOINTS_MAXPACKETSIZE(0),
    MSDDriverDescriptors_VENDORID,
    MSDDriverDescriptors_PRODUCTID,
    MSDDriverDescriptors_RELEASE,
    1, /* Manufacturer string descriptor index. */
    2, /* Product string descriptor index. */
    3, /* Serial number string descriptor index. */
    1  /* Device has one possible configuration. */
};

/** Device qualifier descriptor (Necessary to pass USB test). */
static const USBDeviceQualifierDescriptor qualifierDescriptor = {

    sizeof(USBDeviceQualifierDescriptor),
    USBGenericDescriptor_DEVICEQUALIFIER,
    USBDeviceDescriptor_USB2_00,
    MSDeviceDescriptor_CLASS,
    MSDeviceDescriptor_SUBCLASS,
    MSDeviceDescriptor_PROTOCOL,
    CHIP_USB_ENDPOINTS_MAXPACKETSIZE(0),
    1, // Device has one possible configuration.
    0x00
};

/** Full-speed configuration descriptor. */
static const MSDConfigurationDescriptors configurationDescriptorsFS = {

    /* Standard configuration descriptor. */
    {
        sizeof(USBConfigurationDescriptor),
        USBGenericDescriptor_CONFIGURATION,
        sizeof(MSDConfigurationDescriptors),
        1, /* Configuration has one interface. */
        1, /* This is configuration #1. */
        0, /* No string descriptor for configuration. */
        USBD_BMATTRIBUTES,
        USBConfigurationDescriptor_POWER(100)
    },
    /* Mass Storage interface descriptor. */
    {
        sizeof(USBInterfaceDescriptor),
        USBGenericDescriptor_INTERFACE,
        0, /* This is interface #0. */
        0, /* This is alternate setting #0. */
        2, /* Interface uses two endpoints. */
        MSInterfaceDescriptor_CLASS,
        MSInterfaceDescriptor_SCSI,
        MSInterfaceDescriptor_BULKONLY,
        0 /* No string descriptor for interface. */
    },
    /* Bulk-OUT endpoint descriptor */
    {
        sizeof(USBEndpointDescriptor),
        USBGenericDescriptor_ENDPOINT,
        USBEndpointDescriptor_ADDRESS(
        USBEndpointDescriptor_OUT,
        MSDDriverDescriptors_BULKOUT),
        USBEndpointDescriptor_BULK,
        MIN(CHIP_USB_ENDPOINTS_MAXPACKETSIZE(MSDDriverDescriptors_BULKOUT),
        USBEndpointDescriptor_MAXBULKSIZE_FS),
        0 /* Must be 0 for full-speed Bulk endpoints. */
    },
    /* Bulk-IN endpoint descriptor */
    {
        sizeof(USBEndpointDescriptor),
        USBGenericDescriptor_ENDPOINT,
        USBEndpointDescriptor_ADDRESS(
        USBEndpointDescriptor_IN,
        MSDDriverDescriptors_BULKIN),
        USBEndpointDescriptor_BULK,
        MIN(CHIP_USB_ENDPOINTS_MAXPACKETSIZE(MSDDriverDescriptors_BULKIN),
        USBEndpointDescriptor_MAXBULKSIZE_FS),
        0 /* Must be 0 for full-speed Bulk endpoints. */

    }
};

/** Full-speed other speed configuration descriptor. */
static const MSDConfigurationDescriptors otherSpeedDescriptorsFS = {

    /* Standard configuration descriptor. */
    {
        sizeof(USBConfigurationDescriptor),
        USBGenericDescriptor_OTHERSPEEDCONFIGURATION,
        sizeof(MSDConfigurationDescriptors),
        1, /* Configuration has one interface. */
        1, /* This is configuration #1. */
        0, /* No string descriptor for configuration. */
        BOARD_USB_BMATTRIBUTES,
        USBConfigurationDescriptor_POWER(100)
    },
    /* Mass Storage interface descriptor. */
    {
        sizeof(USBInterfaceDescriptor),
        USBGenericDescriptor_INTERFACE,
        0, /* This is interface #0. */
        0, /* This is alternate setting #0. */
        2, /* Interface uses two endpoints. */
        MSInterfaceDescriptor_CLASS,
        MSInterfaceDescriptor_SCSI,
        MSInterfaceDescriptor_BULKONLY,
        0 /* No string descriptor for interface. */
    },
    /* Bulk-OUT endpoint descriptor */
    {
        sizeof(USBEndpointDescriptor),
        USBGenericDescriptor_ENDPOINT,
        USBEndpointDescriptor_ADDRESS(
        USBEndpointDescriptor_OUT,
        MSDDriverDescriptors_BULKOUT),
        USBEndpointDescriptor_BULK,
        MIN(CHIP_USB_ENDPOINTS_MAXPACKETSIZE(MSDDriverDescriptors_BULKOUT),
        USBEndpointDescriptor_MAXBULKSIZE_HS),
        0 /* No string descriptor for endpoint. */
    },
    /* Bulk-IN endpoint descriptor */
    {
        sizeof(USBEndpointDescriptor),
        USBGenericDescriptor_ENDPOINT,
        USBEndpointDescriptor_ADDRESS(
        USBEndpointDescriptor_IN,
        MSDDriverDescriptors_BULKIN),
        USBEndpointDescriptor_BULK,
        MIN(CHIP_USB_ENDPOINTS_MAXPACKETSIZE(MSDDriverDescriptors_BULKIN),
        USBEndpointDescriptor_MAXBULKSIZE_HS),
        0 /* No string descriptor for endpoint. */
    }
};

/** High-speed configuration descriptor. */
static const MSDConfigurationDescriptors configurationDescriptorsHS = {

    /* Standard configuration descriptor. */
    {
        sizeof(USBConfigurationDescriptor),
        USBGenericDescriptor_CONFIGURATION,
        sizeof(MSDConfigurationDescriptors),
        1, /* Configuration has one interface. */
        1, /* This is configuration #1. */
        0, /* No string descriptor for configuration. */
        BOARD_USB_BMATTRIBUTES,
        USBConfigurationDescriptor_POWER(100)
    },
    /* Mass Storage interface descriptor. */
    {
        sizeof(USBInterfaceDescriptor),
        USBGenericDescriptor_INTERFACE,
        0, /* This is interface #0. */
        0, /* This is alternate setting #0. */
        2, /* Interface uses two endpoints. */
        MSInterfaceDescriptor_CLASS,
        MSInterfaceDescriptor_SCSI,
        MSInterfaceDescriptor_BULKONLY,
        0 /* No string descriptor for interface. */
    },
    /* Bulk-OUT endpoint descriptor */
    {
        sizeof(USBEndpointDescriptor),
        USBGenericDescriptor_ENDPOINT,
        USBEndpointDescriptor_ADDRESS(
        USBEndpointDescriptor_OUT,
        MSDDriverDescriptors_BULKOUT),
        USBEndpointDescriptor_BULK,
        MIN(CHIP_USB_ENDPOINTS_MAXPACKETSIZE(MSDDriverDescriptors_BULKOUT),
        USBEndpointDescriptor_MAXBULKSIZE_HS),
        0 /* No string descriptor for endpoint. */
    },
    /* Bulk-IN endpoint descriptor */
    {
        sizeof(USBEndpointDescriptor),
        USBGenericDescriptor_ENDPOINT,
        USBEndpointDescriptor_ADDRESS(
        USBEndpointDescriptor_IN,
        MSDDriverDescriptors_BULKIN),
        USBEndpointDescriptor_BULK,
        MIN(CHIP_USB_ENDPOINTS_MAXPACKETSIZE(MSDDriverDescriptors_BULKIN),
        USBEndpointDescriptor_MAXBULKSIZE_HS),
        0 /* No string descriptor for endpoint. */
    }
};

/** High-speed other speed configuration descriptor. */
static const MSDConfigurationDescriptors otherSpeedDescriptorsHS = {

    /* Standard configuration descriptor. */
    {
        sizeof(USBConfigurationDescriptor),
        USBGenericDescriptor_OTHERSPEEDCONFIGURATION,
        sizeof(MSDConfigurationDescriptors),
        1, /* Configuration has one interface. */
        1, /* This is configuration #1. */
        0, /* No string descriptor for configuration. */
        BOARD_USB_BMATTRIBUTES,
        USBConfigurationDescriptor_POWER(100)
    },
    /* Mass Storage interface descriptor. */
    {
        sizeof(USBInterfaceDescriptor),
        USBGenericDescriptor_INTERFACE,
        0, /* This is interface #0. */
        0, /* This is alternate setting #0. */
        2, /* Interface uses two endpoints. */
        MSInterfaceDescriptor_CLASS,
        MSInterfaceDescriptor_SCSI,
        MSInterfaceDescriptor_BULKONLY,
        0 /* No string descriptor for interface. */
    },
    /* Bulk-OUT endpoint descriptor */
    {
        sizeof(USBEndpointDescriptor),
        USBGenericDescriptor_ENDPOINT,
        USBEndpointDescriptor_ADDRESS(
        USBEndpointDescriptor_OUT,
        MSDDriverDescriptors_BULKOUT),
        USBEndpointDescriptor_BULK,
        MIN(CHIP_USB_ENDPOINTS_MAXPACKETSIZE(MSDDriverDescriptors_BULKOUT),
        USBEndpointDescriptor_MAXBULKSIZE_FS),
        0 /* No string descriptor for endpoint. */
    },
    /* Bulk-IN endpoint descriptor */
    {
        sizeof(USBEndpointDescriptor),
        USBGenericDescriptor_ENDPOINT,
        USBEndpointDescriptor_ADDRESS(
        USBEndpointDescriptor_IN,
        MSDDriverDescriptors_BULKIN),
        USBEndpointDescriptor_BULK,
        MIN(CHIP_USB_ENDPOINTS_MAXPACKETSIZE(MSDDriverDescriptors_BULKIN),
        USBEndpointDescriptor_MAXBULKSIZE_FS),
        0 /* No string descriptor for endpoint. */
    }
};

/** Language ID string descriptor. */
static const unsigned char languageIdDescriptor[] = {

    USBStringDescriptor_LENGTH(1),
    USBGenericDescriptor_STRING,
    USBStringDescriptor_ENGLISH_US
};

/** Manufacturer string descriptor. */
static const unsigned char manufacturerDescriptor[] = {

    USBStringDescriptor_LENGTH(5),
    USBGenericDescriptor_STRING,
    USBStringDescriptor_UNICODE('A'),
    USBStringDescriptor_UNICODE('T'),
    USBStringDescriptor_UNICODE('M'),
    USBStringDescriptor_UNICODE('E'),
    USBStringDescriptor_UNICODE('L')
};

/** Product string descriptor. */
static const unsigned char MSDproductDescriptor[] = {

    USBStringDescriptor_LENGTH(14),
    USBGenericDescriptor_STRING,
    USBStringDescriptor_UNICODE('A'),
    USBStringDescriptor_UNICODE('T'),
    USBStringDescriptor_UNICODE('M'),
    USBStringDescriptor_UNICODE('E'),
    USBStringDescriptor_UNICODE('L'),
    USBStringDescriptor_UNICODE(' '),
    USBStringDescriptor_UNICODE('A'),
    USBStringDescriptor_UNICODE('T'),
    USBStringDescriptor_UNICODE('9'),
    USBStringDescriptor_UNICODE('1'),
    USBStringDescriptor_UNICODE(' '),
    USBStringDescriptor_UNICODE('M'),
    USBStringDescriptor_UNICODE('S'),
    USBStringDescriptor_UNICODE('D')
};

/** Serial number string descriptor. The serial number must be at least 12 */
/** characters long and made up of only letters & numbers to be compliant with */
/** the MSD specification. */
static const unsigned char MSDserialNumberDescriptor[] = {

    USBStringDescriptor_LENGTH(12),
    USBGenericDescriptor_STRING,
    USBStringDescriptor_UNICODE('0'),
    USBStringDescriptor_UNICODE('1'),
    USBStringDescriptor_UNICODE('2'),
    USBStringDescriptor_UNICODE('3'),
    USBStringDescriptor_UNICODE('4'),
    USBStringDescriptor_UNICODE('5'),
    USBStringDescriptor_UNICODE('6'),
    USBStringDescriptor_UNICODE('7'),
    USBStringDescriptor_UNICODE('8'),
    USBStringDescriptor_UNICODE('9'),
    USBStringDescriptor_UNICODE('A'),
    USBStringDescriptor_UNICODE('B')
};

/** List of all string descriptors used. */
static const unsigned char *MSDstringDescriptors[] = {

    languageIdDescriptor,
    manufacturerDescriptor,
    MSDproductDescriptor,
    MSDserialNumberDescriptor
};

/*--------------------------------------------------------------------------- */
/*         Global variables */
/*--------------------------------------------------------------------------- */


/** List of the standard descriptors used by the Mass Storage driver. */
const USBDDriverDescriptors msdDriverDescriptors = {

    &MSDdeviceDescriptor,
    (USBConfigurationDescriptor *) &configurationDescriptorsFS,
    &qualifierDescriptor,
    (USBConfigurationDescriptor *) &otherSpeedDescriptorsFS,
    0, /* No high-speed device descriptor (uses FS one) */
    (USBConfigurationDescriptor *) &configurationDescriptorsHS,
    &qualifierDescriptor,
    (USBConfigurationDescriptor *) &otherSpeedDescriptorsHS,
    MSDstringDescriptors,
    4 /* Four string descriptors in array */
};

#endif


#if 1//USB_HID_TRANSFER 
/** Device descriptor. */
static const USBDeviceDescriptor deviceDescriptor = {

    sizeof(USBDeviceDescriptor),
    USBGenericDescriptor_DEVICE,
    USBDeviceDescriptor_USB2_00,
    0xef,
    0x02,
    0x01,
    64,
    HIDDTransferDriverDescriptors_VENDORID,
    HIDDTransferDriverDescriptors_PRODUCTID,
    HIDDTransferDriverDescriptors_RELEASE,
    1, /* Index of manufacturer description */
    2, /* Index of product description */
    3, /* Index of serial number description */
    1  /* One possible configuration */
};

extern const uint8_t HID_ReportDescriptor[];

/** Configuration descriptor. */
static const HIDDTransferDriverConfigurationDescriptors configurationDescriptors = {

	/* Configuration descriptor */

	{
		sizeof(USBConfigurationDescriptor),
		USBGenericDescriptor_CONFIGURATION,
		sizeof(HIDDTransferDriverConfigurationDescriptors),
		1, /* One interface in this configuration */
		1, /* This is configuration #1 */
		0, /* No associated string descriptor */
		0x80,
		USBConfigurationDescriptor_POWER(100)
	},
	/* Interface descriptor */

	{
		sizeof(USBInterfaceDescriptor),
		USBGenericDescriptor_INTERFACE,
		0, /* This is interface #0 */
		0, /* This is alternate setting #0 */
		2, /* Two endpoints used */
		HIDInterfaceDescriptor_CLASS,
		0xff,
		0xff,
		0  /* No associated string descriptor */

	},
	/* HID descriptor */

	{
		sizeof(HIDDescriptor1),
		HIDGenericDescriptor_HID,
		HIDDescriptor_HID1_11,
		0, /* Device is not localized, no country code */
		1, /* One HID-specific descriptor (apart from this one) */
		HIDGenericDescriptor_REPORT,
		{HIDDTransferDriver_REPORTDESCRIPTORSIZE}
	},
	/* Interrupt IN endpoint descriptor */

	{
		sizeof(USBEndpointDescriptor),
		USBGenericDescriptor_ENDPOINT,
		0x84,
		USBEndpointDescriptor_INTERRUPT,
		0x40,
		0x01
	},
	/* Interrupt OUT endpoint descriptor */

	{
		sizeof(USBEndpointDescriptor),
		USBGenericDescriptor_ENDPOINT,
		0x01,
		USBEndpointDescriptor_INTERRUPT,
		0x40,
		0x01
	}
};

#if 0
/**
 *  Variables: String descriptors
 *      languageIdDescriptor - Language ID string descriptor.
 *      manufacturerDescriptor - Manufacturer name.
 *      productDescriptor - Product name.
 *      serialNumberDescriptor - Product serial number.
 *      stringDescriptors - Array of pointers to string descriptors.
 */
static const unsigned char languageIdDescriptor[] = {

    USBStringDescriptor_LENGTH(1),
    USBGenericDescriptor_STRING,
    USBStringDescriptor_ENGLISH_US
};

static const unsigned char manufacturerDescriptor[] = {

    USBStringDescriptor_LENGTH(5),
    USBGenericDescriptor_STRING,
    USBStringDescriptor_UNICODE('A'),
    USBStringDescriptor_UNICODE('T'),
    USBStringDescriptor_UNICODE('M'),
    USBStringDescriptor_UNICODE('E'),
    USBStringDescriptor_UNICODE('L')
};
#endif

static const unsigned char productDescriptor[] = {

    USBStringDescriptor_LENGTH(22),
    USBGenericDescriptor_STRING,
    USBStringDescriptor_UNICODE('A'),
    USBStringDescriptor_UNICODE('T'),
    USBStringDescriptor_UNICODE('M'),
    USBStringDescriptor_UNICODE('E'),
    USBStringDescriptor_UNICODE('L'),
    USBStringDescriptor_UNICODE(' '),
    USBStringDescriptor_UNICODE('A'),
    USBStringDescriptor_UNICODE('T'),
    USBStringDescriptor_UNICODE('9'),
    USBStringDescriptor_UNICODE('1'),
    USBStringDescriptor_UNICODE(' '),
    USBStringDescriptor_UNICODE('H'),
    USBStringDescriptor_UNICODE('I'),
    USBStringDescriptor_UNICODE('D'),
    USBStringDescriptor_UNICODE(' '),
    USBStringDescriptor_UNICODE('T'),
    USBStringDescriptor_UNICODE('R'),
    USBStringDescriptor_UNICODE('A'),
    USBStringDescriptor_UNICODE('N'),
    USBStringDescriptor_UNICODE('S'),
    USBStringDescriptor_UNICODE('F'),
    USBStringDescriptor_UNICODE('E'),
    USBStringDescriptor_UNICODE('R'),
};

static const unsigned char serialNumberDescriptor[] = {

    USBStringDescriptor_LENGTH(12),
    USBGenericDescriptor_STRING,
    USBStringDescriptor_UNICODE('0'),
    USBStringDescriptor_UNICODE('1'),
    USBStringDescriptor_UNICODE('2'),
    USBStringDescriptor_UNICODE('3'),
    USBStringDescriptor_UNICODE('4'),
    USBStringDescriptor_UNICODE('5'),
    USBStringDescriptor_UNICODE('6'),
    USBStringDescriptor_UNICODE('7'),
    USBStringDescriptor_UNICODE('8'),
    USBStringDescriptor_UNICODE('9'),
    USBStringDescriptor_UNICODE('A'),
    USBStringDescriptor_UNICODE('F')
};

static const unsigned char *stringDescriptors[] = {

    languageIdDescriptor,
    manufacturerDescriptor,
    productDescriptor,
    serialNumberDescriptor
};

/*------------------------------------------------------------------------------
 *         Exported variables
 *------------------------------------------------------------------------------*/

/** List of descriptors used by the HID Transfer driver. */
USBDDriverDescriptors hiddTransferDriverDescriptors = {

    &deviceDescriptor,
    (USBConfigurationDescriptor *) &configurationDescriptors,
    0, /* No full-speed device qualifier descriptor */
    0, /* No full-speed other speed configuration */
    0, /* No high-speed device descriptor */
    0, /* No high-speed configuration descriptor */
    0, /* No high-speed device qualifier descriptor */
    0, /* No high-speed other speed configuration descriptor */
    stringDescriptors,
    4 /* Four string descriptors in list */
};


extern uint8_t USB_Device_Mode;

#if 1
/**
 *  Invoked whenever a SETUP request is received from the host. Forwards the
 *  request to the standard handler.
 */
void USBDCallbacks_RequestReceived(const USBGenericRequest *request)
{
	//HIDDTransferDriver_RequestHandler(request);
    if(HID == USB_Device_Mode){
        HIDDTransferDriver_RequestHandler(request);
    }
    else if(MSD == USB_Device_Mode){
        MSDDriver_RequestHandler(request);
    }
    else
    {
        
    }
}

/**
 * Invoked when the configuration of the device changes. Start reading
 * output reports.
 * \param cfgnum New configuration number.
 */
void USBDDriverCallbacks_ConfigurationChanged(uint8_t cfgnum)
{
	//HIDDTransferDriver_ConfigurationChangedHandler(cfgnum);
	
    if(HID == USB_Device_Mode){
        HIDDTransferDriver_ConfigurationChangedHandler(cfgnum);
    }
    else if(MSD == USB_Device_Mode){        
        MSDDriver_ConfigurationChangeHandler(cfgnum);
    }
    else
    {
        
    }       
}


#endif
#endif
/**@}*/
