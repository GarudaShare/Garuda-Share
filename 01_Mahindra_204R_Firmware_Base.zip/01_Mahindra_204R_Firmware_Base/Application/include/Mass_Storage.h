/******************************************************************************
*
* Copyright                                                  Template Version
* 2007 Dearborn Electronics India                            <Ver # from PG>
* an unpublished work. All Rights Reserved.
*
* The information contained herein is confidential property of Dearborn
* Electronics. The use, copying, transfer or disclosure of such information is
* prohibited except by express written agreement with Dearborn Electronics.
*
* Mass_Storage.h
*
* Created: 11/23/2015 12:14:38 PM
*  Author: amit
*******************************************************************************/

/******************************************************************************
* P U R P O S E: This module implements Mass Storage MAnagement interface
*******************************************************************************/
#ifndef MASS_STORAGE_H_
#define MASS_STORAGE_H_

/******************************************************************************
*                    I N C L U D E   F I L E S
*******************************************************************************/

/******************************************************************************
*               E X P O R T E D   D E F I N I T I O N S
*******************************************************************************/

/******************************************************************************
*                   E X P O R T E D   V A R I A B L E S
*******************************************************************************/

/******************************************************************************
*           E X P O R T E D   F U N C T I O N    P R O T O T Y P E S
*******************************************************************************/
void MassStorageFreeRTOS_Init(void);
void MSD_Management_Task(void *PvParam);

#endif /* MASS_STORAGE_H_ */

/******************************************************************************
* R E V I S I O N   H I S T O R Y
* $History: $
* Version      Author                          Date
******************************************************************************
* 2.0          Amit Gudigar                      11/23/2015 12:14:38 PM
* Initial version.
*
******************************************************************************/