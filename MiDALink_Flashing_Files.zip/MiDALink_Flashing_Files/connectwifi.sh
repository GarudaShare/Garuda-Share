#!/bin/sh
CONFIG_FILE="/etc/g3-wlan.config"

MODE="$1"
SSID="$2"
PASS="$3"

if [ -z "$MODE" ]; then
    echo "Usage:"
    echo "  $0 AP"
    echo "  $0 STA <SSID> <PASSWORD>"
    exit 1
fi

if [ "$MODE" = "AP" ]; then
    echo "[INFO] Switching to AP mode..."

    sed -i 's/^WLAN_MODE=.*/WLAN_MODE="AP"/' $CONFIG_FILE

elif [ "$MODE" = "STA" ]; then
    if [ -z "$SSID" ] || [ -z "$PASS" ]; then
        echo "[ERROR] STA mode requires SSID and PASSWORD"
        exit 1
    fi  

    echo "[INFO] Switching to STA mode..."
    echo "[INFO] SSID: $SSID"

    sed -i 's/^WLAN_MODE=.*/WLAN_MODE="STA"/' $CONFIG_FILE
    sed -i "s/^WLAN_STA_WPA_SSID=.*/WLAN_STA_WPA_SSID=\"$SSID\"/" $CONFIG_FILE
    sed -i "s/^WLAN_STA_WPA_PASSPHRASE=.*/WLAN_STA_WPA_PASSPHRASE=\"$PASS\"/" $CONFIG_FILE

else
    echo "[ERROR] Invalid mode. Use AP or STA"
    exit 1
fi

echo "[INFO] Config updated successfully!"


# Verify connectivity
    if ping -c 2 google.com >/dev/null 2>&1; then
        echo "[INFO] Network reachable, logging to DB..."
    else
        echo "[ERROR] Network not reachable, skipping DB log."
    fi
