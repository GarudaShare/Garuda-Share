#import status_server
from time import sleep
import subprocess
import time

from doip_main import doip_main
from sbw_support import (
    LedBlinker,
    flash_completed,
    flash_progress,
    flash_started,
    get_checksum_frz_app,
    sbw_flashing,
)

# error_led = LedBlinker("error-led", interval=1)
data_led  = LedBlinker("datalog-led", interval=1)
wifi_led  = LedBlinker("wlanbt-led", interval=1)
usb_led  = LedBlinker("usb-led", interval=1)
link_led  = LedBlinker("link-led", interval=1)

#status_server.run_ui()

def wait_for_ping(retries=3, interval=1):
    for _ in range(retries):
        if subprocess.call(
            ["ping", "-c", "1", "-W", "1", "172.30.1.6"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        ) == 0:

            usb_led.start_blink()
            data_led.start_blink()
            wifi_led.start_blink()
            link_led.start_blink()
            sleep(0.8)
            link_led.stop_blink()
            usb_led.stop_blink()
            data_led.stop_blink()
            wifi_led.stop_blink()
            
            
            return True
        time.sleep(interval)
    return False

conn_status = wait_for_ping()
if not conn_status :
    exit(1)
    
wifi_led.start_blink()

SBW_SW = r'/usr/bin/doip_flashing/AA1685-X850ECc.hex'
SBW_segments, SBW_req_down = sbw_flashing(SBW_SW)
SBW_crc = get_checksum_frz_app(SBW_SW)
print(SBW_crc)
wifi_led.stop_blink()
doip = doip_main()
data_led  = LedBlinker("datalog-led")
data_led.start_blink()
doip.doip_reconnect(0x7D1, '172.30.1.6')
#VIN = doip.send_doip_request_get_response('22f190')
#vin_number = binascii.hexlify(VIN).decode().upper()
vin_number = doip.read_sw_version('22f190')
flash_started(str(vin_number))
doip.send_doip_request_verify_pos('22f181')
doip.send_doip_request_verify_pos('22f180')
doip.send_doip_request_verify_pos('1003')
doip.send_doip_request_verify_pos('22f190')
doip.send_diagnostic_security_l3(0x7D1, '2705')
flash_progress(30,"Security access done")
doip.send_doip_request_verify_pos('1002')
doip.send_doip_request_verify_pos('31 01 02 00 01')
doip.send_doip_request_verify_pos('31 01 02 01 01 06 03 09 07 24 10 41 57 36 31 30 53 42 57 44 41 41 43 54 32 30 37 00 00')
doip.send_doip_request_verify_pos('83 04 00 00 00 32 00 00 00')
doip.send_doip_request_verify_pos('31 01 FF 00 02')
flash_progress(40,"Data Transfer")
doip.send_doip_request_verify_pos(SBW_req_down[0])
flash_progress(50,"Data Transfer")
doip.send_ecus_transfer_data(0x7D1, SBW_segments[0])
doip.send_doip_request_verify_pos('37')
flash_progress(85,"Data Transfer")
doip.send_doip_request_verify_pos(f'3101FF01{SBW_crc}')
doip.send_doip_request_verify_pos(f'31 01 02 00 00')
doip.send_doip_request_verify_pos(f'1101')
time.sleep(5)
doip.close_doip_port()
doip.doip_reconnect(0x7D1, '172.30.1.6')
doip.send_doip_request_verify_pos('22f181')
doip.send_doip_request_verify_pos('22f180')
doip.close_doip_port()
flash_progress(98,"Data Transfer")
time.sleep(1)
flash_completed()
data_led.stop_blink(final_state="off")

link_led.start_blink()
sleep(0.8)
link_led.stop_blink(final_state="on")
