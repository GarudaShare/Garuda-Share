from sbw_support import dll_path, sal1, sal3

print(sal3("670516091F0D1F173608"))

__all__ = ["dll_path", "sal1", "sal3"]
