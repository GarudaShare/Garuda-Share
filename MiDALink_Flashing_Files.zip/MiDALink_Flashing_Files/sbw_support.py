import ctypes
import json
import os
import threading
import time
from datetime import datetime

from packages import crcmod
from packages.intelhex import IntelHex


class LedBlinker:
	def __init__(self, led_name, interval=0.1):
		self.led = led_name
		self.interval = interval
		self._stop_event = threading.Event()
		self._thread = None
		self.led_path = f"/sys/class/leds/{self.led}"

	def _write(self, path, value):
		with open(path, "w") as f:
			f.write(str(value))

	def _led_on(self):
		self._write(f"{self.led_path}/brightness", 1)

	def _led_off(self):
		self._write(f"{self.led_path}/brightness", 0)

	def _blink_loop(self):
		while not self._stop_event.is_set():
			self._led_on()
			time.sleep(self.interval)
			self._led_off()
			time.sleep(self.interval)

	def start_blink(self):
		if self._thread and self._thread.is_alive():
			return
		self._stop_event.clear()
		self._thread = threading.Thread(target=self._blink_loop, daemon=True)
		self._thread.start()

	def stop_blink(self, final_state="off"):
		self._stop_event.set()
		time.sleep(self.interval)
		if final_state == "on":
			self._led_on()
		else:
			self._led_off()

	def led_on(self):
		self.stop_blink()
		self._led_on()

	def led_off(self):
		self.stop_blink()
		self._led_off()


LOCK = threading.Lock()
STATUS_FILE = "status.json"
REPORT_DIR = "reports"
os.makedirs(REPORT_DIR, exist_ok=True)


def _safe(text):
	return "".join(c if c.isalnum() else "_" for c in text)


def _write(data):
	with open(STATUS_FILE, "w") as f:
		json.dump(data, f, indent=2)


def flash_started(vin):
	with LOCK:
		data = {
			"state": "FLASHING",
			"vin": vin,
			"progress": 0,
			"message": "Flashing started",
			"timestamp": datetime.now().isoformat(),
			"last_report": "",
		}
		_write(data)


def flash_progress(percent, message):
	with LOCK:
		if not os.path.exists(STATUS_FILE):
			return
		with open(STATUS_FILE) as f:
			data = json.load(f)

		data.update({
			"progress": percent,
			"message": message,
			"timestamp": datetime.now().isoformat(),
		})
		_write(data)


def flash_completed():
	with LOCK:
		with open(STATUS_FILE) as f:
			data = json.load(f)

		data.update({
			"state": "COMPLETED",
			"progress": 100,
			"message": "Flashing completed successfully",
			"timestamp": datetime.now().isoformat(),
		})

		report_path = _save_report(data)
		data["last_report"] = report_path
		_write(data)

	go_idle_after_delay(5)


def flash_failed(reason):
	with LOCK:
		with open(STATUS_FILE) as f:
			data = json.load(f)

		data.update({
			"state": "FAILED",
			"message": reason,
			"timestamp": datetime.now().isoformat(),
		})

		report_path = _save_report(data)
		data["last_report"] = report_path
		_write(data)

	go_idle_after_delay(10)


def go_idle_after_delay(seconds):
	def _idle():
		time.sleep(seconds)
		with LOCK:
			if not os.path.exists(STATUS_FILE):
				return
			with open(STATUS_FILE) as f:
				data = json.load(f)

			data.update({
				"state": "IDLE",
				"progress": 0,
				"message": "Waiting for next flash",
			})
			_write(data)

	_idle


def _save_report(data):
	vin = _safe(data.get("vin", "UNKNOWN_VIN"))
	ts = datetime.now().strftime("%Y%m%d_%H%M%S")

	filename = f"report_{vin}_{ts}.html"
	path = os.path.join(REPORT_DIR, filename)

	with open(path, "w") as f:
		f.write(
			f"""
<!DOCTYPE html>
<html>
<head><title>ECU Flash Report</title></head>
<body>
<h2>ECU Flash Report</h2>
<p><b>VIN:</b> {data.get("vin")}</p>
<p><b>Status:</b> {data.get("state")}</p>
<p><b>Progress:</b> {data.get("progress")}%</p>
<p><b>Message:</b> {data.get("message")}</p>
<p><b>Timestamp:</b> {data.get("timestamp")}</p>
</body>
</html>
"""
		)

	return f"/reports/{filename}"


def process_hex_file(hex_file, split_len=0):
	try:
		with open(hex_file, "r") as file:
			hex_dump = file.readlines()

		concatenated_data = "".join(line[split_len:].strip() for line in hex_dump)

		if not concatenated_data:
			raise ValueError("No valid hex data found in the file")

		if len(concatenated_data) % 2 != 0:
			concatenated_data = "0" + concatenated_data

		pairs = [concatenated_data[i:i + 2] for i in range(0, len(concatenated_data), 2)]
		hex_strings = ["0x" + pair for pair in pairs]

		for pair in pairs:
			try:
				int(pair, 16)
			except ValueError:
				raise ValueError(f"Invalid hex data found: {pair}")

		return hex_strings

	except FileNotFoundError:
		raise FileNotFoundError(f"File not found: {hex_file}")
	except Exception as e:
		raise ValueError(f"Error processing hex file: {str(e)}")


def convert_hex_to_block(hex_file_path):
	with open(hex_file_path, "r") as hex_file:
		block_hex = []

		for line in hex_file:
			if line.startswith(":"):
				line = line.strip()
				data_size = int((line[1:3]), 16)
				if data_size >= 4:
					if line.startswith(":"):
						data = line[:-2]
						data_1 = data[-data_size * 2:]
						hex_list = [f"0x{data_1[i:i + 2]}" for i in range(0, len(data_1), 2)]
						block_hex.extend(hex_list)

			if line.startswith("S3"):
				line = line.strip()
				data = line[-66:]
				data_1 = data[:64]
				s19_list = [f"0x{data_1[i:i + 2]}" for i in range(0, len(data_1), 2)]
				block_hex.extend(s19_list)

	return block_hex


def convert_frz_hex_to_block(hex_file_path):
	with open(hex_file_path, "r") as hex_file:
		block_hex = []

		for line in hex_file:
			if line.startswith(":"):
				if line.startswith(":04000"):
					continue
				line = line.strip()
				data_size = int((line[1:3]), 16)

				if data_size >= 4:
					if line.startswith(":"):
						data = line[:-2]
						data_1 = data[-data_size * 2:]
						hex_list = [f"0x{data_1[i:i + 2]}" for i in range(0, len(data_1), 2)]
						block_hex.extend(hex_list)

			if line.startswith("S3"):
				line = line.strip()
				data_1 = line[12:-2]
				s19_list = [f"0x{data_1[i:i + 2]}" for i in range(0, len(data_1), 2)]
				block_hex.extend(s19_list)

	return block_hex


def convert_eps_hex_to_block(hex_file_path):
	with open(hex_file_path, "r") as hex_file:
		block_hex = []

		for line in hex_file:
			if line.startswith(":"):
				line = line.strip()
				data_size = int((line[1:3]), 16)
				if line.startswith(":02FF8"):
					data = line[:-2]
					data_1 = data[-data_size * 2:]
					hex_list = [f"0x{data_1[i:i + 2]}" for i in range(0, len(data_1), 2)]
					block_hex.extend(hex_list)
				if data_size >= 4:
					if line.startswith(":"):
						data = line[:-2]
						data_1 = data[-data_size * 2:]
						hex_list = [f"0x{data_1[i:i + 2]}" for i in range(0, len(data_1), 2)]
						block_hex.extend(hex_list)

			if line.startswith("S3"):
				line = line.strip()
				data_1 = line[12:-2]
				s19_list = [f"0x{data_1[i:i + 2]}" for i in range(0, len(data_1), 2)]
				block_hex.extend(s19_list)

	return block_hex


def convert_s19_to_block(s19_file_path):
	with open(s19_file_path, "r") as s19_file:
		block_s19 = []
		for line in s19_file:
			line = line.strip()
			if line.startswith("S") and len(line) > 65:
				data = line[-66:]
				data_1 = data[:64]
				s19_list = [f"0x{data_1[i:i + 2]}" for i in range(0, len(data_1), 2)]
				block_s19.extend(s19_list)

	with open(s19_file_path, "r") as s19_file:
		for line in s19_file:
			line = line.strip()
			if line.startswith("S") and len(line) == 60:
				data = line[-50:]
				data_1 = data[:48]
				s19_list = [f"0x{data_1[i:i + 2]}" for i in range(0, len(data_1), 2)]
				block_s19.extend(s19_list)
	print(len(block_s19))
	return block_s19


def convert_frm_blocks(s19_file_path):
	with open(s19_file_path, "r") as s19_file:
		block_s19 = []
		for line in s19_file:
			line = line.strip()
			if line.startswith("S2"):
				data_1 = line[10:-2]
				s19_list = [f"0x{data_1[i:i + 2]}" for i in range(0, len(data_1), 2)]
				block_s19.extend(s19_list)
			elif line.startswith("S3"):
				data_1 = line[12:-2]
				s19_list = [f"0x{data_1[i:i + 2]}" for i in range(0, len(data_1), 2)]
				block_s19.extend(s19_list)

	return block_s19


def hex_block_size(file):
	ih = IntelHex()
	ih.loadhex(file)
	segments = ih.segments()

	flashing_block = []
	req_download = []

	for blocks in range(len(segments)):
		block_index = segments[blocks]
		size = block_index[1] - block_index[0]
		req_download.append(f"340044{block_index[0]:08X}{size:08X}")
		if len(flashing_block) > 0:
			flashing_block.append(size + flashing_block[blocks - 1])
		else:
			flashing_block.append(size)
	return flashing_block, req_download


def wlc_hex_block_size(file):
	ih = IntelHex()
	ih.loadhex(file)
	segments = ih.segments()

	flashing_block = []
	req_download = []

	for blocks in range(len(segments)):
		block_index = segments[blocks]
		size = block_index[1] - block_index[0]
		req_download.append(f"340044{block_index[0]:08X}{size:08X}")
		if len(flashing_block) > 0:
			flashing_block.append(size + flashing_block[blocks - 1])
		else:
			flashing_block.append(size)

	return flashing_block, req_download


crc16 = crcmod.predefined.mkPredefinedCrcFun("crc-ccitt-false")


def calculate_crc(data: bytes) -> int:
	crc = 0xFFFF
	chunk_size = 1024 * 1024

	for i in range(0, len(data), chunk_size):
		chunk = data[i:i + chunk_size]
		crc = crc16(chunk, crc)
	return crc


def format_crc(crc_value: int) -> str:
	final_crc = f"{crc_value:02X}"
	if len(final_crc) <= 2:
		return f"00{final_crc}"
	if len(final_crc) == 3:
		return f"0{final_crc}"
	return final_crc


def get_checksum_kernel(txt_file: str) -> str:
	try:
		hex_datas = process_hex_file(txt_file, 11)
		data = bytes(int(byte, 16) for byte in hex_datas)
		crc_value = calculate_crc(data)
		return format_crc(crc_value)
	except (FileNotFoundError, ValueError) as e:
		raise ValueError(f"Error processing kernel file {txt_file}: {str(e)}")


def get_checksum_apa_app(txt_file: str) -> str:
	try:
		with open(txt_file, "rb") as hex_f:
			data = hex_f.read().hex().upper()
			data_bytes = bytes.fromhex(data)
		crc32 = crcmod.predefined.mkCrcFun("crc-ccitt-false")
		crc_value = crc32(data_bytes)
		return format_crc(crc_value)
	except (FileNotFoundError, ValueError) as e:
		raise ValueError(f"Error processing APA app file {txt_file}: {str(e)}")


def get_checksum_app(file: str) -> str:
	try:
		hex_datas = convert_s19_to_block(file)
		data = bytes(int(byte, 16) for byte in hex_datas)
		crc_value = calculate_crc(data)
		return format_crc(crc_value)
	except (FileNotFoundError, ValueError) as e:
		raise ValueError(f"Error processing app file {file}: {str(e)}")


def get_checksum_frz_app(file: str) -> str:
	try:
		hex_datas = convert_frz_hex_to_block(file)
		data = bytes(int(byte, 16) for byte in hex_datas)
		crc_value = calculate_crc(data)
		return format_crc(crc_value)
	except (FileNotFoundError, ValueError) as e:
		raise ValueError(f"Error processing FRZ app file {file}: {str(e)}")


def get_checksum_eps_app(file: str) -> str:
	try:
		hex_datas = convert_eps_hex_to_block(file)
		data = bytes(int(byte, 16) for byte in hex_datas)
		crc_value = calculate_crc(data)
		return format_crc(crc_value)
	except (FileNotFoundError, ValueError) as e:
		raise ValueError(f"Error processing EPS app file {file}: {str(e)}")


def get_fcm_checksum(hex_datas: list) -> str:
	try:
		data = bytes(int(byte, 16) for byte in hex_datas)
		crc_value = calculate_crc(data)
		return format_crc(crc_value)
	except ValueError as e:
		raise ValueError(f"Error processing FCM data: {str(e)}")


def get_frm_checksum_app(file: str) -> str:
	try:
		hex_datas = convert_frm_blocks(file)
		data = bytes(int(byte, 16) for byte in hex_datas)
		crc_value = calculate_crc(data)
		return format_crc(crc_value)
	except (FileNotFoundError, ValueError) as e:
		raise ValueError(f"Error processing FRM app file {file}: {str(e)}")


def sbw_flashing(hex_txt_file, segment_threshold=1026):
	try:
		blocks_info, download_req_hex = hex_block_size(hex_txt_file)
		block_values = convert_frz_hex_to_block(hex_txt_file)
		hex_string = "".join(value[2:] for value in block_values)

		total_bytes = sum(size for size in blocks_info)
		if len(hex_string) // 2 != total_bytes:
			raise ValueError(
				f"Hex data length ({len(hex_string) // 2} bytes) does not match block sizes ({total_bytes} bytes)"
			)

		blocks = []
		current_offset = 0
		segment_length = segment_threshold * 2 - 4

		for size in blocks_info:
			chunk = hex_string[current_offset * 2:(current_offset + size) * 2]
			if len(chunk) != size * 2:
				raise ValueError(f"Chunk size mismatch for block at offset {current_offset}")

			if size >= segment_threshold:
				num_segments = (len(chunk) + segment_length - 1) // segment_length
				segments = [chunk[i:i + segment_length] for i in range(0, len(chunk), segment_length)]
				segment_numbers = [
					f"{(i + 1) % 256:02X}" if (i + 1) % 256 != 0 else "00" for i in range(num_segments)
				]
				segmented_strings = [(num, seg) for num, seg in zip(segment_numbers, segments)]
			else:
				segmented_strings = [("01", chunk)]

			blocks.append(segmented_strings)
			current_offset += size

		return blocks, download_req_hex

	except FileNotFoundError:
		raise FileNotFoundError(f"File not found: {hex_txt_file}")
	except Exception as e:
		raise ValueError(f"Error processing HEX file: {str(e)}")


dll_path = "/usr/bin/falshingscripts/mahindra_security_32.so"


def sal1(hex_string):
	dll_file = str(dll_path)
	response_seed = hex_string.replace(" ", "")
	response_seed = response_seed[4:]
	seed = int(response_seed, 16)
	seed = ctypes.c_ulonglong(seed)
	key = ctypes.c_ulonglong()
	ctypes.c_uint()
	mydll = ctypes.cdll.LoadLibrary(dll_file)
	mydll.generateKeyLevel1.argtypes = [ctypes.c_ulonglong, ctypes.POINTER(ctypes.c_ulonglong)]
	mydll.generateKeyLevel1.restype = ctypes.c_uint8
	mydll.generateKeyLevel1(seed, ctypes.byref(key))
	keyvalue = key.value
	keyvalue = hex(keyvalue)
	keyvalue = keyvalue[2:]
	keyvalue = str(keyvalue)
	out = "2702"
	keydata = out + keyvalue
	return keydata


def sal3(hex_string):
	dll_file = str(dll_path)
	response_seed = hex_string.replace(" ", "")
	response_seed = response_seed[4:]
	seed = int(response_seed, 16)
	seed = ctypes.c_ulonglong(seed)
	key = ctypes.c_ulonglong()
	ctypes.c_uint()
	mydll = ctypes.cdll.LoadLibrary(dll_file)
	mydll.generateKeyLevel3.argtypes = [ctypes.c_ulonglong, ctypes.POINTER(ctypes.c_ulonglong)]
	mydll.generateKeyLevel3.restype = ctypes.c_uint8
	mydll.generateKeyLevel3(seed, ctypes.byref(key))
	keyvalue = key.value
	keyvalue = hex(keyvalue)
	keyvalue = keyvalue[2:]
	keyvalue = str(keyvalue)
	out = "2706"
	keydata = out + keyvalue
	return keydata
