import binascii
# import threading
import time
from contextlib import contextmanager
from packages.doipclient import DoIPClient
#from doipclient.connectors import DoIPClientUDSConnector
# from udsoncan.client import Client
# from udsoncan.services import *
# from robot.libraries.BuiltIn import BuiltIn
# from robot.api import ContinuableFailure
from time import sleep as wait
from l1_sa import sal1, sal3
# from ping3 import ping
import logging
# import yaml
from pathlib import Path

# dtc_config = Path(__file__).parent.parent.parent / 'UI_Shell' / 'dtc_description.yaml'
logger = logging.getLogger("DOIP")


@contextmanager
def doip_client_context(ecu_ip, ecu_logical_address, client_logical_address, auto_reconnect_tcp):
    """Context manager for DoIPClient to ensure proper resource cleanup."""
    client = DoIPClient(ecu_ip, ecu_logical_address=ecu_logical_address,
                        client_logical_address=client_logical_address,
                        auto_reconnect_tcp=auto_reconnect_tcp)
    try:
        yield client
    finally:
        try:
            client.close()
            print(f"Closed DoIP connection to {ecu_ip}")
        except Exception as e:
            print(f"Error closing DoIP connection: {e}")


class doip_main:
    """Class for managing DoIP-based diagnostic communication with automotive ECUs."""

    def __init__(self, ecu_ip='172.30.1.6', apa_ip='172.30.1.11', fcm_ip='172.30.1.9', a53_ip='172.30.1.5'):
        """
        Initialize the DoIP client with default IP addresses and settings.

        Args:
            ecu_ip (str): IP address for the main ECU (default: '172.30.1.6').
            apa_ip (str): IP address for the APA ECU (default: '172.30.1.11').
            fcm_ip (str): IP address for the FCM ECU (default: '172.30.1.9').
            a53_ip (str): IP address for the A53 ECU (default: '172.30.1.5').
        """
        self.client_fcm = None
        self.client_apa = None
        self.client_a53 = None
        self.client = None
        self.func_diag_client = None
        self.ecu_ip = ecu_ip
        self.apa_ip = apa_ip
        self.fcm_ip = fcm_ip
        self.a53_ip = a53_ip
        self.client_id = 0x7DF
        self.client_log_addr = 0x0E80
        self.reconnect_tcp = True
        # with open(dtc_config, encoding="utf-8") as f:
        #     self.config = yaml.safe_load(f)

    def set_client_log_addr(self, addr):
        if isinstance(addr, str):
            addr = int(addr, 16) if addr.startswith("0x") else int(addr)
        self.client_log_addr = addr

    # def check_ip_addr_ping(self, ip, retries: int = 1, timeout: int = 30):
    #     for attempt in range(1, retries + 1):
    #         print(f"Attempt to ping {ip}...")
    #         response = ping(ip, timeout=timeout)
    #         if response:
    #             print(f"{ip} is reachable. Response time: {response:.4f} seconds")
    #             return True
    #         else:
    #             self.doip_report_fail(f"{ip} is not reachable for {timeout}sec.")
    #             return False
    #     return False

    def doip_reconnect(self, ecu_id, ecu_ip=None, retries=2, timeout=10):
        """
        Establish a DoIP connection to the main ECU.

        Args:
            ecu_id (int): ECU logical address.
            ecu_ip (str, optional): IP address for the ECU. Defaults to self.ecu_ip.
            retries (int): Default 2 times.
            timeout (int): Default 10sec.
        Returns:
            DoIPClient: The connected DoIP client instance.
        """
        ecu_ip = ecu_ip or self.ecu_ip
        for retry in range(0, retries):
            try:
                self.client = DoIPClient(ecu_ip, ecu_logical_address=ecu_id,
                                         client_logical_address=self.client_log_addr,
                                         auto_reconnect_tcp=self.reconnect_tcp)
                print(f'Routing activation established with {ecu_id:02X}')
                return self.client
            except Exception as e:
                print(f"Error establishing DoIP connection {retry} times: {e}")
                time.sleep(timeout)
        self.doip_report_fail(f"DoIP connection attempt failed {retries} times. Please check the OBD interface or verify the ping response.")
        return None

    def func_doip_reconnect(self, client_id=0xE400, ecu_ip=None, retries=2, timeout=10):
        """
        Establish a DoIP connection for functional diagnostics.

        Args:
            client_id (int): Client logical address (default: 0xE400).
            ecu_ip (str, optional): IP address for the ECU. Defaults to self.ecu_ip.
            retries (int): Default 2 times.
            timeout (int): Default 10sec.
        Returns:
            DoIPClient: The connected DoIP client instance.
        """
        ecu_ip = ecu_ip or self.ecu_ip
        for retry in range(0, retries):
            try:
                self.func_diag_client = DoIPClient(ecu_ip, ecu_logical_address=client_id,
                                                   client_logical_address=self.client_log_addr,
                                                   auto_reconnect_tcp=self.reconnect_tcp)
                print(f'Routing activation established with {client_id:02X}')
                return self.func_diag_client
            except Exception as e:
                print(f"Error establishing functional DoIP connection {retry} times: {e}")
                time.sleep(timeout)
        self.doip_report_fail(
            f"DoIP connection attempt failed {retries} times. Please check the OBD interface or verify the ping response.")
        return None

    def doip_apa_reconnect(self, ecu_id, ecu_ip=None, retries=2, timeout=10):
        """
        Establish a DoIP connection to the APA ECU.

        Args:
            ecu_id (int): ECU logical address.
            ecu_ip (str, optional): IP address for the APA ECU. Defaults to self.apa_ip.
            retries (int): Default 2 times.
            timeout (int): Default 10sec.
        Returns:
            DoIPClient: The connected DoIP client instance.
        """
        ecu_ip = ecu_ip or self.apa_ip
        for retry in range(0, retries):
            try:
                self.client_apa = DoIPClient(ecu_ip, ecu_logical_address=ecu_id,
                                             client_logical_address=self.client_log_addr,
                                             auto_reconnect_tcp=self.reconnect_tcp)
                print(f'Routing activation established with {ecu_id:02X}')
                return self.client_apa
            except Exception as e:
                print(f"Error establishing APA DoIP connection {retry} times: {e}")
                time.sleep(timeout)
        self.doip_report_fail(
            f"DoIP connection attempt failed {retries} times. Please check the OBD interface or verify the ping response.")
        return None

    def doip_fcm_reconnect(self, ecu_id, ecu_ip=None, retries=2, timeout=10):
        """
        Establish a DoIP connection to the FCM ECU.

        Args:
            ecu_id (int): ECU logical address.
            ecu_ip (str, optional): IP address for the FCM ECU. Defaults to self.fcm_ip.
            retries (int): Default 2 times.
            timeout (int): Default 10sec.
        Returns:
            DoIPClient: The connected DoIP client instance.
        """
        ecu_ip = ecu_ip or self.fcm_ip
        for retry in range(0, retries):
            try:
                self.client_fcm = DoIPClient(ecu_ip, ecu_logical_address=ecu_id,
                                             client_logical_address=self.client_log_addr,
                                             auto_reconnect_tcp=self.reconnect_tcp)
                print(f'Routing activation established with {ecu_id:02X}')
                return self.client_fcm
            except Exception as e:
                print(f"Error establishing FCM DoIP connection {retry} times: {e}")
                time.sleep(timeout)
        self.doip_report_fail(
            f"DoIP connection attempt failed {retries} times. Please check the OBD interface or verify the ping response.")
        return None

    def doip_a53_reconnect(self, ecu_id, ecu_ip=None, retries=2, timeout=10):
        """
        Establish a DoIP connection to the A53 ECU.

        Args:
            ecu_id (int): ECU logical address.
            ecu_ip (str, optional): IP address for the A53 ECU. Defaults to self.a53_ip.
            retries (int): Default 2 times.
            timeout (int): Default 10sec.
        Returns:
            DoIPClient: The connected DoIP client instance.
        """
        ecu_ip = ecu_ip or self.a53_ip
        for retry in range(0, retries):
            try:
                self.client_a53 = DoIPClient(ecu_ip, ecu_logical_address=ecu_id,
                                             client_logical_address=self.client_log_addr,
                                             auto_reconnect_tcp=self.reconnect_tcp)
                print(f'Routing activation established with {ecu_id:02X}')
                return self.client_a53
            except Exception as e:
                print(f"Error establishing A53 DoIP connection {retry} times: {e}")
                time.sleep(timeout)
        self.doip_report_fail(
            f"DoIP connection attempt failed {retries} times. Please check the OBD interface or verify the ping response.")
        return None

    def close_doip_port(self):
        """Close the main ECU DoIP port."""
        try:
            self.client.close()
            print('Close The ECU DOIP Port')
        except Exception as e:
            print(f'Error closing ECU DoIP port: {e}')

    def close_func_doip_port(self):
        """Close the functional DoIP port."""
        try:
            self.func_diag_client.close()
            print('Close The Functional DOIP Port')
        except Exception as e:
            print(f'Error closing Functional DoIP port: {e}')

    def close_doip_a53_port(self):
        """Close the A53 ECU DoIP port."""
        try:
            self.client_a53.close()
            print('Close The A53 DOIP Port')
        except Exception as e:
            print(f'Error closing A53 DoIP port: {e}')

    def close_doip_apa_port(self):
        """Close the APA ECU DoIP port."""
        try:
            self.client_apa.close()
            print('Close The APA DOIP Port')
        except Exception as e:
            print(f'Error closing APA DoIP port: {e}')

    def close_doip_fcm_port(self):
        """Close the FCM ECU DoIP port."""
        try:
            self.client_fcm.close()
            print('Close The FCM DOIP Port')
        except Exception as e:
            print(f'Error closing FCM DoIP port: {e}')

    def doip_report_fail(self, fail_command: str):
        """
        Report a test failure and set the 'FAIL' tag.

        Args:
            fail_command (str): The failure message.

        Raises:
            ContinuableFailure: To indicate a test failure that allows continuation.
        """
        print(f'{fail_command}')
        # BuiltIn().set_tags('FAIL')
        # raise ContinuableFailure(fail_command)

    def convert_str_to_bytearray(self, diag_request: str) -> bytearray:
        """
        Convert a hexadecimal string to a bytearray.

        Args:
            diag_request (str): Hexadecimal string representing the diagnostic request.

        Returns:
            bytearray: The converted bytearray.

        Raises:
            ValueError: If the input string contains invalid hexadecimal characters.
        """
        try:
            cleaned_request = diag_request.replace(' ', '').upper()
            if not all(c in '0123456789ABCDEF' for c in cleaned_request):
                raise ValueError("Invalid hexadecimal string")
            return bytearray(int(cleaned_request[i:i + 2], 16) for i in range(0, len(cleaned_request), 2))
        except ValueError as e:
            print(f"Invalid diagnostic request: {e}")
            raise

    def send_doip_request_verify_response(self, diag_request: str, user_resp: str, user_resp2: str = None):
        """
        Send a diagnostic request and verify the response against expected values.

        Args:
            diag_request (str): The diagnostic request in hexadecimal string format.
            user_resp (str): The expected response in hexadecimal string format.
            user_resp2 (str, optional): An alternative expected response.

        Raises:
            ContinuableFailure: If the response does not match the expected values.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client.send_diagnostic(diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'Diagnostic Request --> {diag_request.hex()}')
        resp = binascii.hexlify(self.client.receive_diagnostic(timeout=4.5)).decode().upper()
        stime = time.time()
        while True:
            if str(resp[:2]) != '7F':
                break
            if str(resp[-2:]) == '78':
                print(f'Diagnostic Response +ve <-- {resp}')
                resp = binascii.hexlify(self.client.receive_diagnostic(timeout=5)).decode().upper()
            if str(resp[-2:]) != '78':
                break
            if time.time() - stime > 600:
                print(f'10min waited Diagnostic Response +ve <-- {resp}')
                break

        if user_resp.replace(' ', '') == resp:
            print(
                "Obtained diagnostic response'{}', expected response'{}' for diagnostic request'{}'. TEST PASS.".format(
                    str(resp), str(user_resp.replace(' ', '')), str(diag_request.hex())))
        elif user_resp2 and user_resp2.replace(' ', '') == resp:
            print(
                "Obtained diagnostic response'{}', expected response'{}' for diagnostic request'{}'. TEST PASS.".format(
                    str(resp), str(user_resp2.replace(' ', '')), str(diag_request.hex())))
        else:
            self.doip_report_fail(
                "Obtained diagnostic response'{}', expected response'{}' or '{}' for diagnostic request'{}'. TEST FAIL.".format(
                    str(resp), str(user_resp.replace(' ', '')),
                    str(user_resp2.replace(' ', '') if user_resp2 else None),
                    str(diag_request.hex())))

    def send_doip_request_verify_pos(self, diag_request: str) -> str:
        """
        Send a diagnostic request and verify a positive response.

        Args:
            diag_request (str): The diagnostic request in hexadecimal string format.

        Returns:
            str: The diagnostic response in uppercase hexadecimal string.

        Raises:
            ContinuableFailure: If a negative response is received.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client.send_diagnostic(diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'Diagnostic Request --> {diag_request.hex()}')
        resp = binascii.hexlify(self.client.receive_diagnostic(timeout=4.5)).decode().upper()
        stime = time.time()
        while True:
            if str(resp[:2]) != '7F':
                break
            if int(len(resp)) >= int(6):
                if str(resp[-2:]) == '78':
                    resp = binascii.hexlify(self.client.receive_diagnostic(timeout=5)).decode().upper()
                if str(resp[-2:]) != '78':
                    break
                if time.time() - stime > 300:
                    print(f'5min waited Diagnostic Response +ve <-- {resp}')
                    break
            else:
                break
        if resp[:2] != '7F':
            print(f'Diagnostic Response +ve <-- {resp}')
            return resp
        else:
            self.doip_report_fail(f'Diagnostic Response -ve <-- {resp}')
            return resp

    def send_doip_request_verify_ecus_pos_rsp(self, ecu_addr, diag_request: str) -> str:
        """
        Send a diagnostic request to a specific ECU address and verify a positive response.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request in hexadecimal string format.

        Returns:
            str: The diagnostic response in uppercase hexadecimal string.

        Raises:
            ContinuableFailure: If a negative response is received.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client.send_diagnostic_to_address(ecu_addr, diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'Diagnostic Request --> {diag_request.hex()}')
        resp = binascii.hexlify(self.client.receive_diagnostic(timeout=4.5)).decode().upper()
        stime = time.time()
        while True:
            if str(resp[:2]) != '7F':
                break
            if int(len(resp)) >= int(6):
                if str(resp[-2:]) == '78':
                    resp = binascii.hexlify(self.client.receive_diagnostic(timeout=5)).decode().upper()
                if str(resp[-2:]) != '78':
                    break
                if time.time() - stime > 300:
                    print(f'5min waited Diagnostic Response +ve <-- {resp}')
                    break
            else:
                break
        if resp[:2] != '7F':
            print(f'Diagnostic Response +ve <-- {resp}')
            return resp
        else:
            self.doip_report_fail(f'Diagnostic Response -ve <-- {resp}')
        return resp

    # def send_doip_request_verify_ecus_no_dtc(self, ecu_name: str, ecu_addr, diag_request: str, *args) -> str:
    #     """
    #     Send a diagnostic request to a specific ECU address and verify a positive response.
    #
    #     Args:
    #         ecu_name : The ECU name.
    #         ecu_addr (int): The ECU address.
    #         diag_request (str): The diagnostic request in hexadecimal string format.
    #
    #     Returns:
    #         str: The diagnostic response in uppercase hexadecimal string.
    #
    #     Raises:
    #         ContinuableFailure: If a negative response is received.
    #     """
    #     diag_request = self.convert_str_to_bytearray(diag_request)
    #     try:
    #         self.client.send_diagnostic_to_address(ecu_addr, diag_request)
    #     except AttributeError:
    #         self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
    #     print(f'Diagnostic Request --> {diag_request.hex()}')
    #     resp = binascii.hexlify(self.client.receive_diagnostic(timeout=4.5)).decode().upper()
    #     stime = time.time()
    #     while True:
    #         if str(resp[:2]) != '7F':
    #             break
    #         if int(len(resp)) >= int(6):
    #             if str(resp[-2:]) == '78':
    #                 resp = binascii.hexlify(self.client.receive_diagnostic(timeout=5)).decode().upper()
    #             if str(resp[-2:]) != '78':
    #                 break
    #             if time.time() - stime > 300:
    #                 print(f'5min waited Diagnostic Response +ve <-- {resp}')
    #                 break
    #         else:
    #             break
    #     if resp[:2] != '7F':
    #         print(f'Diagnostic Response +ve <-- {resp}')
    #     else:
    #         self.doip_report_fail(f'Diagnostic Response -ve <-- {resp}')
    #     dtcs = []
    #     for arg in args:
    #         if arg.isdigit():
    #             dtc_desc = self.config.get(ecu_name.upper()).get(int(arg))
    #         else:
    #             dtc_desc = self.config.get(ecu_name.upper()).get(arg.upper())
    #         if arg in resp:
    #             dtcs.append(arg)
    #             print(f'{arg} DTC Present. Description: {dtc_desc}. Diagnostic Response <-- {resp}')
    #         else:
    #             print(f'{arg} DTC not Present. Description: {dtc_desc}. Diagnostic Response -ve <-- {resp}')
    #     if len(dtcs)>=1:
    #         self.doip_report_fail(f"{dtcs} DTC's Present in Diagnostic Response <-- {resp}")
    #
    #     return resp
    #
    # def send_fcm_doip_request_verify_ecus_no_dtc(self, ecu_name: str, ecu_addr, diag_request: str, *args) -> str:
    #     """
    #     Send a diagnostic request to a specific ECU address and verify a positive response.
    #
    #     Args:
    #         ecu_name : The ECU Name.
    #         ecu_addr (int): The ECU address.
    #         diag_request (str): The diagnostic request in hexadecimal string format.
    #
    #     Returns:
    #         str: The diagnostic response in uppercase hexadecimal string.
    #
    #     Raises:
    #         ContinuableFailure: If a negative response is received.
    #     """
    #     diag_request = self.convert_str_to_bytearray(diag_request)
    #     try:
    #         self.client_fcm.send_diagnostic_to_address(ecu_addr, diag_request)
    #     except AttributeError:
    #         self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
    #     print(f'Diagnostic Request --> {diag_request.hex()}')
    #     resp = binascii.hexlify(self.client_fcm.receive_diagnostic(timeout=4.5)).decode().upper()
    #     stime = time.time()
    #     while True:
    #         if str(resp[:2]) != '7F':
    #             break
    #         if int(len(resp)) >= int(6):
    #             if str(resp[-2:]) == '78':
    #                 resp = binascii.hexlify(self.client_fcm.receive_diagnostic(timeout=5)).decode().upper()
    #             if str(resp[-2:]) != '78':
    #                 break
    #             if time.time() - stime > 300:
    #                 print(f'5min waited Diagnostic Response +ve <-- {resp}')
    #                 break
    #         else:
    #             break
    #     if resp[:2] != '7F':
    #         print(f'Diagnostic Response +ve <-- {resp}')
    #     else:
    #         self.doip_report_fail(f'Diagnostic Response -ve <-- {resp}')
    #     dtcs = []
    #     for arg in args:
    #         if arg.isdigit():
    #             dtc_desc = self.config.get(ecu_name.upper()).get(int(arg))
    #         else:
    #             dtc_desc = self.config.get(ecu_name.upper()).get(arg.upper())
    #         if arg in resp:
    #             dtcs.append(arg)
    #             print(f"{arg} DTC is present. Description: {dtc_desc}. Diagnostic Response: <-- {resp}")
    #         else:
    #             print(f"{arg} DTC not present. Description: {dtc_desc}. Diagnostic Response: <-- {resp}")
    #     if len(dtcs)>=1:
    #         self.doip_report_fail(f"{dtcs} DTC's Present in Diagnostic Response <-- {resp}")
    #     return resp
    #
    # def send_apa_doip_request_verify_ecus_no_dtc(self, ecu_name: str, ecu_addr, diag_request: str, *args) -> str:
    #     """
    #     Send a diagnostic request to a specific ECU address and verify a positive response.
    #
    #     Args:
    #         ecu_name : The ECU Name.
    #         ecu_addr (int): The ECU address.
    #         diag_request (str): The diagnostic request in hexadecimal string format.
    #
    #     Returns:
    #         str: The diagnostic response in uppercase hexadecimal string.
    #
    #     Raises:
    #         ContinuableFailure: If a negative response is received.
    #     """
    #     diag_request = self.convert_str_to_bytearray(diag_request)
    #     try:
    #         self.client_apa.send_diagnostic_to_address(ecu_addr, diag_request)
    #     except AttributeError:
    #         self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
    #     print(f'Diagnostic Request --> {diag_request.hex()}')
    #     resp = binascii.hexlify(self.client_apa.receive_diagnostic(timeout=4.5)).decode().upper()
    #     stime = time.time()
    #     while True:
    #         if str(resp[:2]) != '7F':
    #             break
    #         if int(len(resp)) >= int(6):
    #             if str(resp[-2:]) == '78':
    #                 resp = binascii.hexlify(self.client_apa.receive_diagnostic(timeout=5)).decode().upper()
    #             if str(resp[-2:]) != '78':
    #                 break
    #             if time.time() - stime > 300:
    #                 print(f'5min waited Diagnostic Response +ve <-- {resp}')
    #                 break
    #         else:
    #             break
    #     if resp[:2] != '7F':
    #         print(f'Diagnostic Response +ve <-- {resp}')
    #     else:
    #         self.doip_report_fail(f'Diagnostic Response -ve <-- {resp}')
    #     dtcs = []
    #     for arg in args:
    #         if arg.isdigit():
    #             dtc_desc = self.config.get(ecu_name.upper()).get(int(arg))
    #         else:
    #             dtc_desc = self.config.get(ecu_name.upper()).get(arg.upper())
    #         if arg in resp:
    #             dtcs.append(arg)
    #             print(f"{arg} DTC is present. Description: {dtc_desc}. Diagnostic Response: <-- {resp}")
    #         else:
    #             print(f"{arg} DTC not present. Description: {dtc_desc}. Diagnostic Response: <-- {resp}")
    #     if len(dtcs)>=1:
    #         self.doip_report_fail(f"{dtcs} DTC's Present in Diagnostic Response <-- {resp}")
    #     return resp
    #
    # def send_doip_request_verify_ecus_unwanted_dtc(self, ecu_name: str, ecu_addr, diag_request: str) -> str:
    #     diag_request = self.convert_str_to_bytearray(diag_request)
    #     try:
    #         self.client.send_diagnostic_to_address(ecu_addr, diag_request)
    #     except AttributeError:
    #         self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
    #     print(f'Diagnostic Request --> {diag_request.hex()}')
    #     resp = binascii.hexlify(self.client.receive_diagnostic(timeout=4.5)).decode().upper()
    #     stime = time.time()
    #     while True:
    #         if str(resp[:2]) != '7F':
    #             break
    #         if int(len(resp)) >= int(6):
    #             if str(resp[-2:]) == '78':
    #                 resp = binascii.hexlify(self.client.receive_diagnostic(timeout=5)).decode().upper()
    #             if str(resp[-2:]) != '78':
    #                 break
    #             if time.time() - stime > 300:
    #                 print(f'5min waited Diagnostic Response +ve <-- {resp}')
    #                 break
    #         else:
    #             break
    #     if resp[:2] != '7F':
    #         print(f'Diagnostic Response +ve <-- {resp}')
    #     else:
    #         self.doip_report_fail(f'Diagnostic Response -ve <-- {resp}')
    #     resp_dtc_data = resp[6:]
    #     resp_dtc = [resp_dtc_data[i:i + 8][:6] for i in range(0, len(resp_dtc_data), 8)]
    #     ecu_dtc_list = self.config.get(ecu_name.upper()).keys()
    #     args = set(ecu_dtc_list)
    #     resp_dtc = set(resp_dtc)
    #     args =set(str(n) if str(n).isdigit() else str(n).strip().lower() for n in args)
    #     resp_dtc =set(str(n) if str(n).isdigit() else str(n).strip().lower() for n in resp_dtc)
    #     unwanted_dtcs = sorted(resp_dtc - args)
    #     if len(unwanted_dtcs)>0:
    #         self.doip_report_fail(f'There is unwanted dtcs: {resp}\n. actual={resp_dtc}\n expected={args}\n unwanted dtcs={unwanted_dtcs}')
    #     print(f'There is no unwanted dtcs: {resp}\n. actual={resp_dtc}\n expected={args}\n')
    #     return resp
    #
    # def send_fcm_doip_request_verify_ecus_unwanted_dtc(self, ecu_name: str, ecu_addr, diag_request: str) -> str:
    #     diag_request = self.convert_str_to_bytearray(diag_request)
    #     try:
    #         self.client_fcm.send_diagnostic_to_address(ecu_addr, diag_request)
    #     except AttributeError:
    #         self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
    #     print(f'Diagnostic Request --> {diag_request.hex()}')
    #     resp = binascii.hexlify(self.client_fcm.receive_diagnostic(timeout=4.5)).decode().upper()
    #     stime = time.time()
    #     while True:
    #         if str(resp[:2]) != '7F':
    #             break
    #         if int(len(resp)) >= int(6):
    #             if str(resp[-2:]) == '78':
    #                 resp = binascii.hexlify(self.client_fcm.receive_diagnostic(timeout=5)).decode().upper()
    #             if str(resp[-2:]) != '78':
    #                 break
    #             if time.time() - stime > 300:
    #                 print(f'5min waited Diagnostic Response +ve <-- {resp}')
    #                 break
    #         else:
    #             break
    #     if resp[:2] != '7F':
    #         print(f'Diagnostic Response +ve <-- {resp}')
    #     else:
    #         self.doip_report_fail(f'Diagnostic Response -ve <-- {resp}')
    #     resp_dtc_data = resp[6:]
    #     resp_dtc = [resp_dtc_data[i:i + 8][:6] for i in range(0, len(resp_dtc_data), 8)]
    #     ecu_dtc_list = self.config.get(ecu_name.upper()).keys()
    #     args = set(ecu_dtc_list)
    #     resp_dtc = set(resp_dtc)
    #     args = set(str(n) if str(n).isdigit() else str(n).strip().lower() for n in args)
    #     resp_dtc = set(str(n) if str(n).isdigit() else str(n).strip().lower() for n in resp_dtc)
    #     unwanted_dtcs = sorted(resp_dtc - args)
    #     if len(unwanted_dtcs)>0:
    #         self.doip_report_fail(f'There is unwanted dtcs: {resp}\n. actual={resp_dtc}\n expected={args}\n unwanted dtcs={unwanted_dtcs}')
    #     print(f'There is no unwanted dtcs: {resp}\n. actual={resp_dtc}\n expected={args}\n')
    #     return resp
    #
    # def send_doip_request_verify_ecus_dtc(self, ecu_name: str, ecu_addr, diag_request: str, *args) -> str:
    #     """
    #     Send a diagnostic request to a specific ECU address and verify a positive response.
    #
    #     Args:
    #         ecu_name : The ECU Name.
    #         ecu_addr (int): The ECU address.
    #         diag_request (str): The diagnostic request in hexadecimal string format.
    #
    #     Returns:
    #         str: The diagnostic response in uppercase hexadecimal string.
    #
    #     Raises:
    #         ContinuableFailure: If a negative response is received.
    #     """
    #     diag_request = self.convert_str_to_bytearray(diag_request)
    #     try:
    #         self.client.send_diagnostic_to_address(ecu_addr, diag_request)
    #     except AttributeError:
    #         self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
    #     print(f'Diagnostic Request --> {diag_request.hex()}')
    #     resp = binascii.hexlify(self.client.receive_diagnostic(timeout=4.5)).decode().upper()
    #     stime = time.time()
    #     while True:
    #         if str(resp[:2]) != '7F':
    #             break
    #         if int(len(resp)) >= int(6):
    #             if str(resp[-2:]) == '78':
    #                 resp = binascii.hexlify(self.client.receive_diagnostic(timeout=5)).decode().upper()
    #             if str(resp[-2:]) != '78':
    #                 break
    #             if time.time() - stime > 300:
    #                 print(f'5min waited Diagnostic Response +ve <-- {resp}')
    #                 break
    #         else:
    #             break
    #     if resp[:2] != '7F':
    #         print(f'Diagnostic Response +ve <-- {resp}')
    #     else:
    #         self.doip_report_fail(f'Diagnostic Response -ve <-- {resp}')
    #     dtcs = []
    #     for arg in args:
    #         if arg.isdigit():
    #             dtc_desc = self.config.get(ecu_name.upper()).get(int(arg))
    #         else:
    #             dtc_desc = self.config.get(ecu_name.upper()).get(arg.upper())
    #         if arg in resp:
    #             print(f'{arg} DTC Present. Description: {dtc_desc}. Diagnostic Response <-- {resp}')
    #         else:
    #             dtcs.append(arg)
    #             print(f'{arg} DTC not Present. Description: {dtc_desc}. Diagnostic Response -ve <-- {resp}')
    #     if len(dtcs)>=1:
    #         self.doip_report_fail(f"{dtcs} DTC's not Present in Diagnostic Response <-- {resp}")
    #     return resp
    #
    # def send_fcm_doip_request_verify_ecus_dtc(self, ecu_name: str, ecu_addr, diag_request: str, *args) -> str:
    #     """
    #     Send a diagnostic request to a specific ECU address and verify a positive response.
    #
    #     Args:
    #         ecu_name : The ECU name.
    #         ecu_addr (int): The ECU address.
    #         diag_request (str): The diagnostic request in hexadecimal string format.
    #
    #     Returns:
    #         str: The diagnostic response in uppercase hexadecimal string.
    #
    #     Raises:
    #         ContinuableFailure: If a negative response is received.
    #     """
    #     diag_request = self.convert_str_to_bytearray(diag_request)
    #     try:
    #         self.client_fcm.send_diagnostic_to_address(ecu_addr, diag_request)
    #     except AttributeError:
    #         self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
    #     print(f'Diagnostic Request --> {diag_request.hex()}')
    #     resp = binascii.hexlify(self.client_fcm.receive_diagnostic(timeout=4.5)).decode().upper()
    #     stime = time.time()
    #     while True:
    #         if str(resp[:2]) != '7F':
    #             break
    #         if int(len(resp)) >= int(6):
    #             if str(resp[-2:]) == '78':
    #                 resp = binascii.hexlify(self.client_fcm.receive_diagnostic(timeout=5)).decode().upper()
    #             if str(resp[-2:]) != '78':
    #                 break
    #             if time.time() - stime > 300:
    #                 print(f'5min waited Diagnostic Response +ve <-- {resp}')
    #                 break
    #         else:
    #             break
    #     if resp[:2] != '7F':
    #         print(f'Diagnostic Response +ve <-- {resp}')
    #     else:
    #         self.doip_report_fail(f'Diagnostic Response -ve <-- {resp}')
    #     dtcs = []
    #     for arg in args:
    #         if arg.isdigit():
    #             dtc_desc = self.config.get(ecu_name.upper()).get(int(arg))
    #         else:
    #             dtc_desc = self.config.get(ecu_name.upper()).get(arg.upper())
    #         if arg in resp:
    #             print(f'{arg} DTC Present. Description: {dtc_desc}. Diagnostic Response <-- {resp}')
    #         else:
    #             dtcs.append(arg)
    #             print(f'{arg} DTC not Present. Description: {dtc_desc}. Diagnostic Response -ve <-- {resp}')
    #     if len(dtcs)>=1:
    #         self.doip_report_fail(f"{dtcs} DTC's not Present in Diagnostic Response <-- {resp}")
    #     return resp
    #
    # def send_apa_doip_request_verify_ecus_dtc(self, ecu_name: str, ecu_addr, diag_request: str, *args) -> str:
    #     """
    #     Send a diagnostic request to a specific ECU address and verify a positive response.
    #
    #     Args:
    #         ecu_name : The ECU name.
    #         ecu_addr (int): The ECU address.
    #         diag_request (str): The diagnostic request in hexadecimal string format.
    #
    #     Returns:
    #         str: The diagnostic response in uppercase hexadecimal string.
    #
    #     Raises:
    #         ContinuableFailure: If a negative response is received.
    #     """
    #     diag_request = self.convert_str_to_bytearray(diag_request)
    #     try:
    #         self.client_apa.send_diagnostic_to_address(ecu_addr, diag_request)
    #     except AttributeError:
    #         self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
    #     print(f'Diagnostic Request --> {diag_request.hex()}')
    #     resp = binascii.hexlify(self.client_apa.receive_diagnostic(timeout=4.5)).decode().upper()
    #     stime = time.time()
    #     while True:
    #         if str(resp[:2]) != '7F':
    #             break
    #         if int(len(resp)) >= int(6):
    #             if str(resp[-2:]) == '78':
    #                 resp = binascii.hexlify(self.client_apa.receive_diagnostic(timeout=5)).decode().upper()
    #             if str(resp[-2:]) != '78':
    #                 break
    #             if time.time() - stime > 300:
    #                 print(f'5min waited Diagnostic Response +ve <-- {resp}')
    #                 break
    #         else:
    #             break
    #     if resp[:2] != '7F':
    #         print(f'Diagnostic Response +ve <-- {resp}')
    #     else:
    #         self.doip_report_fail(f'Diagnostic Response -ve <-- {resp}')
    #     dtcs = []
    #     for arg in args:
    #         if arg.isdigit():
    #             dtc_desc = self.config.get(ecu_name.upper()).get(int(arg))
    #         else:
    #             dtc_desc = self.config.get(ecu_name.upper()).get(arg.upper())
    #         if arg in resp:
    #             print(f'{arg} DTC Present. Description: {dtc_desc}. Diagnostic Response <-- {resp}')
    #         else:
    #             dtcs.append(arg)
    #             print(f'{arg} DTC not Present. Description: {dtc_desc}. Diagnostic Response -ve <-- {resp}')
    #     if len(dtcs)>=1:
    #         self.doip_report_fail(f"{dtcs} DTC's not Present in Diagnostic Response <-- {resp}")
    #     return resp

    def send_ecus_func_doip_request_verify_no_resp(self, ecu_addr, diag_request: str):
        """
        Send a functional diagnostic request to an ECU address and verify no response.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request in hexadecimal string format.

        Raises:
            ContinuableFailure: If a response is received unexpectedly.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client.send_diagnostic_to_address(ecu_addr, diag_request, timeout=2)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'7DF Diagnostic Request <-- {diag_request.hex()}')
        try:
            resp = binascii.hexlify(self.client.receive_diagnostic(timeout=2.5)).decode().upper()
            print(f'7DF Diagnostic Resp <-- {resp}')
            self.doip_report_fail(f'FUNC DIAG:7DF --> Diagnostic Response <-- {resp}')
        except TimeoutError:
            print('FUNC DIAG:7DF --> Diagnostic No Response Received')

    def send_apa_func_doip_request_verify_no_resp(self, ecu_addr, diag_request: str):
        """
        Send a functional diagnostic request to an APA ECU address and verify no response.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request in hexadecimal string format.

        Raises:
            ContinuableFailure: If a response is received unexpectedly.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client_apa.send_diagnostic_to_address(ecu_addr, diag_request, timeout=2)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'7DF Diagnostic Request <-- {diag_request.hex()}')
        try:
            resp = binascii.hexlify(self.client_apa.receive_diagnostic(timeout=2.5)).decode().upper()
            print(f'7DF Diagnostic Resp <-- {resp}')
            self.doip_report_fail(f'FUNC DIAG:7DF --> Diagnostic Response <-- {resp}')
        except TimeoutError:
            print('FUNC DIAG:7DF --> Diagnostic No Response Received')

    def send_fcm_func_doip_request_verify_no_resp(self, ecu_addr, diag_request: str):
        """
        Send a functional diagnostic request to an FCM ECU address and verify no response.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request in hexadecimal string format.

        Raises:
            ContinuableFailure: If a response is received unexpectedly.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client_fcm.send_diagnostic_to_address(ecu_addr, diag_request, timeout=2)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'7DF Diagnostic Request <-- {diag_request.hex()}')
        try:
            resp = binascii.hexlify(self.client_fcm.receive_diagnostic(timeout=2.5)).decode().upper()
            print(f'7DF Diagnostic Resp <-- {resp}')
            self.doip_report_fail(f'FUNC DIAG:7DF --> Diagnostic Response <-- {resp}')
        except TimeoutError:
            print('FUNC DIAG:7DF --> Diagnostic No Response Received')

    def send_ecus_func_doip_request(self, ecu_addr, diag_request: str):
        """
        Send a functional diagnostic request to an ECU address.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request in hexadecimal string format.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client.send_diagnostic_to_address(ecu_addr, diag_request, timeout=2)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'7DF Diagnostic Request <-- {diag_request.hex()}')

    def send_doip_request_verify_ecus_rsp(self, ecu_addr, diag_request: str, user_resp: str, user_resp2: str = None,
                                          timeout: float = 4.5):
        """
        Send a diagnostic request to an ECU address and verify the response.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request in hexadecimal string format.
            user_resp (str): The expected response in hexadecimal string format.
            user_resp2 (str, optional): An alternative expected response.
            timeout (float): Timeout for receiving the response (default: 4.5 seconds).

        Raises:
            ContinuableFailure: If the response does not match the expected values.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client.send_diagnostic_to_address(ecu_addr, diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'Diagnostic Request --> {diag_request.hex()}')
        resp = binascii.hexlify(self.client.receive_diagnostic(timeout=timeout)).decode().upper()
        stime = time.time()
        while True:
            if str(resp[:2]) != '7F':
                break
            if int(len(resp)) >= int(6):
                if str(resp[-2:]) == '78':
                    resp = binascii.hexlify(self.client.receive_diagnostic(timeout=5)).decode().upper()
                if str(resp[-2:]) != '78':
                    break
                if time.time() - stime > 300:
                    print(f'5min waited Diagnostic Response +ve <-- {resp}')
                    break
            else:
                break
        if user_resp.replace(' ', '').upper() == resp:
            print(
                "Obtained diagnostic response'{}', expected response'{}' for diagnostic request'{}'. TEST PASS.".format(
                    str(resp), str(user_resp.replace(' ', '').upper()), str(diag_request.hex())))
        elif user_resp2 and user_resp2.replace(' ', '').upper() == resp:
            print(
                "Obtained diagnostic response'{}', expected response'{}' for diagnostic request'{}'. TEST PASS.".format(
                    str(resp), str(user_resp2.replace(' ', '').upper()), str(diag_request.hex())))
        else:
            self.doip_report_fail(
                "Obtained diagnostic response'{}', expected response'{}' or '{}' for diagnostic request'{}'. TEST FAIL.".format(
                    str(resp), str(user_resp.replace(' ', '').upper()),
                    str(user_resp2.replace(' ', '').upper() if user_resp2 else None),
                    str(diag_request.hex())))

    def send_doip_a53_request_verify_ecus_rsp(self, ecu_addr, diag_request: str, user_resp: str, user_resp2: str = None,
                                              timeout: float = 4.5):
        """
        Send a diagnostic request to an ECU address and verify the response.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request in hexadecimal string format.
            user_resp (str): The expected response in hexadecimal string format.
            user_resp2 (str, optional): An alternative expected response.
            timeout (float): Timeout for receiving the response (default: 4.5 seconds).

        Raises:
            ContinuableFailure: If the response does not match the expected values.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client_a53.send_diagnostic_to_address(ecu_addr, diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'Diagnostic Request --> {diag_request.hex()}')
        resp = binascii.hexlify(self.client_a53.receive_diagnostic(timeout=timeout)).decode().upper()
        stime = time.time()
        while True:
            if str(resp[:2]) != '7F':
                break
            if int(len(resp)) >= int(6):
                if str(resp[-2:]) == '78':
                    resp = binascii.hexlify(self.client_a53.receive_diagnostic(timeout=5)).decode().upper()
                if str(resp[-2:]) != '78':
                    break
                if time.time() - stime > 300:
                    print(f'5min waited Diagnostic Response +ve <-- {resp}')
                    break
            else:
                break
        if user_resp.replace(' ', '').upper() == resp:
            print(
                "Obtained diagnostic response'{}', expected response'{}' for diagnostic request'{}'. TEST PASS.".format(
                    str(resp), str(user_resp.replace(' ', '').upper()), str(diag_request.hex())))
        elif user_resp2 and user_resp2.replace(' ', '').upper() == resp:
            print(
                "Obtained diagnostic response'{}', expected response'{}' for diagnostic request'{}'. TEST PASS.".format(
                    str(resp), str(user_resp2.replace(' ', '').upper()), str(diag_request.hex())))
        else:
            self.doip_report_fail(
                "Obtained diagnostic response'{}', expected response'{}' or '{}' for diagnostic request'{}'. TEST FAIL.".format(
                    str(resp), str(user_resp.replace(' ', '').upper()),
                    str(user_resp2.replace(' ', '').upper() if user_resp2 else None),
                    str(diag_request.hex())))

    def send_doip_apa_request_verify_ecus_rsp(self, ecu_addr, diag_request: str, user_resp: str, user_resp2: str = None,
                                              timeout: float = 4.5):
        """
        Send a diagnostic request to an APA ECU address and verify the response.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request in hexadecimal string format.
            user_resp (str): The expected response in hexadecimal string format.
            user_resp2 (str, optional): An alternative expected response.
            timeout (float): Timeout for receiving the response (default: 4.5 seconds).

        Raises:
            ContinuableFailure: If the response does not match the expected values.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client_apa.send_diagnostic_to_address(ecu_addr, diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'Diagnostic Request --> {diag_request.hex()}')
        resp = binascii.hexlify(self.client_apa.receive_diagnostic(timeout=timeout)).decode().upper()
        stime = time.time()
        while True:
            if str(resp[:2]) != '7F':
                break
            if int(len(resp)) >= int(6):
                if str(resp[-2:]) == '78':
                    resp = binascii.hexlify(self.client_apa.receive_diagnostic(timeout=5)).decode().upper()
                if str(resp[-2:]) != '78':
                    break
                if time.time() - stime > 300:
                    print(f'5min waited Diagnostic Response +ve <-- {resp}')
                    break
            else:
                break
        if user_resp.replace(' ', '').upper() == resp:
            print(
                "Obtained diagnostic response'{}', expected response'{}' for diagnostic request'{}'. TEST PASS.".format(
                    str(resp), str(user_resp.replace(' ', '').upper()), str(diag_request.hex())))
        elif user_resp2 and user_resp2.replace(' ', '').upper() == resp:
            print(
                "Obtained diagnostic response'{}', expected response'{}' for diagnostic request'{}'. TEST PASS.".format(
                    str(resp), str(user_resp2.replace(' ', '').upper()), str(diag_request.hex())))
        else:
            self.doip_report_fail(
                "Obtained diagnostic response'{}', expected response'{}' or '{}' for diagnostic request'{}'. TEST FAIL.".format(
                    str(resp), str(user_resp.replace(' ', '').upper()),
                    str(user_resp2.replace(' ', '').upper() if user_resp2 else None),
                    str(diag_request.hex())))

    def send_doip_fcm_request_verify_ecus_rsp(self, ecu_addr, diag_request: str, user_resp: str, user_resp2: str = None,
                                              timeout: float = 4.5):
        """
        Send a diagnostic request to an FCM ECU address and verify the response.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request in hexadecimal string format.
            user_resp (str): The expected response in hexadecimal string format.
            user_resp2 (str, optional): An alternative expected response.
            timeout (float): Timeout for receiving the response (default: 4.5 seconds).

        Raises:
            ContinuableFailure: If the response does not match the expected values.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client_fcm.send_diagnostic_to_address(ecu_addr, diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'Diagnostic Request --> {diag_request.hex()}')
        resp = binascii.hexlify(self.client_fcm.receive_diagnostic(timeout=timeout)).decode().upper()
        stime = time.time()
        while True:
            if str(resp[:2]) != '7F':
                break
            if int(len(resp)) >= int(6):
                if str(resp[-2:]) == '78':
                    resp = binascii.hexlify(self.client_fcm.receive_diagnostic(timeout=5)).decode().upper()
                if str(resp[-2:]) != '78':
                    break
                if time.time() - stime > 300:
                    print(f'5min waited Diagnostic Response +ve <-- {resp}')
                    break
            else:
                break
        if user_resp.replace(' ', '').upper() == resp:
            print(
                "Obtained diagnostic response'{}', expected response'{}' for diagnostic request'{}'. TEST PASS.".format(
                    str(resp), str(user_resp.replace(' ', '').upper()), str(diag_request.hex())))
        elif user_resp2 and user_resp2.replace(' ', '').upper() == resp:
            print(
                "Obtained diagnostic response'{}', expected response'{}' for diagnostic request'{}'. TEST PASS.".format(
                    str(resp), str(user_resp2.replace(' ', '').upper()), str(diag_request.hex())))
        else:
            self.doip_report_fail(
                "Obtained diagnostic response'{}', expected response'{}' or '{}' for diagnostic request'{}'. TEST FAIL.".format(
                    str(resp), str(user_resp.replace(' ', '').upper()),
                    str(user_resp2.replace(' ', '').upper() if user_resp2 else None),
                    str(diag_request.hex())))

    def send_doip_a53_request_verify_ecus_pos_rsp(self, ecu_addr, diag_request: str) -> str:
        """
        Send a diagnostic request to an A53 ECU address and verify a positive response.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request in hexadecimal string format.

        Returns:
            str: The diagnostic response in uppercase hexadecimal string.

        Raises:
            ContinuableFailure: If a negative response is received.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client_a53.send_diagnostic_to_address(ecu_addr, diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'Diagnostic Request --> {diag_request.hex()}')
        resp = binascii.hexlify(self.client_a53.receive_diagnostic(timeout=4.5)).decode().upper()
        stime = time.time()
        while True:
            if str(resp[:2]) != '7F':
                break
            if int(len(resp)) >= int(6):
                if str(resp[-2:]) == '78':
                    resp = binascii.hexlify(self.client_a53.receive_diagnostic(timeout=5)).decode().upper()
                if str(resp[-2:]) != '78':
                    break
                if time.time() - stime > 300:
                    print(f'5min waited Diagnostic Response +ve <-- {resp}')
                    break
            else:
                break
        if resp[:2] != '7F':
            print(f'Diagnostic Response +ve <-- {resp}')
            return resp
        else:
            self.doip_report_fail(f'Diagnostic Response -ve <-- {resp}')
        return resp

    def send_doip_apa_request_verify_ecus_pos_rsp(self, ecu_addr, diag_request: str) -> str:
        """
        Send a diagnostic request to an APA ECU address and verify a positive response.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request in hexadecimal string format.

        Returns:
            str: The diagnostic response in uppercase hexadecimal string.

        Raises:
            ContinuableFailure: If a negative response is received.

        Note:
            Uses a 0.15-second initial timeout, which is shorter than the standard 4.5 seconds,
            as per the original implementation. Verify if this is intentional for APA ECU.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client_apa.send_diagnostic_to_address(ecu_addr, diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'Diagnostic Request --> {diag_request.hex()}')
        resp = binascii.hexlify(self.client_apa.receive_diagnostic(timeout=0.15)).decode().upper()
        stime = time.time()
        while True:
            if str(resp[:2]) != '7F':
                break
            if int(len(resp)) >= int(6):
                if str(resp[-2:]) == '78':
                    resp = binascii.hexlify(self.client_apa.receive_diagnostic(timeout=5)).decode().upper()
                if str(resp[-2:]) != '78':
                    break
                if time.time() - stime > 300:
                    print(f'5min waited Diagnostic Response +ve <-- {resp}')
                    break
            else:
                break
        if resp[:2] != '7F':
            print(f'Diagnostic Response +ve <-- {resp}')
            return resp
        else:
            self.doip_report_fail(f'Diagnostic Response -ve <-- {resp}')
        return resp

    def send_doip_fcm_request_verify_ecus_pos_rsp(self, ecu_addr, diag_request: str) -> str:
        """
        Send a diagnostic request to an FCM ECU address and verify a positive response.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request in hexadecimal string format.

        Returns:
            str: The diagnostic response in uppercase hexadecimal string.

        Raises:
            ContinuableFailure: If a negative response is received.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client_fcm.send_diagnostic_to_address(ecu_addr, diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'Diagnostic Request --> {diag_request.hex()}')
        resp = binascii.hexlify(self.client_fcm.receive_diagnostic(timeout=4.5)).decode().upper()
        stime = time.time()
        while True:
            if str(resp[:2]) != '7F':
                break
            if int(len(resp)) >= int(6):
                if str(resp[-2:]) == '78':
                    resp = binascii.hexlify(self.client_fcm.receive_diagnostic(timeout=5)).decode().upper()
                if str(resp[-2:]) != '78':
                    break
                if time.time() - stime > 300:
                    print(f'5min waited Diagnostic Response +ve <-- {resp}')
                    break
            else:
                break
        if resp[:2] != '7F':
            print(f'Diagnostic Response +ve <-- {resp}')
            return resp
        else:
            self.doip_report_fail(f'Diagnostic Response -ve <-- {resp}')
        return resp

    def read_sw_version(self, request: str) -> str:
        """
        Read the software version from the ECU.

        Args:
            request (str): The diagnostic request to read the software version.

        Returns:
            str: The software version as an ASCII string, or the raw response if negative.
        """
        diag_resp = self.send_doip_request_verify_pos(request)
        if diag_resp[:2] != '7F':
            diag_resp = diag_resp.replace(' ', '')
            diag_resp = diag_resp[6:]
            try:
                data = bytes.fromhex(diag_resp).decode('ascii')
                print(f'Software Version -- {data}')
                return data
            except UnicodeDecodeError:
                print(f'Failed to decode software version: {diag_resp}')
                return diag_resp
        else:
            print(f'Diagnostic Response -ve <-- {diag_resp}')
            return diag_resp

    def read_ecus_sw_version(self, ecu_id, request: str):
        """
        Read the software version from a specific ECU.

        Args:
            ecu_id (int): The ECU address.
            request (str): The diagnostic request to read the software version.
        """
        diag_resp = self.send_doip_request_verify_ecus_pos_rsp(ecu_id, request)
        if diag_resp[:2] != '7F':
            diag_resp = diag_resp.replace(' ', '')
            diag_resp = diag_resp[6:]
            try:
                data = bytes.fromhex(diag_resp).decode('ascii')
                print(f'Software Version -- {data}')
            except UnicodeDecodeError:
                print(f'Failed to decode software version: {diag_resp}')
        else:
            print(f'Diagnostic Response -ve <-- {diag_resp}')

    def read_a53_ecu_sw_version(self, ecu_id, request: str):
        """
        Read the software version from an A53 ECU.

        Args:
            ecu_id (int): The ECU address.
            request (str): The diagnostic request to read the software version.
        """
        diag_resp = self.send_doip_a53_request_verify_ecus_pos_rsp(ecu_id, request)
        if diag_resp[:2] != '7F':
            diag_resp = diag_resp.replace(' ', '')
            diag_resp = diag_resp[6:]
            try:
                data = bytes.fromhex(diag_resp).decode('ascii')
                print(f'Software Version -- {data}')
            except UnicodeDecodeError:
                print(f'Failed to decode software version: {diag_resp}')
        else:
            print(f'Diagnostic Response -ve <-- {diag_resp}')

    def read_apa_ecu_sw_version(self, ecu_id, request: str):
        """
        Read the software version from an APA ECU.

        Args:
            ecu_id (int): The ECU address.
            request (str): The diagnostic request to read the software version.
        """
        diag_resp = self.send_doip_apa_request_verify_ecus_pos_rsp(ecu_id, request)
        if diag_resp[:2] != '7F':
            diag_resp = diag_resp.replace(' ', '')
            diag_resp = diag_resp[6:]
            try:
                data = bytes.fromhex(diag_resp).decode('ascii')
                print(f'Software Version -- {data}')
            except UnicodeDecodeError:
                print(f'Failed to decode software version: {diag_resp}')
        else:
            print(f'Diagnostic Response -ve <-- {diag_resp}')

    def read_fcm_ecu_sw_version(self, ecu_id, request: str):
        """
        Read the software version from an FCM ECU.

        Args:
            ecu_id (int): The ECU address.
            request (str): The diagnostic request to read the software version.
        """
        diag_resp = self.send_doip_fcm_request_verify_ecus_pos_rsp(ecu_id, request)
        if diag_resp[:2] != '7F':
            diag_resp = diag_resp.replace(' ', '')
            diag_resp = diag_resp[6:]
            try:
                data = bytes.fromhex(diag_resp).decode('ascii')
                print(f'Software Version -- {data}')
            except UnicodeDecodeError:
                print(f'Failed to decode software version: {diag_resp}')
        else:
            print(f'Diagnostic Response -ve <-- {diag_resp}')

    def send_doip_request_transfer_data(self, diag_request: str):
        """
        Send a diagnostic request for data transfer and verify a positive response.

        Args:
            diag_request (str): The diagnostic request in hexadecimal string format.

        Raises:
            ContinuableFailure: If a negative response is received.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client.send_diagnostic(diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        resp = binascii.hexlify(self.client.receive_diagnostic(timeout=4.5)).decode().upper()
        stime = time.time()
        while True:
            if str(resp[:2]) != '7F':
                break
            if int(len(resp)) >= int(6):
                if str(resp[-2:]) == '78':
                    print(f'Diagnostic Response +ve <-- {resp}')
                    resp = binascii.hexlify(self.client.receive_diagnostic(timeout=5)).decode().upper()
                if str(resp[-2:]) != '78':
                    break
                if time.time() - stime > 600:
                    print(f'10min waited Diagnostic Response +ve <-- {resp}')
                    break
            else:
                break
        if resp[:2] != '7F':
            print(f'Diagnostic Response +ve <-- {resp}')
        else:
            self.doip_report_fail(f'Diagnostic Response -ve <-- {resp}')

    def send_ecus_doip_request_transfer_data(self, ecu_addr, diag_request: str):
        """
        Send a diagnostic request for data transfer to an ECU address.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request in hexadecimal string format.

        Raises:
            ContinuableFailure: If a negative response is received.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client.send_diagnostic_to_address(ecu_addr, diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        resp = binascii.hexlify(self.client.receive_diagnostic(timeout=4.5)).decode().upper()
        stime = time.time()
        while True:
            if str(resp[:2]) != '7F':
                break
            if int(len(resp)) >= int(6):
                if str(resp[-2:]) == '78':
                    resp = binascii.hexlify(self.client.receive_diagnostic(timeout=5)).decode().upper()
                if str(resp[-2:]) != '78':
                    break
                if time.time() - stime > 600:
                    print(f'10min waited Diagnostic Response +ve <-- {resp}')
                    break
            else:
                break
        if resp[:2] != '7F':
            print(f'Diagnostic Response +ve <-- {resp}')
        else:
            self.doip_report_fail(f'Diagnostic Response -ve <-- {resp}')

    def send_apa_ecus_doip_request_transfer_data(self, ecu_addr, diag_request: str):
        """
        Send a diagnostic request for data transfer to an APA ECU address.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request in hexadecimal string format.

        Raises:
            ContinuableFailure: If a negative response is received.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client_apa.send_diagnostic_to_address(ecu_addr, diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        resp = binascii.hexlify(self.client_apa.receive_diagnostic(timeout=4.5)).decode().upper()
        stime = time.time()
        while True:
            if str(resp[:2]) != '7F':
                break
            if int(len(resp)) >= int(6):
                if str(resp[-2:]) == '78':
                    resp = binascii.hexlify(self.client_apa.receive_diagnostic(timeout=5)).decode().upper()
                if str(resp[-2:]) != '78':
                    break
                if time.time() - stime > 600:
                    print(f'10min waited Diagnostic Response +ve <-- {resp}')
                    break
            else:
                break
        if resp[:2] != '7F':
            print(f'Diagnostic Response +ve <-- {resp}')
        else:
            self.doip_report_fail(f'Diagnostic Response -ve <-- {resp}')

    def send_fcm_ecus_doip_request_transfer_data(self, ecu_addr, diag_request: str):
        """
        Send a diagnostic request for data transfer to an FCM ECU address.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request in hexadecimal string format.

        Raises:
            ContinuableFailure: If a negative response is received.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client_fcm.send_diagnostic_to_address(ecu_addr, diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        resp = binascii.hexlify(self.client_fcm.receive_diagnostic(timeout=4.5)).decode().upper()
        stime = time.time()
        while True:
            if str(resp[:2]) != '7F':
                break
            if int(len(resp)) >= int(6):
                if str(resp[-2:]) == '78':
                    resp = binascii.hexlify(self.client_fcm.receive_diagnostic(timeout=5)).decode().upper()
                if str(resp[-2:]) != '78':
                    break
                if time.time() - stime > 600:
                    print(f'10min waited Diagnostic Response +ve <-- {resp}')
                    break
            else:
                break
        if resp[:2] != '7F':
            print(f'Diagnostic Response +ve <-- {resp}')
        else:
            self.doip_report_fail(f'Diagnostic Response -ve <-- {resp}')

    def send_doip_ecus_request(self, ecu_addr, diag_request: str):
        """
        Send a diagnostic request to an ECU address without response verification.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request in hexadecimal string format.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client.send_diagnostic_to_address(ecu_addr, diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'Diagnostic Request <-- {diag_request.hex()}')

    def send_doip_request_verify_resp_len(self, diag_request: str, resp_len: int):
        """
        Send a diagnostic request and verify the response length.

        Args:
            diag_request (str): The diagnostic request in hexadecimal string format.
            resp_len (int): The expected response length in bytes.

        Raises:
            ContinuableFailure: If the response length does not match the expected length.
        """
        resp = self.send_doip_request_verify_pos(diag_request)
        if int(len(resp) / 2) == int(resp_len):
            print(f'Diagnostic Response +ve <-- {resp}')
        else:
            self.doip_report_fail(f'Diagnostic Response -ve <-- {resp}')

    def send_ecus_doip_request_verify_resp_len(self, ecu_addr, diag_request: str, resp_len: int):
        resp = self.send_doip_request_verify_ecus_pos_rsp(ecu_addr, diag_request)
        if int(len(resp) / 2) == int(resp_len):
            print(f'Diagnostic Response +ve <-- {resp}')
        else:
            self.doip_report_fail(f'Diagnostic Response -ve <-- {resp}')

    def send_apa_doip_request_verify_resp_len(self, ecu_addr, diag_request: str, resp_len: int):
        resp = self.send_doip_apa_request_verify_ecus_pos_rsp(ecu_addr, diag_request)
        if int(len(resp) / 2) == int(resp_len):
            print(f'Diagnostic Response +ve <-- {resp}')
        else:
            self.doip_report_fail(f'Diagnostic Response -ve <-- {resp}')

    def send_fcm_doip_request_verify_resp_len(self, ecu_addr, diag_request: str, resp_len: int):
        resp = self.send_doip_fcm_request_verify_ecus_pos_rsp(ecu_addr, diag_request)
        if int(len(resp) / 2) == int(resp_len):
            print(f'Diagnostic Response +ve <-- {resp}')
        else:
            self.doip_report_fail(f'Diagnostic Response -ve <-- {resp}')

    def send_doip_request_verify_neg_resp(self, diag_request: str):
        """
        Send a diagnostic request and verify a negative response.

        Args:
            diag_request (str): The diagnostic request in hexadecimal string format.

        Raises:
            ContinuableFailure: If a positive response is received unexpectedly.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client.send_diagnostic(diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'Diagnostic Request <-- {diag_request.hex()}')
        resp = binascii.hexlify(self.client.receive_diagnostic(timeout=3.5)).decode().upper()
        if resp[:2] == '7F':
            print(f'Diagnostic Response -ve <-- {resp}')
        else:
            self.doip_report_fail(f'Diagnostic Response <-- {resp}')

    def send_ecus_doip_request_verify_neg_resp(self, ecu_addr, diag_request: str):
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client.send_diagnostic_to_address(ecu_addr, diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'Diagnostic Request <-- {diag_request.hex()}')
        resp = binascii.hexlify(self.client.receive_diagnostic(timeout=3.5)).decode().upper()
        if resp[:2] == '7F':
            print(f'Diagnostic Response -ve <-- {resp}')
        else:
            self.doip_report_fail(f'Diagnostic Response <-- {resp}')

    def send_apa_doip_request_verify_neg_resp(self, ecu_addr, diag_request: str):
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client_apa.send_diagnostic_to_address(ecu_addr, diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'Diagnostic Request <-- {diag_request.hex()}')
        resp = binascii.hexlify(self.client_apa.receive_diagnostic(timeout=3.5)).decode().upper()
        if resp[:2] == '7F':
            print(f'Diagnostic Response -ve <-- {resp}')
        else:
            self.doip_report_fail(f'Diagnostic Response <-- {resp}')

    def send_fcm_doip_request_verify_neg_resp(self, ecu_addr, diag_request: str):
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client_fcm.send_diagnostic_to_address(ecu_addr, diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'Diagnostic Request <-- {diag_request.hex()}')
        resp = binascii.hexlify(self.client_fcm.receive_diagnostic(timeout=3.5)).decode().upper()
        if resp[:2] == '7F':
            print(f'Diagnostic Response -ve <-- {resp}')
        else:
            self.doip_report_fail(f'Diagnostic Response <-- {resp}')

    def send_doip_request_verify_nrc(self, diag_request: str, user_nrc: str, user_nrc1: str = None):
        """
        Send a diagnostic request and verify the negative response code (NRC).

        Args:
            diag_request (str): The diagnostic request in hexadecimal string format.
            user_nrc (str): The expected NRC in hexadecimal.
            user_nrc1 (str, optional): An alternative expected NRC.

        Raises:
            ContinuableFailure: If the NRC does not match the expected values.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client.send_diagnostic(diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'Diagnostic Request <-- {diag_request.hex()}')
        resp = binascii.hexlify(self.client.receive_diagnostic(timeout=4.5)).decode().upper()
        stime = time.time()
        while True:
            if str(resp[:2]) != '7F':
                break
            if int(len(resp)) >= int(6):
                if str(resp[-2:]) == '78':
                    print(f'Diagnostic Response -ve <-- {resp}')
                    resp = binascii.hexlify(self.client.receive_diagnostic(timeout=5)).decode().upper()
                if str(resp[-2:]) != '78':
                    break
                if time.time() - stime > 300:
                    print(f'5min waited Diagnostic Response +ve <-- {resp}')
                    break
            else:
                break
        if resp[-2:] == user_nrc:
            print(f'Diagnostic Response -ve <-- {resp}')
        elif user_nrc1 and resp[:2] == user_nrc1:
            print(f'Diagnostic Response +ve <-- {resp}')
        else:
            self.doip_report_fail(f'Diagnostic Response <-- {resp}')

    def send_ecus_doip_request_verify_nrc(self, ecu_addr, diag_request: str, user_nrc: str, user_nrc1: str = None):
        """
        Send a diagnostic request to an ECU address and verify the NRC.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request in hexadecimal string format.
            user_nrc (str): The expected NRC in hexadecimal.
            user_nrc1 (str, optional): An alternative expected NRC.

        Raises:
            ContinuableFailure: If the NRC does not match the expected values.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client.send_diagnostic_to_address(ecu_addr, diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'Diagnostic Request <-- {diag_request.hex()}')
        resp = binascii.hexlify(self.client.receive_diagnostic(timeout=4.5)).decode().upper()
        stime = time.time()
        while True:
            if str(resp[:2]) != '7F':
                break
            if int(len(resp)) >= int(6):
                if str(resp[-2:]) == '78':
                    print(f'Diagnostic Response -ve <-- {resp}')
                    resp = binascii.hexlify(self.client.receive_diagnostic(timeout=5)).decode().upper()
                if str(resp[-2:]) != '78':
                    break
                if time.time() - stime > 300:
                    print(f'5min waited Diagnostic Response +ve <-- {resp}')
                    break
            else:
                break
        if resp[-2:] == user_nrc:
            print(f'Diagnostic Response -ve <-- {resp}')
        elif user_nrc1 and resp[:2] == user_nrc1:
            print(f'Diagnostic Response +ve <-- {resp}')
        else:
            self.doip_report_fail(f'Diagnostic Response <-- {resp}')

    def send_apa_doip_request_verify_nrc(self, ecu_addr, diag_request: str, user_nrc: str, user_nrc1: str = None):
        """
        Send a diagnostic request to an ECU address and verify the NRC.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request in hexadecimal string format.
            user_nrc (str): The expected NRC in hexadecimal.
            user_nrc1 (str, optional): An alternative expected NRC.

        Raises:
            ContinuableFailure: If the NRC does not match the expected values.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client_apa.send_diagnostic_to_address(ecu_addr, diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'Diagnostic Request <-- {diag_request.hex()}')
        resp = binascii.hexlify(self.client_apa.receive_diagnostic(timeout=4.5)).decode().upper()
        stime = time.time()
        while True:
            if str(resp[:2]) != '7F':
                break
            if int(len(resp)) >= int(6):
                if str(resp[-2:]) == '78':
                    print(f'Diagnostic Response -ve <-- {resp}')
                    resp = binascii.hexlify(self.client_apa.receive_diagnostic(timeout=5)).decode().upper()
                if str(resp[-2:]) != '78':
                    break
                if time.time() - stime > 300:
                    print(f'5min waited Diagnostic Response +ve <-- {resp}')
                    break
            else:
                break
        if resp[-2:] == user_nrc:
            print(f'Diagnostic Response -ve <-- {resp}')
        elif user_nrc1 and resp[:2] == user_nrc1:
            print(f'Diagnostic Response +ve <-- {resp}')
        else:
            self.doip_report_fail(f'Diagnostic Response <-- {resp}')

    def send_fcm_doip_request_verify_nrc(self, ecu_addr, diag_request: str, user_nrc: str, user_nrc1: str = None):
        """
        Send a diagnostic request to an ECU address and verify the NRC.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request in hexadecimal string format.
            user_nrc (str): The expected NRC in hexadecimal.
            user_nrc1 (str, optional): An alternative expected NRC.

        Raises:
            ContinuableFailure: If the NRC does not match the expected values.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client_fcm.send_diagnostic_to_address(ecu_addr, diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'Diagnostic Request <-- {diag_request.hex()}')
        resp = binascii.hexlify(self.client_fcm.receive_diagnostic(timeout=4.5)).decode().upper()
        stime = time.time()
        while True:
            if str(resp[:2]) != '7F':
                break
            if int(len(resp)) >= int(6):
                if str(resp[-2:]) == '78':
                    print(f'Diagnostic Response -ve <-- {resp}')
                    resp = binascii.hexlify(self.client_fcm.receive_diagnostic(timeout=5)).decode().upper()
                if str(resp[-2:]) != '78':
                    break
                if time.time() - stime > 300:
                    print(f'5min waited Diagnostic Response +ve <-- {resp}')
                    break
            else:
                break
        if resp[-2:] == user_nrc:
            print(f'Diagnostic Response -ve <-- {resp}')
        elif user_nrc1 and resp[:2] == user_nrc1:
            print(f'Diagnostic Response +ve <-- {resp}')
        else:
            self.doip_report_fail(f'Diagnostic Response <-- {resp}')

    def send_doip_request_get_response(self, diag_request: str) -> bytes:
        """
        Send a diagnostic request and return the raw response.

        Args:
            diag_request (str): The diagnostic request in hexadecimal string format.

        Returns:
            bytes: The raw diagnostic response.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client.send_diagnostic(diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'Diagnostic Request <-- {diag_request.hex()}')
        resp = self.client.receive_diagnostic(timeout=3.5)
        return resp

    def send_doip_request_verify_no_resp(self, diag_request: str):
        """
        Send a diagnostic request and verify no response is received.

        Args:
            diag_request (str): The diagnostic request in hexadecimal string format.

        Raises:
            ContinuableFailure: If a response is received unexpectedly.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client.send_diagnostic(diag_request, timeout=2)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'Diagnostic Request <-- {diag_request.hex()}')
        try:
            resp = binascii.hexlify(self.client.receive_diagnostic(timeout=1)).decode().upper()
            print(f'Diagnostic Response <-- {resp}')
            self.doip_report_fail(f'Diagnostic Response <-- {resp}')
        except TimeoutError:
            print('Diagnostic No Response Received')

    def send_ecus_doip_request_verify_no_resp(self, ecu_addr, diag_request: str):
        """
        Send a diagnostic request to an ECU address and verify no response is received.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request in hexadecimal string format.

        Raises:
            ContinuableFailure: If a response is received unexpectedly.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.client.send_diagnostic_to_address(ecu_addr, diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'Diagnostic Request <-- {diag_request.hex()}')
        try:
            resp = binascii.hexlify(self.client.receive_diagnostic(timeout=1)).decode().upper()
            print(f'Diagnostic Response <-- {resp}')
            self.doip_report_fail(f'Diagnostic Response <-- {resp}')
        except TimeoutError:
            print('Diagnostic No Response Received')

    def _send_diagnostic_security(self, client, ecu_addr, diag_request: str, security_level: str) -> str:
        """
        Helper method to handle security access (Level 1 or Level 3) for an ECU.

        Args:
            client: The DoIP client instance (e.g., self.client, self.client_apa, self.client_fcm).
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request in hexadecimal string format (e.g., '2701' or '2705').
            security_level (str): The security level ('L1' or 'L3').

        Returns:
            str: The NRC if security access fails with NRC '36', otherwise None.

        Raises:
            ContinuableFailure: If the security access fails with an unexpected response.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            client.send_diagnostic_to_address(ecu_addr, diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'Diagnostic Request <-- {diag_request.hex()}')
        seed_resp = binascii.hexlify(client.receive_diagnostic(timeout=4.5)).decode().upper()
        stime = time.time()
        while True:
            if str(seed_resp[:2]) != '7F':
                break
            if int(len(seed_resp)) >= int(6):
                if str(seed_resp[-2:]) == '78':
                    seed_resp = binascii.hexlify(client.receive_diagnostic(timeout=5)).decode().upper()
                if str(seed_resp[-2:]) != '78':
                    break
                if time.time() - stime > 300:
                    print(f'5min waited Diagnostic Response +ve <-- {seed_resp}')
                    break
            else:
                break
        if seed_resp[:2] != '7F':
            print(f'Diagnostic Response +ve <-- {seed_resp}')
        elif seed_resp[:2] == '7F':
            if seed_resp[-2:] == '7F':
                print(f'Diagnostic Response -ve <-- {seed_resp}')
                if client == self.client:
                    self.send_doip_request_verify_ecus_pos_rsp(ecu_addr, '1003')
                elif client == self.client_apa:
                    self.send_doip_apa_request_verify_ecus_pos_rsp(ecu_addr, '1003')
                elif client == self.client_fcm:
                    self.send_doip_fcm_request_verify_ecus_pos_rsp(ecu_addr, '1003')
                time.sleep(1)
                client.send_diagnostic_to_address(ecu_addr, diag_request)
                print(f'Diagnostic Request <-- {diag_request.hex()}')
                seed_resp = binascii.hexlify(client.receive_diagnostic(timeout=4.5)).decode().upper()
            elif seed_resp[-2:] == '36':
                print(f'Diagnostic Response -ve <-- {seed_resp}')
                self.doip_report_fail(f'Number of Time Exceed Give IGN TOGGLE')
                return seed_resp[-2:]
        else:
            self.doip_report_fail(f'Diagnostic Response -ve <-- {seed_resp}')
        try:
            ecu_key = sal1(seed_resp) if security_level == 'L1' else sal3(seed_resp)
        except Exception as e:
            print(f'Failed to generate security key: {e}')
            self.doip_report_fail(f'Key generation failed: {e}')
            return None
        ecu_key = self.convert_str_to_bytearray(ecu_key)
        client.send_diagnostic_to_address(ecu_addr, ecu_key)
        print(f'Diagnostic Request <-- {ecu_key.hex()}')
        key_resp = binascii.hexlify(client.receive_diagnostic(timeout=4.5)).decode().upper()
        stime = time.time()
        while True:
            if str(key_resp[:2]) != '7F':
                break
            if int(len(key_resp)) >= int(6):
                if str(key_resp[-2:]) == '78':
                    key_resp = binascii.hexlify(client.receive_diagnostic(timeout=5)).decode().upper()
                if str(key_resp[-2:]) != '78':
                    break
                if time.time() - stime > 300:
                    print(f'5min waited Diagnostic Response +ve <-- {key_resp}')
                    break
            else:
                break
        if key_resp[:2] != '7F':
            print(f'Diagnostic Response +ve <-- {key_resp}')
        elif key_resp[:2] == '7F':
            if key_resp[-2:] == '13':
                wait(0.5)
                if client == self.client:
                    self.send_doip_request_verify_ecus_pos_rsp(ecu_addr, '1003')
                    wait(0.5)
                    self._send_diagnostic_security(client, ecu_addr, '2701' if security_level == 'L1' else '2705',
                                                   security_level)
                elif client == self.client_apa:
                    self.send_doip_apa_request_verify_ecus_pos_rsp(ecu_addr, '1003')
                    wait(0.5)
                    self._send_diagnostic_security(client, ecu_addr, '2701' if security_level == 'L1' else '2705',
                                                   security_level)
                elif client == self.client_fcm:
                    self.send_doip_fcm_request_verify_ecus_pos_rsp(ecu_addr, '1003')
                    wait(0.5)
                    self._send_diagnostic_security(client, ecu_addr, '2701' if security_level == 'L1' else '2705',
                                                   security_level)
            elif key_resp[-2:] == '35':
                wait(1)
                if client == self.client:
                    self.send_doip_request_verify_ecus_pos_rsp(ecu_addr, '1001')
                    wait(0.5)
                    self.send_doip_request_verify_ecus_pos_rsp(ecu_addr, '1003')
                    wait(0.5)
                    self._send_diagnostic_security(client, ecu_addr, '2701' if security_level == 'L1' else '2705',
                                                   security_level)
                elif client == self.client_apa:
                    self.send_doip_apa_request_verify_ecus_pos_rsp(ecu_addr, '1001')
                    wait(0.5)
                    self.send_doip_apa_request_verify_ecus_pos_rsp(ecu_addr, '1003')
                    wait(0.5)
                    self._send_diagnostic_security(client, ecu_addr, '2701' if security_level == 'L1' else '2705',
                                                   security_level)
                elif client == self.client_fcm:
                    self.send_doip_fcm_request_verify_ecus_pos_rsp(ecu_addr, '1001')
                    wait(0.5)
                    self.send_doip_fcm_request_verify_ecus_pos_rsp(ecu_addr, '1003')
                    wait(0.5)
                    self._send_diagnostic_security(client, ecu_addr, '2701' if security_level == 'L1' else '2705',
                                                   security_level)
            elif key_resp[-2:] == '36':
                print(f'Diagnostic Response -ve <-- {key_resp}')
                self.doip_report_fail(f'Number of Time Exceed Give IGN TOGGLE')
                return key_resp[-2:]
        else:
            self.doip_report_fail(f'Diagnostic Response -ve <-- {key_resp}')
        return None

    def send_diagnostic_security_l1(self, ecu_addr, diag_request: str) -> str:
        """
        Perform security access (Level 1) for the main ECU.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request (e.g., '2701').

        Returns:
            str: The NRC if security access fails with NRC '36', otherwise None.

        Raises:
            ContinuableFailure: If the security access fails with an unexpected response.
        """
        return self._send_diagnostic_security(self.client, ecu_addr, diag_request, 'L1')

    def send_apa_diagnostic_security_l1(self, ecu_addr, diag_request: str) -> str:
        """
        Perform security access (Level 1) for the APA ECU.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request (e.g., '2701').

        Returns:
            str: The NRC if security access fails with NRC '36', otherwise None.

        Raises:
            ContinuableFailure: If the security access fails with an unexpected response.
        """
        return self._send_diagnostic_security(self.client_apa, ecu_addr, diag_request, 'L1')

    def send_fcm_diagnostic_security_l1(self, ecu_addr, diag_request: str) -> str:
        """
        Perform security access (Level 1) for the FCM ECU.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request (e.g., '2701').

        Returns:
            str: The NRC if security access fails with NRC '36', otherwise None.

        Raises:
            ContinuableFailure: If the security access fails with an unexpected response.
        """
        return self._send_diagnostic_security(self.client_fcm, ecu_addr, diag_request, 'L1')

    def send_diagnostic_security_l3(self, ecu_addr, diag_request: str) -> str:
        """
        Perform security access (Level 3) for the main ECU.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request (e.g., '2705').

        Returns:
            str: The NRC if security access fails with NRC '36', otherwise None.

        Raises:
            ContinuableFailure: If the security access fails with an unexpected response.
        """
        return self._send_diagnostic_security(self.client, ecu_addr, diag_request, 'L3')

    def send_apa_diagnostic_security_l3(self, ecu_addr, diag_request: str) -> str:
        """
        Perform security access (Level 3) for the APA ECU.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request (e.g., '2705').

        Returns:
            str: The NRC if security access fails with NRC '36', otherwise None.

        Raises:
            ContinuableFailure: If the security access fails with an unexpected response.
        """
        return self._send_diagnostic_security(self.client_apa, ecu_addr, diag_request, 'L3')

    def send_fcm_diagnostic_security_l3(self, ecu_addr, diag_request: str) -> str:
        """
        Perform security access (Level 3) for the FCM ECU.

        Args:
            ecu_addr (int): The ECU address.
            diag_request (str): The diagnostic request (e.g., '2705').

        Returns:
            str: The NRC if security access fails with NRC '36', otherwise None.

        Raises:
            ContinuableFailure: If the security access fails with an unexpected response.
        """
        return self._send_diagnostic_security(self.client_fcm, ecu_addr, diag_request, 'L3')

    def transfer_data(self, segmented_string):
        """
        Transfer segmented data to the main ECU.

        Args:
            segmented_string (list): List of tuples containing (segment_number, segment) pairs.
        """
        for segment_number, segment in segmented_string:
            self.send_doip_request_transfer_data(f'36 {segment_number} {segment}')

    def send_ecus_transfer_data(self, ecu_addr, segmented_string):
        """
        Transfer segmented data to a specific ECU address.

        Args:
            ecu_addr (int): The ECU address.
            segmented_string (list): List of tuples containing (segment_number, segment) pairs.
        """
        for segment_number, segment in segmented_string:
            self.send_ecus_doip_request_transfer_data(ecu_addr, f'36 {segment_number} {segment}')

    def send_apa_transfer_data(self, ecu_addr, segmented_string):
        """
        Transfer segmented data to an APA ECU address.

        Args:
            ecu_addr (int): The ECU address.
            segmented_string (list): List of tuples containing (segment_number, segment) pairs.
        """
        for segment_number, segment in segmented_string:
            self.send_apa_ecus_doip_request_transfer_data(ecu_addr, f'36 {segment_number} {segment}')

    def send_fcm_transfer_data(self, ecu_addr, segmented_string):
        """
        Transfer segmented data to an FCM ECU address.

        Args:
            ecu_addr (int): The ECU address.
            segmented_string (list): List of tuples containing (segment_number, segment) pairs.
        """
        for segment_number, segment in segmented_string:
            self.send_fcm_ecus_doip_request_transfer_data(ecu_addr, f'36 {segment_number} {segment}')

    def send_func_doip_request_verify_response(self, diag_request: str, user_resp: str, user_resp2: str = None):
        """
        Send a functional diagnostic request and verify the response.

        Args:
            diag_request (str): The diagnostic request in hexadecimal string format.
            user_resp (str): The expected response in hexadecimal string format.
            user_resp2 (str, optional): An alternative expected response.

        Raises:
            ContinuableFailure: If the response does not match the expected values.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.func_diag_client.send_diagnostic(diag_request)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'7DF Diagnostic Request <-- {diag_request.hex()}')
        resp = binascii.hexlify(self.func_diag_client.receive_diagnostic(timeout=4.5)).decode().upper()
        stime = time.time()
        while True:
            if str(resp[:2]) != '7F':
                break
            if str(resp[-2:]) == '78':
                resp = binascii.hexlify(self.func_diag_client.receive_diagnostic(timeout=4.9)).decode().upper()
            if str(resp[-2:]) != '78':
                break
            if time.time() - stime > 300:
                print(f'5min waited Diagnostic Response +ve <-- {resp}')
                break
        if user_resp.replace(' ', '') == resp:
            print(
                "FUNC DIAG:7DF --> Obtained diagnostic response'{}', expected response'{}' for diagnostic request'{}'. TEST PASS.".format(
                    str(resp), str(user_resp.replace(' ', '')), str(diag_request.hex())))
        elif user_resp2 and user_resp2.replace(' ', '') == resp:
            print(
                "FUNC DIAG:7DF --> Obtained diagnostic response'{}', expected response'{}' for diagnostic request'{}'. TEST PASS.".format(
                    str(resp), str(user_resp2.replace(' ', '')), str(diag_request.hex())))
        else:
            self.doip_report_fail(
                "FUNC DIAG:7DF --> Obtained diagnostic response'{}', expected response'{}' or '{}' for diagnostic request'{}'. TEST FAIL.".format(
                    str(resp), str(user_resp.replace(' ', '')),
                    str(user_resp2.replace(' ', '') if user_resp2 else None),
                    str(diag_request.hex())))

    def send_func_doip_request_verify_no_resp(self, diag_request: str):
        """
        Send a functional diagnostic request and verify no response is received.

        Args:
            diag_request (str): The diagnostic request in hexadecimal string format.

        Raises:
            ContinuableFailure: If a response is received unexpectedly.
        """
        diag_request = self.convert_str_to_bytearray(diag_request)
        try:
            self.func_diag_client.send_diagnostic(diag_request, timeout=2)
        except AttributeError:
            self.doip_report_fail(f'Failed to send diagnostic request due to missing routing activation.')
        print(f'7DF Diagnostic Request <-- {diag_request.hex()}')
        try:
            resp = binascii.hexlify(self.func_diag_client.receive_diagnostic(timeout=2.5)).decode().upper()
            print(f'7DF Diagnostic Resp <-- {resp}')
            self.doip_report_fail(f'FUNC DIAG:7DF --> Diagnostic Response <-- {resp}')
        except TimeoutError:
            print('FUNC DIAG:7DF --> Diagnostic No Response Received')
