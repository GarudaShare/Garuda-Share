#!/bin/sh

RESIZE_FLAG="/var/lib/g3_resize_done"
ROOTDEVICE="/dev/mmcblk0"
ROOTPARTITION="/dev/mmcblk0p2"
SYS="/sys/block/mmcblk0"
ROOTFSNAME="/dev/root"
ROOTFSSIZE=`df | grep "${ROOTFSNAME}" | awk '{ print $2 }'`
LOWFSSIZE=$((256*1024))

TARGET_MB=512
SECTOR_SIZE=512

echo "ROOTFSSIZE=${ROOTFSSIZE}"
echo "LOWFSSIZE=${LOWFSSIZE}"
BOOT_DIR="/boot"

# Step 0: Clean /boot (delete everything except .itb and .itb.prev)
if [ -d "$BOOT_DIR" ]; then
    echo "Cleaning /boot, preserving .itb and .itb.prev files..."
    find "$BOOT_DIR" -maxdepth 1 -type f ! -name "*.itb" ! -name "*.itb.prev" -exec rm -f {} \;
fi
sync

# Step 1: fallback. partx failed earlier and we rebooted, so grow the filesystem now
if [ -f "${RESIZE_FLAG}" ]; then
    echo "Running resize2fs on ${ROOTPARTITION}..."
    resize2fs ${ROOTPARTITION}
    rm -f ${RESIZE_FLAG}
    echo "Filesystem resized successfully."
    exit 0
fi

# Step 2: if rootfs is small, extend the partition
if [ ${ROOTFSSIZE} -le ${LOWFSSIZE} ]; then
    START_SECTOR=$(cat ${SYS}/mmcblk0p2/start)
    SIZE_SECTORS=$((TARGET_MB * 1024 * 1024 / SECTOR_SIZE))
    END_SECTOR=$((START_SECTOR + SIZE_SECTORS - 1))
    echo "START_SECTOR=$START_SECTOR END_SECTOR=$END_SECTOR"

    # Safety 1: start sector must be a number
    case "$START_SECTOR" in
        ''|*[!0-9]*) echo "ERROR: bad start sector, aborting"; exit 1 ;;
    esac

    # Safety 2: the card must be big enough
    DISK_SECTORS=$(cat ${SYS}/size)
    if [ ${END_SECTOR} -ge ${DISK_SECTORS} ]; then
        echo "ERROR: card too small, aborting"; exit 1
    fi

    # Safety 3: no other partition (p3, extended p4, ...) may start inside the new p2 range
    for p in ${SYS}/mmcblk0p*; do
        [ "$p" = "${SYS}/mmcblk0p2" ] && continue
        S=$(cat $p/start)
        if [ ${S} -gt ${START_SECTOR} ] && [ ${S} -le ${END_SECTOR} ]; then
            echo "ERROR: $(basename $p) starts inside new p2 range, aborting"
            exit 1
        fi
    done

    # Backup the partition table
    dd if=${ROOTDEVICE} of=/var/lib/g3_mbr.bak bs=512 count=1 2>/dev/null

    sync
    printf "d\n2\nn\np\n2\n%s\n%s\nw\n" "$START_SECTOR" "$END_SECTOR" | fdisk ${ROOTDEVICE}
    sync

    # Tell the kernel the new size (no reboot needed)
    partx --update --nr 2 ${ROOTDEVICE}

    NEW_SECTORS=$(cat ${SYS}/mmcblk0p2/size)
    if [ ${NEW_SECTORS} -ge ${SIZE_SECTORS} ]; then
        echo "Kernel sees new size, running resize2fs online..."
        resize2fs ${ROOTPARTITION} && echo "Resized without reboot"
    else
        echo "partx did not work, will resize after reboot"
        touch ${RESIZE_FLAG}
    fi
fi
