# Copyright (c) 2023, Capgemini - Intelligent Devices
# All Rights Reserved.
#
# The information contained herein is confidential property of Capgemini.
# The use, copying, transfer or disclosure of such information is
# prohibited except by express written agreement with Capgemini.

inherit module

DESCRIPTION = "NXP Wi-Fi Driver for SD9177"
SUMMARY = "NXP Wi-Fi driver SD9177"
COMPATIBLE_MACHINE = "sama5d27-som1-ek-sd|sama5d29-garuda3-noremmc"

LICENSE = "GPL-2.0"
LIC_FILES_CHKSUM = "file://${WORKDIR}/git/LICENSE;md5=ab04ac0f249af12befccb94447c08b77"

# Source download info
GIT_SRC  = "git://github.com/nxp-imx/mwifiex.git"
SRCREV	 = "a84df583155bad2a396a937056805550bdf655ab"
BRANCH	 = "lf-6.6.3_1.0.0"
WLAN_SRC = "wlan_src"
MLAN	 = "${WLAN_SRC}/mlan"
MLINUX	 = "${WLAN_SRC}/mlinux"
FW	 = "firmware"
S	 = "${WORKDIR}/git/mxm_wifiex/wlan_src"
FW_INSTALL_PATH = "/lib/firmware/nxp"
MODULES_MODULE_SYMVERS_LOCATION = "${STAGING_KERNEL_BUILDDIR}"

CPPFLAGS += "-DSDIO"
CPPFLAGS += "-DSDIO_MMC"
CPPFLAGS += "-DCONFIG_OF"

CFLAGS += "-DSDIO"
CFLAGS += "-DSDIO_MMC"
CFLAGS += "-DCONFIG_OF"

FILESEXTRAPATHS:prepend := "${THISDIR}/${BP}_${PR}:"

SRC_URI = "${GIT_SRC};protocol=https;branch=${BRANCH} \
	file://${FW}/sduart_nw61x_v1.bin \
        file://${FW}/sduart_nw61x_v1.bin.se \
	file://${FW}/wifi_mod_para.conf \
	"

# Patch the Wi-Fi Driver's Makefile to disable PCIE interface
SRC_URI += "file://mwifiex-no_pcie_wifi-${PV}_${PR}.patch;patchdir=${WORKDIR}/git"

# TODO: bring in the firmware

EXTRA_OEMAKE = "KERNELDIR=${STAGING_KERNEL_DIR} -C ${STAGING_KERNEL_BUILDDIR} M=${S}"
EXTRA_OEMAKE += "INSTALL_MOD_PATH=${DEPLOY_DIR_MODULES}"

do_install:append() {
	bbdebug 1 "S=${S}"
	bbdebug 1 "D=${D}"
	bbdebug 1 "PN=${PN}"
	bbdebug 1 "PV=${PV}"
	bbdebug 1 "PR=${PR}"
	bbdebug 1 "BP=${BP}"
	bbdebug 1 "BPN=${BPN}"
	bbdebug 1 "THISDIR=${THISDIR}"
	bbdebug 1 "WORKDIR=${WORKDIR}"

    install -d ${D}/${FW_INSTALL_PATH}
    install -d ${D}/${sysconfdir}/init.d
    install -d ${D}/${sysconfdir}
    install -m 0644 ${D}/../${FW}/sduart_nw61x_v1.bin ${D}/${FW_INSTALL_PATH}
    install -m 0644 ${D}/../${FW}/sduart_nw61x_v1.bin.se ${D}/${FW_INSTALL_PATH}
    install -m 0644 ${D}/../${FW}/wifi_mod_para.conf ${D}/${FW_INSTALL_PATH}
}

FILES:${PN} += "${FW_INSTALL_PATH}"
FILES:${PN} += "${sysconfdir}"
FILES:${PN} += "${sysconfdir}/init.d"

