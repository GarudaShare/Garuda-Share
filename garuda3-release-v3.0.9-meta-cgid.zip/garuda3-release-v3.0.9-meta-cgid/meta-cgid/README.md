# meta-cgid 

meta-cgid is a yocto layer for small Linux system developed by Capgemini -
Intelligent Devices.  The layer has been initially created to support
building of Linux systems based on the Microchip SAMA5D29 SoC. Platforms
supported are
- Garuda 3 - a vehicle diagnostic platform with support for CAN, K-Line,
  J-1939 and Ethernet vehicle interfaces and USB, Bluetooth and Wi-Fi
  host interfaces.

## Build Resources
The following resources are useful to understand the build process for Garuda 3 which is based on the Microchip ATSAMD2XX family of microcontrollers.
- [ ] [SAMA5D2 PTC EK Board](https://www.linux4sam.org/bin/view/Linux4SAM/Sama5d2PtcEKMainPage)
- [ ] [SAMA5D2 Xplained Board](https://www.linux4sam.org/bin/view/Linux4SAM/Sama5d2XplainedMainPage)

## Building
Using the builder.sh script is the preferred way to build the project. This
way building is consistent and can be easily replicated by many developers
and the automated build system.
The builder script can be downloaded from the garuda3 directory.

## Installation / Deployment
To install the system on the target the built images need to be flashed on
the target using the appropriate tools.

## Testing
You can also document commands to lint the code or run tests. These steps help to ensure high code quality and reduce the likelihood that the changes inadvertently break something. Having instructions for running tests is especially helpful if it requires external setup, such as starting a Selenium server for testing in a browser.

## Usage
Use examples liberally, and show the expected output if you can. It's helpful to have inline the smallest example of usage that you can demonstrate, while providing links to more sophisticated examples if they are too long to reasonably include in the README.

## Roadmap
If you have ideas for releases in the future, it is a good idea to list them in the README.

## License
The main application software that is included in this project is Copyright (c) 2023, Capgemini Engineering - Digital (Intelligent Devices).

## Badges
On some READMEs, you may see small images that convey metadata, such as whether or not all the tests are passing for the project. You can use Shields to add some to your README. Many services also have instructions for adding a badge.

## Visuals
Depending on what you are making, it can be a good idea to include screenshots or even a video (you'll frequently see GIFs rather than actual videos). Tools like ttygif can help, but check out Asciinema for a more sophisticated method.

## Getting started

To make it easy for you to get started with GitLab, here's a list of recommended next steps.

Already a pro? Just edit this README.md and make it your own. Want to make it easy? [Use the template at the bottom](#editing-this-readme)!

# Editing this README

When you're ready to make this README your own, just edit this file and use the handy template below (or feel free to structure it however you want - this is just a starting point!).  Thank you to [makeareadme.com](https://www.makeareadme.com/) for this template.

## Add your files

- [ ] [Create](https://docs.gitlab.com/ee/user/project/repository/web_editor.html#create-a-file) or [upload](https://docs.gitlab.com/ee/user/project/repository/web_editor.html#upload-a-file) files
- [ ] [Add files using the command line](https://docs.gitlab.com/ee/gitlab-basics/add-file.html#add-a-file-using-the-command-line) or push an existing Git repository with the following command:

```
cd existing_repo
git remote add origin https://gs.globaledgesoft.com/garuda/garuda_3.git
git branch -M main
git push -uf origin main
```

## Integrate with your tools

- [ ] [Set up project integrations](https://gs.globaledgesoft.com/garuda/garuda_3/-/settings/integrations)

## Collaborate with your team

- [ ] [Invite team members and collaborators](https://docs.gitlab.com/ee/user/project/members/)
- [ ] [Create a new merge request](https://docs.gitlab.com/ee/user/project/merge_requests/creating_merge_requests.html)
- [ ] [Automatically close issues from merge requests](https://docs.gitlab.com/ee/user/project/issues/managing_issues.html#closing-issues-automatically)
- [ ] [Enable merge request approvals](https://docs.gitlab.com/ee/user/project/merge_requests/approvals/)
- [ ] [Automatically merge when pipeline succeeds](https://docs.gitlab.com/ee/user/project/merge_requests/merge_when_pipeline_succeeds.html)

## Test and Deploy

Use the built-in continuous integration in GitLab.

- [ ] [Get started with GitLab CI/CD](https://docs.gitlab.com/ee/ci/quick_start/index.html)
- [ ] [Analyze your code for known vulnerabilities with Static Application Security Testing(SAST)](https://docs.gitlab.com/ee/user/application_security/sast/)
- [ ] [Deploy to Kubernetes, Amazon EC2, or Amazon ECS using Auto Deploy](https://docs.gitlab.com/ee/topics/autodevops/requirements.html)
- [ ] [Use pull-based deployments for improved Kubernetes management](https://docs.gitlab.com/ee/user/clusters/agent/)
- [ ] [Set up protected environments](https://docs.gitlab.com/ee/ci/environments/protected_environments.html)

***
