This directory contains documents related to
    * source code build
    * testing plan and reports
