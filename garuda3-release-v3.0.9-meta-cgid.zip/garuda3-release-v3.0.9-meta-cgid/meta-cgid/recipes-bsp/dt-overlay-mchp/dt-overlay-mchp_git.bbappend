COMPATIBLE_MACHINE = "(sama5d29-garuda3-noremmc|sama5d29-garuda3-emmc)"

FILESEXTRAPATHS:prepend := "${THISDIR}/${PN}:"
SRC_URI:append:sama5d29-garuda3-noremmc = " file://sama5d29_garuda3.dtso;subdir=git/sama5d29_garuda3/"
SRC_URI:append:sama5d29-garuda3-noremmc = " file://sama5d29_garuda3.its;subdir=git"
SRC_URI:append:sama5d29-garuda3-noremmc = " file://Makefile;subdir=git"
#SRC_URI:append:sama5d29-garuda3-noremmc = " file://dt_overlay_check.sh;subdir=git/scripts/"



AT91BOOTSTRAP_MACHINE = "sama5d29_garuda3"

inherit deploy

DEPENDS = "virtual/kernel u-boot-mkimage-native dtc-native"

do_compile:append() {
	
		oe_runmake DTC=dtc KERNEL_DIR=${STAGING_KERNEL_DIR} KERNEL_BUILD_DIR=${KERNEL_PATH} ${AT91BOOTSTRAP_MACHINE}_dtbos
	
        	mkimage -D "-i${DEPLOY_DIR_IMAGE} -p 1000 ${DTC_OPTIONS}" -f sama5d29_garuda3.its sama5d29_garuda3.itb
}

FILES:${PN} = "/boot/*.*"


do_install:append:sama5d29-garuda3-noremmc() {
    # Copy files to /boot
    if [ -e ${WORKDIR}/git/sama5d29_garuda3 ]; then
        install -d ${D}/boot
        install ${WORKDIR}/git/sama5d29_garuda3/${AT91BOOTSTRAP_MACHINE}*.dtbo ${D}/boot
    fi;

    if [ -e ${WORKDIR}/git/sama5d29_garuda3/${AT91BOOTSTRAP_MACHINE}.itb ]; then
        install -d ${D}/boot
        install ${WORKDIR}/git/sama5d29_garuda3/${AT91BOOTSTRAP_MACHINE}.itb ${D}/boot/
        install ${WORKDIR}/git/sama5d29_garuda3/${AT91BOOTSTRAP_MACHINE}.its ${D}/boot/
    fi;
}

do_deploy:append:sama5d29-garuda3-noremmc() {
    #bbnote "Copying ${fit_image_basename}.itb and source file to ${DEPLOYDIR}..."
    if [ -e ${WORKDIR}/git/sama5d29_garuda3/${AT91BOOTSTRAP_MACHINE}.itb ]; then
        install ${WORKDIR}/git/sama5d29_garuda3/${AT91BOOTSTRAP_MACHINE}.itb ${DEPLOYDIR}/
        install ${WORKDIR}/git/sama5d29_garuda3/${AT91BOOTSTRAP_MACHINE}.its ${DEPLOYDIR}/
    fi;
}

ALLOW_EMPTY_${PN} = "1"
