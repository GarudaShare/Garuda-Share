COMPATIBLE_MACHINE = "(sama5d29-garuda3-noremmc|sama5d29-garuda3-emmc)"

AT91BOOTSTRAP_CONFIG:sama5d29-garuda3-noremmc ??= "${AT91BOOTSTRAP_MACHINE}-qspi_uboot"
AT91BOOTSTRAP_CONFIG:sama5d29-garuda3-emmc ??= "${AT91BOOTSTRAP_MACHINE}-emmc_uboot"

FILESEXTRAPATHS:prepend := "${THISDIR}/${PN}:"

AT91BOOTSTRAP_LOAD:sama5d29-garuda3-noremmc ??= "qspiboot-uboot"
AT91BOOTSTRAP_LOAD:sama5d29-garuda3-emmc ??= "emmcboot-uboot"

SRC_URI:append:sama5d29-garuda3-noremmc = " file://sama5d29-garuda3-qspi_uboot_defconfig;subdir=git/configs"
SRC_URI:append:sama5d29-garuda3-emmc = " file://sama5d29-garuda3-emmc_uboot_defconfig;subdir=git/configs"

