COMPATIBLE_MACHINE = "(sama5d29-garuda3-noremmc|sama5d29-garuda3-emmc)"

FILESEXTRAPATHS:prepend := "${THISDIR}/${PN}:"


SRC_URI:append:sama5d29-garuda3-noremmc = " file://sama5d29_garuda3_qspiflash_defconfig;subdir=git/configs"
SRC_URI:append:sama5d29-garuda3-noremmc = " file://at91-sama5d29_garuda3.dts;subdir=git/arch/arm/dts"
SRC_URI:append:sama5d29-garuda3-noremmc = " file://sama5d29-garuda3-noremmc.txt;subdir=envs"
SRC_URI:append:sama5d29-garuda3-noremmc = " file://sama5d29_garuda3/Makefile;subdir=git/board/atmel"
SRC_URI:append:sama5d29-garuda3-noremmc = " file://sama5d29_garuda3/MAINTAINERS;subdir=git/board/atmel"
SRC_URI:append:sama5d29-garuda3-noremmc = " file://sama5d29_garuda3/Kconfig;subdir=git/board/atmel"
SRC_URI:append:sama5d29-garuda3-noremmc = " file://sama5d29_garuda3/sama5d29_garuda3.c;subdir=git/board/atmel"
SRC_URI:append:sama5d29-garuda3-noremmc = " file://sama5d29_garuda3.h;subdir=git/include/configs"
SRC_URI:append:sama5d29-garuda3-noremmc = " file://Makefile;subdir=git/arch/arm/dts"
SRC_URI:append:sama5d29-garuda3-noremmc = " file://Kconfig;subdir=git/arch/arm/mach-at91"



#SRC_URI:append:sama5d29-garuda3-emmc = " file://sama5d29_garuda3_emmc_defconfig;subdir=git/configs"
#SRC_URI:append:sama5d29-garuda3-emmc = " file://at91-sama5d29_garuda3.dts;subdir=git/arch/arm/dts"
#SRC_URI:append:sama5d29-garuda3-emmc = " file://0001-Add-support-for-Garuda3-board.patch"
