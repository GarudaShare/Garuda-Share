FILESEXTRAPATHS:prepend := "${THISDIR}/${P}:"

SRC_URI:append:sama5d29-garuda3-noremmc = " file://sama5/defconfig"
SRC_URI:append:sama5d29-garuda3-emmc = " file://sama5/defconfig"

COMPATIBLE_MACHINE:sama5d29-garuda3-noremmc = "(sama5d29-garuda3-noremmc)"
COMPATIBLE_MACHINE:sama5d29-garuda3-emmc = "(sama5d29-garuda3-emmc)"

