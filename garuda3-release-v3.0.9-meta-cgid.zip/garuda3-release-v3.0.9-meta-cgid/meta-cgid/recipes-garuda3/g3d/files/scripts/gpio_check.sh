INET:Station is not Connected to AP


#list of GPIO pins
GPIO_LIST="PB14 PB21 PB20 PB15 PB19 PB18 PB16 PB17 PB22 PB23 PB13 PB24 PC9"

# Function to convert PBxx to GPIO number
convert_to_gpio() {
    port_letter=$(echo "$1" | cut -c2)  # Extract 'B' from 'PB14'
    pin_number=$(echo "$1" | cut -c3-)  # Extract '14' from 'PB14'

    port_number=$(($(printf "%d" "'$port_letter") - 65))  # Convert 'A'=0, 'B'=1, ...
    echo $(( port_number * 32 + pin_number ))
}

for gpio_label in $GPIO_LIST; do
    GPIO=$(convert_to_gpio "$gpio_label")

    echo "Checking GPIO: $gpio_label (GPIO$GPIO)..."

    # Export GPIO
    echo $GPIO > /sys/class/gpio/export 2>/dev/null

    # Read value (before setting direction)
    cat /sys/class/gpio/$gpio_label/value

    # Set direction and value
    echo out > /sys/class/gpio/$gpio_label/direction
    echo 0 > /sys/class/gpio/$gpio_label/value
    echo "reading set low "
    cat /sys/class/gpio/$gpio_label/value
    echo "reading set High"
    echo 1 > /sys/class/gpio/$gpio_label/value
    cat /sys/class/gpio/$gpio_label/value
done

