#include "stdafx.h"
#include "J2534Generic.h"
#include "doip.h"
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif
//-----------------------------------------------------------------------------
//	Function Name	: CDOIP
//	Input Params	: void
//	Output Params	: void
//	Description		: Constructor for CDOIP class
//-----------------------------------------------------------------------------
CDOIP::CDOIP(CDeviceBase* pclsDevice, CDebugLog* pclsDebugLog) :
	CProtocolBase(pclsDevice, pclsDebugLog)
{
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("doip.cpp", "CDOIP()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("doip.cpp", "CDOIP()", DEBUGLOG_TYPE_COMMENT,
			"End");
	}
	m_bLoopback = FALSE;
}

//-----------------------------------------------------------------------------
//	Function Name	: ~CDOIP
//	Input Params	: void
//	Output Params	: void
//	Description		: Destructor for CDOIP class
//-----------------------------------------------------------------------------
CDOIP::~CDOIP()
{
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("CDOIP.cpp", "~CDOIP()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Disconnect() incase not called yet.
	vDisconnect();

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("CDOIP.cpp", "~CDOIP()", DEBUGLOG_TYPE_COMMENT, "End");
	}
}

//-----------------------------------------------------------------------------
//	Function Name	: vConnect
//	Input Params	: 
//	Output Params	: 
//	Description		: This function establishes connection to the proctol.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR CDOIP::vConnect(
	J2534_PROTOCOL	enProtocolID,
	unsigned long   ulFlags,
	unsigned long	ulBaudRate,
	DEVICEBASE_CALLBACK_RX_FUNC pfnCallback,
	DEVICEBASE_CALLBACK_FC_FUNC pfirstframefnCallback,
	DEVICEBASE_CALLBACK_ISO15765_SETRXSTATUS_FUNC psetRxstatusfnCallback,
	LPVOID			pVoid)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char			szBuffer[DOIP_ERROR_TEXT_SIZE];
	J2534ERROR		enJ2534Error = J2534_ERR_NOT_SUPPORTED;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("DOIP.cpp", "vConnect()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	if (enProtocolID == DOIP_PROTOCOL_ID)
	{
		m_enDOIPProtocol = DOIP_PROTOCOL_ID;
	}

	// Call Connect of Base.
	if ((enJ2534Error = CProtocolBase::vConnect(enProtocolID,
		ulFlags,
		ulBaudRate,
		OnDOIPRxMessage,
		NULL, NULL,
		this)) != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("DOIP.cpp", "vConnect()", DEBUGLOG_TYPE_ERROR,
				szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("DOIP.cpp", "vConnect()", DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

	return(enJ2534Error);
}

//-----------------------------------------------------------------------------
//	Function Name	: vDisconnect
//	Input Params	: 
//	Output Params	: 
//	Description		: This function disconnects the connection to a protocol.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR CDOIP::vDisconnect()
{
	char			szBuffer[DOIP_ERROR_TEXT_SIZE];
	J2534ERROR		enJ2534Error;

	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("DOIP.cpp", "vDisconnect()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Disconnect this protocol.
	if ((enJ2534Error = CProtocolBase::vDisconnect()) != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("DOIP.cpp", "vDisconnect()", DEBUGLOG_TYPE_ERROR,
				szBuffer);
		}
		return(enJ2534Error);
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("DOIP.cpp", "CDOIP()", DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

void OnDOIPRxMessage(PASSTHRU_MSG* pstPassThruMsg, LPVOID pVoid)
{
	CDOIP* pclsDOIP;
	FILTERMSG_CONFORM_REQ	stConformReq;

	pclsDOIP = (CDOIP*)pVoid;

	// Check for NULL pointer.
	if (pclsDOIP == NULL)
	{
		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			CProtocolBase::m_pclsLog->Write("doip.cpp", "OnDOIPRxMessage()",
				DEBUGLOG_TYPE_COMMENT, "NULL pointer");
		}
		return;
	}

	// Check if this is a Loopback message.
	if (pstPassThruMsg->ulRxStatus & J2534_RX_FLAGBIT_MSGTYPE)
	{
		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			CProtocolBase::m_pclsLog->Write("doip.cpp", "OnDOIPRxMessage()", DEBUGLOG_TYPE_COMMENT, "Tx CALLBACK");
		}
		if (pclsDOIP->m_bLoopback == false)
			return;

		// Enqueue to Circ Buffer.
		pclsDOIP->m_pclsRxCircBuffer->Write((unsigned char*)pstPassThruMsg,
			(sizeof(PASSTHRU_MSG) - sizeof(pstPassThruMsg->ucData) +
				pstPassThruMsg->ulDataSize));
		return;
	}
	else
	{
		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			CProtocolBase::m_pclsLog->Write("doip.cpp", "OnDOIPRxMessage()", DEBUGLOG_TYPE_COMMENT, "Tx CALLBACK");
		}

		// Enqueue to Circ Buffer.
		pclsDOIP->m_pclsRxCircBuffer->Write((unsigned char*)pstPassThruMsg,
			(sizeof(PASSTHRU_MSG) - sizeof(pstPassThruMsg->ucData) +
				pstPassThruMsg->ulDataSize));
		return;
	}
	
	if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
	{
		CProtocolBase::m_pclsLog->Write("doip.cpp", "OnDOIPRxMessage()", DEBUGLOG_TYPE_COMMENT, "Rx CALLBACK");
	}
	// Apply Filters and see if msg. is required.
	if (pclsDOIP->m_pclsFilterMsg != NULL)
	{
		stConformReq.bReqPass = true;
		stConformReq.bReqBlock = true;
		if (pclsDOIP->m_pclsFilterMsg->IsMsgRequired(pstPassThruMsg, &stConformReq))
		{
			if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
			{
				CProtocolBase::m_pclsLog->Write("doip.cpp", "OnDOIPRxMessage()",
					DEBUGLOG_TYPE_COMMENT, "Rx CALLBACK PreEnd");
			}
			// Enqueue to Circ Buffer.
			pclsDOIP->m_pclsRxCircBuffer->Write((unsigned char*)pstPassThruMsg,
				(sizeof(PASSTHRU_MSG) - sizeof(pstPassThruMsg->ucData) +
					pstPassThruMsg->ulDataSize));
		}
	}

	if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
	{
		CProtocolBase::m_pclsLog->Write("doip.cpp", "OnDOIPRxMessage()",
			DEBUGLOG_TYPE_COMMENT, "Rx CALLBACK End");
	}
	return;
}


//-----------------------------------------------------------------------------
//	Function Name	: vIoctl
//	Input Params	: 
//	Output Params	: 
//	Description		: This is a virtual function. This function is used to read
//					  and write all the protocol hardware and software
//					  configuration parameters for a given enumIoctlID.
//-----------------------------------------------------------------------------
J2534ERROR  CDOIP::vIoctl(J2534IOCTLID enumIoctlID,
	void* pInput,
	void* pOutput)
{
	J2534ERROR	enumJ2534Error;
	char	szBuffer[CAN_ERROR_TEXT_SIZE];
	enumJ2534Error = J2534_STATUS_NOERROR;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("doip.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, "Start");
	}
	if (enumIoctlID == 0x00000012 )
	{
		enumIoctlID = (J2534IOCTLID) GET_IP_ADDRESS;
	}
	// IoctlID values
	switch (enumIoctlID)
	{
     case GET_IP_ADDRESS:
	 {
		 if (enumJ2534Error = CProtocolBase::vIoctl(enumIoctlID,
			 pInput,
			 pOutput))
		 {
			 if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			 {
				 sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
				 enumJ2534Error = CProtocolBase::vIoctl(GET_IP_ADDRESS, NULL, NULL);
				 m_pclsLog->Write("doip.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR,
					 szBuffer);
			 }
			 return(enumJ2534Error);
		 }
		 break;
	 }
	 case CLEAR_TX_BUFFER:		// Clear all messages in its receive queue
		 if (m_pclsTxCircBuffer != NULL)
		 {
			 m_pclsTxCircBuffer->ClearBuffer();
			 //	 enumJ2534Error = CProtocolBase::vIoctl(CLEAR_TX_BUFFER, NULL, NULL);
			 //	 m_pclsTxCircBuffer->ClearBuffer();
			 enumJ2534Error = J2534_STATUS_NOERROR;
		 }
		 break;
	 case CLEAR_RX_BUFFER:		// Clear all messages in its receive queue
/*		 if (m_pclsTxCircBuffer != NULL)
		 {
			 m_pclsTxCircBuffer->ClearBuffer();
			 //	 enumJ2534Error = CProtocolBase::vIoctl(CLEAR_TX_BUFFER, NULL, NULL);
			 //	 m_pclsTxCircBuffer->ClearBuffer();
			 enumJ2534Error = J2534_STATUS_NOERROR;
		 }*/
		 if (m_pclsRxCircBuffer != NULL)
		 {
		//	 m_pclsRxCircBuffer->ClearBuffer();
		//	 enumJ2534Error = CProtocolBase::vIoctl(CLEAR_RX_BUFFER, NULL, NULL);
			 m_pclsRxCircBuffer->ClearBuffer();
			 enumJ2534Error = J2534_STATUS_NOERROR;
		 }
		 break;
		// Others not supported
	default:
		enumJ2534Error = J2534_ERR_NOT_SUPPORTED;
		break;
	}
	if (enumJ2534Error != J2534_STATUS_NOERROR)
	{
		// Write status to Log File.
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
			m_pclsLog->Write("doip.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, szBuffer);
		}
	}
	else
	{
		// Write status to Log File.
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
			m_pclsLog->Write("doip.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, szBuffer);
		}
	}
	return(enumJ2534Error);
}
//-----------------------------------------------------------------------------
//	Function Name	: vWriteMsgs
//	Input Params	: 
//	Output Params	: 
//	Description		: This function writes the message out to a circular buffer
//					  and waits until it is transmitted out on the bus or exits
//					  immediately after writing to buffer if it is non-blocking.
//					  The message is Blocking if the given timeout value is 
//					  greater than 0. The base class implements the generic 
//					  functionality. Any specific functionality to this derived
//					  class is implented here.
//-----------------------------------------------------------------------------
J2534ERROR CDOIP::vWriteMsgs(PASSTHRU_MSG* pstPassThruMsg,
	unsigned long* pulNumMsgs,
	unsigned long	ulTimeout)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char		szBuffer[CAN_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;
	unsigned long	ulIdx1;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("doip.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_COMMENT,
			"Start");
	}

	for (ulIdx1 = 0; ulIdx1 < *pulNumMsgs; ulIdx1++)
	{
		// Check Msg. Protocol ID.
		if ((pstPassThruMsg + ulIdx1)->ulProtocolID != m_enDOIPProtocol)
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_MSG_PROTOCOL_ID);
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("doip.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_ERROR,
					szBuffer);
			}
			return(J2534_ERR_MSG_PROTOCOL_ID);
		}

		// Check if msg. format is valid.
/*		if (!IsMsgValid((pstPassThruMsg + ulIdx1)))
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("doip.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_ERROR,
					szBuffer);
			}
			return(J2534_ERR_INVALID_MSG);
		}*/
	}
	// Write using the generic Write.
	if ((enJ2534Error = CProtocolBase::vWriteMsgs(pstPassThruMsg,
		pulNumMsgs,
		ulTimeout))
		!= J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("doip.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_ERROR,
				szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("doip.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_COMMENT,
			szBuffer);
	}
	return(J2534_STATUS_NOERROR);
}
//-----------------------------------------------------------------------------
//	Function Name	: vReadMsgs
//	Input Params	: 
//	Output Params	: 
//	Description		: This function reads the messages out of a circular buffer
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here. 
//-----------------------------------------------------------------------------
J2534ERROR CDOIP::vReadMsgs(PASSTHRU_MSG* pstPassThruMsg,
	unsigned long* pulNumMsgs,
	unsigned long	ulTimeout)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char		szBuffer[ISO15765_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("doip.cpp", "vReadMsgs()", m_enDOIPProtocol, DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write using the generic Write.
	if ((enJ2534Error = CProtocolBase::vReadMsgs(pstPassThruMsg,
		pulNumMsgs,
		ulTimeout))
		!= J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("doip.cpp", "vReadMsgs()", m_enDOIPProtocol, DEBUGLOG_TYPE_ERROR,
				szBuffer);
		}
/*		if (enJ2534Error == J2534_ERR_BUFFER_EMPTY)
		{
			if (((m_pclsFilterMsg == NULL) || (!m_pclsFilterMsg->IsFlowControlFilterSet())))
			{
				sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NO_FLOW_CONTROL);
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					m_pclsLog->Write("doip.cpp", "vReadMsgs()", m_enDOIPProtocol, DEBUGLOG_TYPE_ERROR,
						szBuffer);
				}
				return(J2534_ERR_NO_FLOW_CONTROL);
			}
		}*/
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("doip.cpp", "vReadMsgs()", m_enDOIPProtocol, DEBUGLOG_TYPE_COMMENT,
			szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}