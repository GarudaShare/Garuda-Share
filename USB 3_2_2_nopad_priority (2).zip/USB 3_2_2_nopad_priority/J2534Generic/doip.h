#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ProtocolBase.h"

void OnDOIPRxMessage(PASSTHRU_MSG* pstPassThruMsg, LPVOID pVoid);
class CDOIP : public CProtocolBase
{
public:
	CDOIP(CDeviceBase* pclsDevice, CDebugLog* pclsDebugLog = NULL);
	~CDOIP();
	virtual J2534ERROR	vConnect(
		J2534_PROTOCOL enProtocolID,
		unsigned long ulFlags,
		unsigned long ulBaudRate,
		DEVICEBASE_CALLBACK_RX_FUNC pfnCallback = NULL,
		DEVICEBASE_CALLBACK_FC_FUNC pfirstframefnCallback = NULL,
		DEVICEBASE_CALLBACK_ISO15765_SETRXSTATUS_FUNC psetRxstatusfnCallback = NULL,
		LPVOID		  pVoid = NULL);
	virtual J2534ERROR	vDisconnect();
	virtual J2534ERROR	vIoctl(J2534IOCTLID enumIoctlID,
		void* pInput,
		void* pOutput);
	virtual J2534ERROR	vWriteMsgs(
		PASSTHRU_MSG* pstrucJ2534Msg,
		unsigned long* pulNumMsgs,
		unsigned long ulTimeout);
	virtual J2534ERROR	vReadMsgs(
		PASSTHRU_MSG* pstrucJ2534Msg,
		unsigned long* pulNumMsgs,
		unsigned long ulTimeout);
		
public:
	J2534_PROTOCOL			m_enDOIPProtocol;
};
