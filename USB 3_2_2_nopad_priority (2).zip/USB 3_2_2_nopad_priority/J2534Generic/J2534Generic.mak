# Microsoft Developer Studio Generated NMAKE File, Based on J2534Generic.dsp
!IF "$(CFG)" == ""
CFG=J2534Generic - Win32 Debug
!MESSAGE No configuration specified. Defaulting to J2534Generic - Win32 Debug.
!ENDIF 

!IF "$(CFG)" != "J2534Generic - Win32 Release" && "$(CFG)" != "J2534Generic - Win32 Debug"
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "J2534Generic.mak" CFG="J2534Generic - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "J2534Generic - Win32 Release" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE "J2534Generic - Win32 Debug" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE 
!ERROR An invalid configuration is specified.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 

!IF  "$(CFG)" == "J2534Generic - Win32 Release"

OUTDIR=.\Release
INTDIR=.\Release
# Begin Custom Macros
OutDir=.\Release
# End Custom Macros

ALL : "..\..\..\..\Windows\System32\Innova40432.dll" "$(OUTDIR)\J2534Generic.bsc"


CLEAN :
	-@erase "$(INTDIR)\CAN.obj"
	-@erase "$(INTDIR)\CAN.sbr"
	-@erase "$(INTDIR)\CCD.obj"
	-@erase "$(INTDIR)\CCD.sbr"
	-@erase "$(INTDIR)\CircBuffer.obj"
	-@erase "$(INTDIR)\CircBuffer.sbr"
	-@erase "$(INTDIR)\DebugLog.obj"
	-@erase "$(INTDIR)\DebugLog.sbr"
	-@erase "$(INTDIR)\FilterMsg.obj"
	-@erase "$(INTDIR)\FilterMsg.sbr"
	-@erase "$(INTDIR)\ISO14230.obj"
	-@erase "$(INTDIR)\ISO14230.sbr"
	-@erase "$(INTDIR)\ISO15765.obj"
	-@erase "$(INTDIR)\ISO15765.sbr"
	-@erase "$(INTDIR)\ISO9141.obj"
	-@erase "$(INTDIR)\ISO9141.sbr"
	-@erase "$(INTDIR)\J1850PWM.obj"
	-@erase "$(INTDIR)\J1850PWM.sbr"
	-@erase "$(INTDIR)\J1850VPW.obj"
	-@erase "$(INTDIR)\J1850VPW.sbr"
	-@erase "$(INTDIR)\J2534Export.obj"
	-@erase "$(INTDIR)\J2534Export.sbr"
	-@erase "$(INTDIR)\J2534Generic.obj"
	-@erase "$(INTDIR)\J2534Generic.pch"
	-@erase "$(INTDIR)\J2534Generic.res"
	-@erase "$(INTDIR)\J2534Generic.sbr"
	-@erase "$(INTDIR)\J2534Registry.obj"
	-@erase "$(INTDIR)\J2534Registry.sbr"
	-@erase "$(INTDIR)\PeriodicMsg.obj"
	-@erase "$(INTDIR)\PeriodicMsg.sbr"
	-@erase "$(INTDIR)\ProtocolBase.obj"
	-@erase "$(INTDIR)\ProtocolBase.sbr"
	-@erase "$(INTDIR)\ProtocolManager.obj"
	-@erase "$(INTDIR)\ProtocolManager.sbr"
	-@erase "$(INTDIR)\SCI.obj"
	-@erase "$(INTDIR)\SCI.sbr"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\StdAfx.sbr"
	-@erase "$(INTDIR)\SWCAN.obj"
	-@erase "$(INTDIR)\SWCAN.sbr"
	-@erase "$(INTDIR)\SWISO15765.obj"
	-@erase "$(INTDIR)\SWISO15765.sbr"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(OUTDIR)\Innova40432.exp"
	-@erase "$(OUTDIR)\Innova40432.lib"
	-@erase "$(OUTDIR)\J2534Generic.bsc"
	-@erase "..\..\..\..\Windows\System32\Innova40432.dll"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_WINDLL" /D "_AFXDLL" /D "_MBCS" /D "_USRDLL" /FR"$(INTDIR)\\" /Fp"$(INTDIR)\J2534Generic.pch" /Yu"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

MTL=midl.exe
MTL_PROJ=/nologo /D "NDEBUG" /mktyplib203 /win32 
RSC=rc.exe
RSC_PROJ=/l 0x409 /fo"$(INTDIR)\J2534Generic.res" /d "NDEBUG" /d "_AFXDLL" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\J2534Generic.bsc" 
BSC32_SBRS= \
	"$(INTDIR)\CAN.sbr" \
	"$(INTDIR)\CCD.sbr" \
	"$(INTDIR)\CircBuffer.sbr" \
	"$(INTDIR)\DebugLog.sbr" \
	"$(INTDIR)\FilterMsg.sbr" \
	"$(INTDIR)\ISO14230.sbr" \
	"$(INTDIR)\ISO15765.sbr" \
	"$(INTDIR)\ISO9141.sbr" \
	"$(INTDIR)\J1850PWM.sbr" \
	"$(INTDIR)\J1850VPW.sbr" \
	"$(INTDIR)\J2534Export.sbr" \
	"$(INTDIR)\J2534Generic.sbr" \
	"$(INTDIR)\J2534Registry.sbr" \
	"$(INTDIR)\PeriodicMsg.sbr" \
	"$(INTDIR)\ProtocolBase.sbr" \
	"$(INTDIR)\ProtocolManager.sbr" \
	"$(INTDIR)\SCI.sbr" \
	"$(INTDIR)\StdAfx.sbr" \
	"$(INTDIR)\SWCAN.sbr" \
	"$(INTDIR)\SWISO15765.sbr"

"$(OUTDIR)\J2534Generic.bsc" : "$(OUTDIR)" $(BSC32_SBRS)
    $(BSC32) @<<
  $(BSC32_FLAGS) $(BSC32_SBRS)
<<

LINK32=link.exe
LINK32_FLAGS=Version.lib hid.lib setupapi.lib DeviceOEMTool.lib /nologo /subsystem:windows /dll /incremental:no /pdb:"$(OUTDIR)\Innova40432.pdb" /machine:I386 /def:".\J2534Generic.def" /out:"c:\Windows\System32\Innova40432.dll" /implib:"$(OUTDIR)\Innova40432.lib" 
DEF_FILE= \
	".\J2534Generic.def"
LINK32_OBJS= \
	"$(INTDIR)\CAN.obj" \
	"$(INTDIR)\CCD.obj" \
	"$(INTDIR)\CircBuffer.obj" \
	"$(INTDIR)\DebugLog.obj" \
	"$(INTDIR)\FilterMsg.obj" \
	"$(INTDIR)\ISO14230.obj" \
	"$(INTDIR)\ISO15765.obj" \
	"$(INTDIR)\ISO9141.obj" \
	"$(INTDIR)\J1850PWM.obj" \
	"$(INTDIR)\J1850VPW.obj" \
	"$(INTDIR)\J2534Export.obj" \
	"$(INTDIR)\J2534Generic.obj" \
	"$(INTDIR)\J2534Registry.obj" \
	"$(INTDIR)\PeriodicMsg.obj" \
	"$(INTDIR)\ProtocolBase.obj" \
	"$(INTDIR)\ProtocolManager.obj" \
	"$(INTDIR)\SCI.obj" \
	"$(INTDIR)\StdAfx.obj" \
	"$(INTDIR)\SWCAN.obj" \
	"$(INTDIR)\SWISO15765.obj" \
	"$(INTDIR)\J2534Generic.res"

"..\..\..\..\Windows\System32\Innova40432.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "J2534Generic - Win32 Debug"

OUTDIR=.\Debug
INTDIR=.\Debug
# Begin Custom Macros
OutDir=.\Debug
# End Custom Macros

ALL : "..\..\..\..\Windows\System32\Innova40432.dll" "$(OUTDIR)\J2534Generic.bsc"


CLEAN :
	-@erase "$(INTDIR)\CAN.obj"
	-@erase "$(INTDIR)\CAN.sbr"
	-@erase "$(INTDIR)\CCD.obj"
	-@erase "$(INTDIR)\CCD.sbr"
	-@erase "$(INTDIR)\CircBuffer.obj"
	-@erase "$(INTDIR)\CircBuffer.sbr"
	-@erase "$(INTDIR)\DebugLog.obj"
	-@erase "$(INTDIR)\DebugLog.sbr"
	-@erase "$(INTDIR)\FilterMsg.obj"
	-@erase "$(INTDIR)\FilterMsg.sbr"
	-@erase "$(INTDIR)\ISO14230.obj"
	-@erase "$(INTDIR)\ISO14230.sbr"
	-@erase "$(INTDIR)\ISO15765.obj"
	-@erase "$(INTDIR)\ISO15765.sbr"
	-@erase "$(INTDIR)\ISO9141.obj"
	-@erase "$(INTDIR)\ISO9141.sbr"
	-@erase "$(INTDIR)\J1850PWM.obj"
	-@erase "$(INTDIR)\J1850PWM.sbr"
	-@erase "$(INTDIR)\J1850VPW.obj"
	-@erase "$(INTDIR)\J1850VPW.sbr"
	-@erase "$(INTDIR)\J2534Export.obj"
	-@erase "$(INTDIR)\J2534Export.sbr"
	-@erase "$(INTDIR)\J2534Generic.obj"
	-@erase "$(INTDIR)\J2534Generic.pch"
	-@erase "$(INTDIR)\J2534Generic.res"
	-@erase "$(INTDIR)\J2534Generic.sbr"
	-@erase "$(INTDIR)\J2534Registry.obj"
	-@erase "$(INTDIR)\J2534Registry.sbr"
	-@erase "$(INTDIR)\PeriodicMsg.obj"
	-@erase "$(INTDIR)\PeriodicMsg.sbr"
	-@erase "$(INTDIR)\ProtocolBase.obj"
	-@erase "$(INTDIR)\ProtocolBase.sbr"
	-@erase "$(INTDIR)\ProtocolManager.obj"
	-@erase "$(INTDIR)\ProtocolManager.sbr"
	-@erase "$(INTDIR)\SCI.obj"
	-@erase "$(INTDIR)\SCI.sbr"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\StdAfx.sbr"
	-@erase "$(INTDIR)\SWCAN.obj"
	-@erase "$(INTDIR)\SWCAN.sbr"
	-@erase "$(INTDIR)\SWISO15765.obj"
	-@erase "$(INTDIR)\SWISO15765.sbr"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\vc60.pdb"
	-@erase "$(OUTDIR)\Innova40432.exp"
	-@erase "$(OUTDIR)\Innova40432.lib"
	-@erase "$(OUTDIR)\Innova40432.pdb"
	-@erase "$(OUTDIR)\J2534Generic.bsc"
	-@erase "..\..\..\..\Windows\System32\Innova40432.dll"
	-@erase "..\..\..\..\Windows\System32\Innova40432.ilk"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_WINDLL" /D "_AFXDLL" /D "_MBCS" /D "_USRDLL" /FR"$(INTDIR)\\" /Fp"$(INTDIR)\J2534Generic.pch" /Yu"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /GZ /c 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

MTL=midl.exe
MTL_PROJ=/nologo /D "_DEBUG" /mktyplib203 /win32 
RSC=rc.exe
RSC_PROJ=/l 0x409 /fo"$(INTDIR)\J2534Generic.res" /d "_DEBUG" /d "_AFXDLL" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\J2534Generic.bsc" 
BSC32_SBRS= \
	"$(INTDIR)\CAN.sbr" \
	"$(INTDIR)\CCD.sbr" \
	"$(INTDIR)\CircBuffer.sbr" \
	"$(INTDIR)\DebugLog.sbr" \
	"$(INTDIR)\FilterMsg.sbr" \
	"$(INTDIR)\ISO14230.sbr" \
	"$(INTDIR)\ISO15765.sbr" \
	"$(INTDIR)\ISO9141.sbr" \
	"$(INTDIR)\J1850PWM.sbr" \
	"$(INTDIR)\J1850VPW.sbr" \
	"$(INTDIR)\J2534Export.sbr" \
	"$(INTDIR)\J2534Generic.sbr" \
	"$(INTDIR)\J2534Registry.sbr" \
	"$(INTDIR)\PeriodicMsg.sbr" \
	"$(INTDIR)\ProtocolBase.sbr" \
	"$(INTDIR)\ProtocolManager.sbr" \
	"$(INTDIR)\SCI.sbr" \
	"$(INTDIR)\StdAfx.sbr" \
	"$(INTDIR)\SWCAN.sbr" \
	"$(INTDIR)\SWISO15765.sbr"

"$(OUTDIR)\J2534Generic.bsc" : "$(OUTDIR)" $(BSC32_SBRS)
    $(BSC32) @<<
  $(BSC32_FLAGS) $(BSC32_SBRS)
<<

LINK32=link.exe
LINK32_FLAGS=Version.lib hid.lib setupapi.lib DeviceOEMTool.lib /nologo /subsystem:windows /dll /incremental:yes /pdb:"$(OUTDIR)\Innova40432.pdb" /debug /machine:I386 /def:".\J2534Generic.def" /out:"c:\Windows\System32\Innova40432.dll" /implib:"$(OUTDIR)\Innova40432.lib" /pdbtype:sept 
DEF_FILE= \
	".\J2534Generic.def"
LINK32_OBJS= \
	"$(INTDIR)\CAN.obj" \
	"$(INTDIR)\CCD.obj" \
	"$(INTDIR)\CircBuffer.obj" \
	"$(INTDIR)\DebugLog.obj" \
	"$(INTDIR)\FilterMsg.obj" \
	"$(INTDIR)\ISO14230.obj" \
	"$(INTDIR)\ISO15765.obj" \
	"$(INTDIR)\ISO9141.obj" \
	"$(INTDIR)\J1850PWM.obj" \
	"$(INTDIR)\J1850VPW.obj" \
	"$(INTDIR)\J2534Export.obj" \
	"$(INTDIR)\J2534Generic.obj" \
	"$(INTDIR)\J2534Registry.obj" \
	"$(INTDIR)\PeriodicMsg.obj" \
	"$(INTDIR)\ProtocolBase.obj" \
	"$(INTDIR)\ProtocolManager.obj" \
	"$(INTDIR)\SCI.obj" \
	"$(INTDIR)\StdAfx.obj" \
	"$(INTDIR)\SWCAN.obj" \
	"$(INTDIR)\SWISO15765.obj" \
	"$(INTDIR)\J2534Generic.res"

"..\..\..\..\Windows\System32\Innova40432.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ENDIF 


!IF "$(NO_EXTERNAL_DEPS)" != "1"
!IF EXISTS("J2534Generic.dep")
!INCLUDE "J2534Generic.dep"
!ELSE 
!MESSAGE Warning: cannot find "J2534Generic.dep"
!ENDIF 
!ENDIF 


!IF "$(CFG)" == "J2534Generic - Win32 Release" || "$(CFG)" == "J2534Generic - Win32 Debug"
SOURCE=.\CAN.cpp

"$(INTDIR)\CAN.obj"	"$(INTDIR)\CAN.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\J2534Generic.pch"


SOURCE=.\CCD.cpp

"$(INTDIR)\CCD.obj"	"$(INTDIR)\CCD.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\J2534Generic.pch"


SOURCE=.\CircBuffer.cpp

"$(INTDIR)\CircBuffer.obj"	"$(INTDIR)\CircBuffer.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\J2534Generic.pch"


SOURCE=.\DebugLog.cpp

"$(INTDIR)\DebugLog.obj"	"$(INTDIR)\DebugLog.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\J2534Generic.pch"


SOURCE=.\FilterMsg.cpp

"$(INTDIR)\FilterMsg.obj"	"$(INTDIR)\FilterMsg.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\J2534Generic.pch"


SOURCE=.\ISO14230.cpp

"$(INTDIR)\ISO14230.obj"	"$(INTDIR)\ISO14230.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\J2534Generic.pch"


SOURCE=.\ISO15765.cpp

"$(INTDIR)\ISO15765.obj"	"$(INTDIR)\ISO15765.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\J2534Generic.pch"


SOURCE=.\ISO9141.cpp

"$(INTDIR)\ISO9141.obj"	"$(INTDIR)\ISO9141.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\J2534Generic.pch"


SOURCE=.\J1850PWM.cpp

"$(INTDIR)\J1850PWM.obj"	"$(INTDIR)\J1850PWM.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\J2534Generic.pch"


SOURCE=.\J1850VPW.cpp

"$(INTDIR)\J1850VPW.obj"	"$(INTDIR)\J1850VPW.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\J2534Generic.pch"


SOURCE=.\J2534Export.cpp

"$(INTDIR)\J2534Export.obj"	"$(INTDIR)\J2534Export.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\J2534Generic.pch"


SOURCE=.\J2534Generic.cpp

"$(INTDIR)\J2534Generic.obj"	"$(INTDIR)\J2534Generic.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\J2534Generic.pch"


SOURCE=.\J2534Generic.rc

"$(INTDIR)\J2534Generic.res" : $(SOURCE) "$(INTDIR)"
	$(RSC) $(RSC_PROJ) $(SOURCE)


SOURCE=.\J2534Registry.cpp

"$(INTDIR)\J2534Registry.obj"	"$(INTDIR)\J2534Registry.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\J2534Generic.pch"


SOURCE=.\PeriodicMsg.cpp

"$(INTDIR)\PeriodicMsg.obj"	"$(INTDIR)\PeriodicMsg.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\J2534Generic.pch"


SOURCE=.\ProtocolBase.cpp

"$(INTDIR)\ProtocolBase.obj"	"$(INTDIR)\ProtocolBase.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\J2534Generic.pch"


SOURCE=.\ProtocolManager.cpp

"$(INTDIR)\ProtocolManager.obj"	"$(INTDIR)\ProtocolManager.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\J2534Generic.pch"


SOURCE=.\SCI.cpp

"$(INTDIR)\SCI.obj"	"$(INTDIR)\SCI.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\J2534Generic.pch"


SOURCE=.\StdAfx.cpp

!IF  "$(CFG)" == "J2534Generic - Win32 Release"

CPP_SWITCHES=/nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_WINDLL" /D "_AFXDLL" /D "_MBCS" /D "_USRDLL" /FR"$(INTDIR)\\" /Fp"$(INTDIR)\J2534Generic.pch" /Yc"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\StdAfx.sbr"	"$(INTDIR)\J2534Generic.pch" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "J2534Generic - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_WINDLL" /D "_AFXDLL" /D "_MBCS" /D "_USRDLL" /FR"$(INTDIR)\\" /Fp"$(INTDIR)\J2534Generic.pch" /Yc"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /GZ /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\StdAfx.sbr"	"$(INTDIR)\J2534Generic.pch" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\SWCAN.cpp

"$(INTDIR)\SWCAN.obj"	"$(INTDIR)\SWCAN.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\J2534Generic.pch"


SOURCE=.\SWISO15765.cpp

"$(INTDIR)\SWISO15765.obj"	"$(INTDIR)\SWISO15765.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\J2534Generic.pch"



!ENDIF 

