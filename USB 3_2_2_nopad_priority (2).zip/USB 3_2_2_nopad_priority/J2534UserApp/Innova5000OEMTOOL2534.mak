# Microsoft Developer Studio Generated NMAKE File, Based on Innova5000OEMTOOL2534.dsp
!IF "$(CFG)" == ""
CFG=Innova5000OEMTOOL2534 - Win32 Debug
!MESSAGE No configuration specified. Defaulting to Innova5000OEMTOOL2534 - Win32 Debug.
!ENDIF 

!IF "$(CFG)" != "Innova5000OEMTOOL2534 - Win32 Release" && "$(CFG)" != "Innova5000OEMTOOL2534 - Win32 Debug"
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "Innova5000OEMTOOL2534.mak" CFG="Innova5000OEMTOOL2534 - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "Innova5000OEMTOOL2534 - Win32 Release" (based on "Win32 (x86) Application")
!MESSAGE "Innova5000OEMTOOL2534 - Win32 Debug" (based on "Win32 (x86) Application")
!MESSAGE 
!ERROR An invalid configuration is specified.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 

CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "Innova5000OEMTOOL2534 - Win32 Release"

OUTDIR=.\Release
INTDIR=.\Release
# Begin Custom Macros
OutDir=.\Release
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "$(OUTDIR)\Innova5000OEMTOOL2534.exe" "$(OUTDIR)\Innova5000OEMTOOL2534.bsc"

!ELSE 

ALL : "J2534Generic - Win32 Release" "DeviceOEMTool - Win32 Release" "ConfigApp - Win32 Release" "$(OUTDIR)\Innova5000OEMTOOL2534.exe" "$(OUTDIR)\Innova5000OEMTOOL2534.bsc"

!ENDIF 

!IF "$(RECURSE)" == "1" 
CLEAN :"ConfigApp - Win32 ReleaseCLEAN" "DeviceOEMTool - Win32 ReleaseCLEAN" "J2534Generic - Win32 ReleaseCLEAN" 
!ELSE 
CLEAN :
!ENDIF 
	-@erase "$(INTDIR)\Innova5000OEMTOOL2534.obj"
	-@erase "$(INTDIR)\Innova5000OEMTOOL2534.pch"
	-@erase "$(INTDIR)\Innova5000OEMTOOL2534.sbr"
	-@erase "$(INTDIR)\Resource.res"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\StdAfx.sbr"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(OUTDIR)\Innova5000OEMTOOL2534.bsc"
	-@erase "$(OUTDIR)\Innova5000OEMTOOL2534.exe"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP_PROJ=/nologo /ML /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /FR"$(INTDIR)\\" /Fp"$(INTDIR)\Innova5000OEMTOOL2534.pch" /Yu"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
MTL_PROJ=/nologo /D "NDEBUG" /mktyplib203 /win32 
RSC_PROJ=/l 0x409 /fo"$(INTDIR)\Resource.res" /d "NDEBUG" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\Innova5000OEMTOOL2534.bsc" 
BSC32_SBRS= \
	"$(INTDIR)\Innova5000OEMTOOL2534.sbr" \
	"$(INTDIR)\StdAfx.sbr"

"$(OUTDIR)\Innova5000OEMTOOL2534.bsc" : "$(OUTDIR)" $(BSC32_SBRS)
    $(BSC32) @<<
  $(BSC32_FLAGS) $(BSC32_SBRS)
<<

LINK32=link.exe
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /incremental:no /pdb:"$(OUTDIR)\Innova5000OEMTOOL2534.pdb" /machine:I386 /out:"$(OUTDIR)\Innova5000OEMTOOL2534.exe" 
LINK32_OBJS= \
	"$(INTDIR)\Innova5000OEMTOOL2534.obj" \
	"$(INTDIR)\StdAfx.obj" \
	"$(INTDIR)\Resource.res" \
	"..\Innova40432DLL\J2534Generic\DeviceOEMTool.lib" \
	"..\Innova40432DLL\J2534Generic\Release\Innova40432.lib"

"$(OUTDIR)\Innova5000OEMTOOL2534.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "Innova5000OEMTOOL2534 - Win32 Debug"

OUTDIR=.\Debug
INTDIR=.\Debug
# Begin Custom Macros
OutDir=.\Debug
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "$(OUTDIR)\Innova5000OEMTOOL2534.exe" "$(OUTDIR)\Innova5000OEMTOOL2534.bsc"

!ELSE 

ALL : "J2534Generic - Win32 Debug" "DeviceOEMTool - Win32 Debug" "ConfigApp - Win32 Debug" "$(OUTDIR)\Innova5000OEMTOOL2534.exe" "$(OUTDIR)\Innova5000OEMTOOL2534.bsc"

!ENDIF 

!IF "$(RECURSE)" == "1" 
CLEAN :"ConfigApp - Win32 DebugCLEAN" "DeviceOEMTool - Win32 DebugCLEAN" "J2534Generic - Win32 DebugCLEAN" 
!ELSE 
CLEAN :
!ENDIF 
	-@erase "$(INTDIR)\Innova5000OEMTOOL2534.obj"
	-@erase "$(INTDIR)\Innova5000OEMTOOL2534.pch"
	-@erase "$(INTDIR)\Innova5000OEMTOOL2534.sbr"
	-@erase "$(INTDIR)\Resource.res"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\StdAfx.sbr"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\vc60.pdb"
	-@erase "$(OUTDIR)\Innova5000OEMTOOL2534.bsc"
	-@erase "$(OUTDIR)\Innova5000OEMTOOL2534.exe"
	-@erase "$(OUTDIR)\Innova5000OEMTOOL2534.ilk"
	-@erase "$(OUTDIR)\Innova5000OEMTOOL2534.pdb"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP_PROJ=/nologo /MLd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_MBCS" /FR"$(INTDIR)\\" /Fp"$(INTDIR)\Innova5000OEMTOOL2534.pch" /Yu"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /GZ /c 
MTL_PROJ=/nologo /D "_DEBUG" /mktyplib203 /win32 
RSC_PROJ=/l 0x409 /fo"$(INTDIR)\Resource.res" /d "_DEBUG" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\Innova5000OEMTOOL2534.bsc" 
BSC32_SBRS= \
	"$(INTDIR)\Innova5000OEMTOOL2534.sbr" \
	"$(INTDIR)\StdAfx.sbr"

"$(OUTDIR)\Innova5000OEMTOOL2534.bsc" : "$(OUTDIR)" $(BSC32_SBRS)
    $(BSC32) @<<
  $(BSC32_FLAGS) $(BSC32_SBRS)
<<

LINK32=link.exe
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /incremental:yes /pdb:"$(OUTDIR)\Innova5000OEMTOOL2534.pdb" /debug /machine:I386 /out:"$(OUTDIR)\Innova5000OEMTOOL2534.exe" /pdbtype:sept 
LINK32_OBJS= \
	"$(INTDIR)\Innova5000OEMTOOL2534.obj" \
	"$(INTDIR)\StdAfx.obj" \
	"$(INTDIR)\Resource.res" \
	"..\Innova40432DLL\J2534Generic\DeviceOEMTool.lib" \
	"..\Innova40432DLL\J2534Generic\Debug\Innova40432.lib"

"$(OUTDIR)\Innova5000OEMTOOL2534.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ENDIF 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<


!IF "$(NO_EXTERNAL_DEPS)" != "1"
!IF EXISTS("Innova5000OEMTOOL2534.dep")
!INCLUDE "Innova5000OEMTOOL2534.dep"
!ELSE 
!MESSAGE Warning: cannot find "Innova5000OEMTOOL2534.dep"
!ENDIF 
!ENDIF 


!IF "$(CFG)" == "Innova5000OEMTOOL2534 - Win32 Release" || "$(CFG)" == "Innova5000OEMTOOL2534 - Win32 Debug"
SOURCE=.\Innova5000OEMTOOL2534.cpp

"$(INTDIR)\Innova5000OEMTOOL2534.obj"	"$(INTDIR)\Innova5000OEMTOOL2534.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\Innova5000OEMTOOL2534.pch"


SOURCE=.\Resource.rc

"$(INTDIR)\Resource.res" : $(SOURCE) "$(INTDIR)"
	$(RSC) $(RSC_PROJ) $(SOURCE)


SOURCE=.\StdAfx.cpp

!IF  "$(CFG)" == "Innova5000OEMTOOL2534 - Win32 Release"

CPP_SWITCHES=/nologo /ML /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /FR"$(INTDIR)\\" /Fp"$(INTDIR)\Innova5000OEMTOOL2534.pch" /Yc"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\StdAfx.sbr"	"$(INTDIR)\Innova5000OEMTOOL2534.pch" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "Innova5000OEMTOOL2534 - Win32 Debug"

CPP_SWITCHES=/nologo /MLd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_MBCS" /FR"$(INTDIR)\\" /Fp"$(INTDIR)\Innova5000OEMTOOL2534.pch" /Yc"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /GZ /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\StdAfx.sbr"	"$(INTDIR)\Innova5000OEMTOOL2534.pch" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

!IF  "$(CFG)" == "Innova5000OEMTOOL2534 - Win32 Release"

"ConfigApp - Win32 Release" : 
   cd "\Documents and Settings\aegtest\Desktop\INNOVA PROJECT BACKUP\Source_code\ConfigApplication"
   $(MAKE) /$(MAKEFLAGS) /F ".\ConfigApp.mak" CFG="ConfigApp - Win32 Release" 
   cd "..\J2534UserApp"

"ConfigApp - Win32 ReleaseCLEAN" : 
   cd "\Documents and Settings\aegtest\Desktop\INNOVA PROJECT BACKUP\Source_code\ConfigApplication"
   $(MAKE) /$(MAKEFLAGS) /F ".\ConfigApp.mak" CFG="ConfigApp - Win32 Release" RECURSE=1 CLEAN 
   cd "..\J2534UserApp"

!ELSEIF  "$(CFG)" == "Innova5000OEMTOOL2534 - Win32 Debug"

"ConfigApp - Win32 Debug" : 
   cd "\Documents and Settings\aegtest\Desktop\INNOVA PROJECT BACKUP\Source_code\ConfigApplication"
   $(MAKE) /$(MAKEFLAGS) /F ".\ConfigApp.mak" CFG="ConfigApp - Win32 Debug" 
   cd "..\J2534UserApp"

"ConfigApp - Win32 DebugCLEAN" : 
   cd "\Documents and Settings\aegtest\Desktop\INNOVA PROJECT BACKUP\Source_code\ConfigApplication"
   $(MAKE) /$(MAKEFLAGS) /F ".\ConfigApp.mak" CFG="ConfigApp - Win32 Debug" RECURSE=1 CLEAN 
   cd "..\J2534UserApp"

!ENDIF 

!IF  "$(CFG)" == "Innova5000OEMTOOL2534 - Win32 Release"

"DeviceOEMTool - Win32 Release" : 
   cd "\Documents and Settings\aegtest\Desktop\INNOVA PROJECT BACKUP\Source_code\Innova40432DLL\DeviceOEMTool"
   $(MAKE) /$(MAKEFLAGS) /F ".\DeviceOEMTool.mak" CFG="DeviceOEMTool - Win32 Release" 
   cd "..\..\J2534UserApp"

"DeviceOEMTool - Win32 ReleaseCLEAN" : 
   cd "\Documents and Settings\aegtest\Desktop\INNOVA PROJECT BACKUP\Source_code\Innova40432DLL\DeviceOEMTool"
   $(MAKE) /$(MAKEFLAGS) /F ".\DeviceOEMTool.mak" CFG="DeviceOEMTool - Win32 Release" RECURSE=1 CLEAN 
   cd "..\..\J2534UserApp"

!ELSEIF  "$(CFG)" == "Innova5000OEMTOOL2534 - Win32 Debug"

"DeviceOEMTool - Win32 Debug" : 
   cd "\Documents and Settings\aegtest\Desktop\INNOVA PROJECT BACKUP\Source_code\Innova40432DLL\DeviceOEMTool"
   $(MAKE) /$(MAKEFLAGS) /F ".\DeviceOEMTool.mak" CFG="DeviceOEMTool - Win32 Debug" 
   cd "..\..\J2534UserApp"

"DeviceOEMTool - Win32 DebugCLEAN" : 
   cd "\Documents and Settings\aegtest\Desktop\INNOVA PROJECT BACKUP\Source_code\Innova40432DLL\DeviceOEMTool"
   $(MAKE) /$(MAKEFLAGS) /F ".\DeviceOEMTool.mak" CFG="DeviceOEMTool - Win32 Debug" RECURSE=1 CLEAN 
   cd "..\..\J2534UserApp"

!ENDIF 

!IF  "$(CFG)" == "Innova5000OEMTOOL2534 - Win32 Release"

"J2534Generic - Win32 Release" : 
   cd "\Documents and Settings\aegtest\Desktop\INNOVA PROJECT BACKUP\Source_code\Innova40432DLL\J2534Generic"
   $(MAKE) /$(MAKEFLAGS) /F ".\J2534Generic.mak" CFG="J2534Generic - Win32 Release" 
   cd "..\..\J2534UserApp"

"J2534Generic - Win32 ReleaseCLEAN" : 
   cd "\Documents and Settings\aegtest\Desktop\INNOVA PROJECT BACKUP\Source_code\Innova40432DLL\J2534Generic"
   $(MAKE) /$(MAKEFLAGS) /F ".\J2534Generic.mak" CFG="J2534Generic - Win32 Release" RECURSE=1 CLEAN 
   cd "..\..\J2534UserApp"

!ELSEIF  "$(CFG)" == "Innova5000OEMTOOL2534 - Win32 Debug"

"J2534Generic - Win32 Debug" : 
   cd "\Documents and Settings\aegtest\Desktop\INNOVA PROJECT BACKUP\Source_code\Innova40432DLL\J2534Generic"
   $(MAKE) /$(MAKEFLAGS) /F ".\J2534Generic.mak" CFG="J2534Generic - Win32 Debug" 
   cd "..\..\J2534UserApp"

"J2534Generic - Win32 DebugCLEAN" : 
   cd "\Documents and Settings\aegtest\Desktop\INNOVA PROJECT BACKUP\Source_code\Innova40432DLL\J2534Generic"
   $(MAKE) /$(MAKEFLAGS) /F ".\J2534Generic.mak" CFG="J2534Generic - Win32 Debug" RECURSE=1 CLEAN 
   cd "..\..\J2534UserApp"

!ENDIF 


!ENDIF 

