# Microsoft Developer Studio Generated NMAKE File, Based on DeviceOEMTool.dsp
!IF "$(CFG)" == ""
CFG=DeviceOEMTool - Win32 Debug
!MESSAGE No configuration specified. Defaulting to DeviceOEMTool - Win32 Debug.
!ENDIF 

!IF "$(CFG)" != "DeviceOEMTool - Win32 Release" && "$(CFG)" != "DeviceOEMTool - Win32 Debug"
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "DeviceOEMTool.mak" CFG="DeviceOEMTool - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "DeviceOEMTool - Win32 Release" (based on "Win32 (x86) Static Library")
!MESSAGE "DeviceOEMTool - Win32 Debug" (based on "Win32 (x86) Static Library")
!MESSAGE 
!ERROR An invalid configuration is specified.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 

!IF  "$(CFG)" == "DeviceOEMTool - Win32 Release"

OUTDIR=.\Release
INTDIR=.\Release

ALL : "..\J2534Generic\DeviceOEMTool.lib"


CLEAN :
	-@erase "$(INTDIR)\DeviceBase.obj"
	-@erase "$(INTDIR)\DeviceOEMTool.obj"
	-@erase "$(INTDIR)\DeviceOEMTool.pch"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "..\J2534Generic\DeviceOEMTool.lib"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Fp"$(INTDIR)\DeviceOEMTool.pch" /Yu"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

RSC=rc.exe
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\DeviceOEMTool.bsc" 
BSC32_SBRS= \
	
LIB32=link.exe -lib
LIB32_FLAGS=/nologo /out:"..\J2534Generic\DeviceOEMTool.lib" 
LIB32_OBJS= \
	"$(INTDIR)\DeviceBase.obj" \
	"$(INTDIR)\DeviceOEMTool.obj" \
	"$(INTDIR)\StdAfx.obj"

"..\J2534Generic\DeviceOEMTool.lib" : "$(OUTDIR)" $(DEF_FILE) $(LIB32_OBJS)
    $(LIB32) @<<
  $(LIB32_FLAGS) $(DEF_FLAGS) $(LIB32_OBJS)
<<

!ELSEIF  "$(CFG)" == "DeviceOEMTool - Win32 Debug"

OUTDIR=.\Debug
INTDIR=.\Debug
# Begin Custom Macros
OutDir=.\Debug
# End Custom Macros

ALL : "..\J2534Generic\DeviceOEMTool.lib" "$(OUTDIR)\DeviceOEMTool.bsc"


CLEAN :
	-@erase "$(INTDIR)\DeviceBase.obj"
	-@erase "$(INTDIR)\DeviceBase.sbr"
	-@erase "$(INTDIR)\DeviceOEMTool.obj"
	-@erase "$(INTDIR)\DeviceOEMTool.pch"
	-@erase "$(INTDIR)\DeviceOEMTool.sbr"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\StdAfx.sbr"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\vc60.pdb"
	-@erase "$(OUTDIR)\DeviceOEMTool.bsc"
	-@erase "..\J2534Generic\DeviceOEMTool.lib"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP=cl.exe
CPP_PROJ=/nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /FR"$(INTDIR)\\" /Fp"$(INTDIR)\DeviceOEMTool.pch" /Yu"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /GZ /c 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

RSC=rc.exe
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\DeviceOEMTool.bsc" 
BSC32_SBRS= \
	"$(INTDIR)\DeviceBase.sbr" \
	"$(INTDIR)\DeviceOEMTool.sbr" \
	"$(INTDIR)\StdAfx.sbr"

"$(OUTDIR)\DeviceOEMTool.bsc" : "$(OUTDIR)" $(BSC32_SBRS)
    $(BSC32) @<<
  $(BSC32_FLAGS) $(BSC32_SBRS)
<<

LIB32=link.exe -lib
LIB32_FLAGS=/nologo /out:"..\J2534Generic\DeviceOEMTool.lib" 
LIB32_OBJS= \
	"$(INTDIR)\DeviceBase.obj" \
	"$(INTDIR)\DeviceOEMTool.obj" \
	"$(INTDIR)\StdAfx.obj"

"..\J2534Generic\DeviceOEMTool.lib" : "$(OUTDIR)" $(DEF_FILE) $(LIB32_OBJS)
    $(LIB32) @<<
  $(LIB32_FLAGS) $(DEF_FLAGS) $(LIB32_OBJS)
<<

!ENDIF 


!IF "$(NO_EXTERNAL_DEPS)" != "1"
!IF EXISTS("DeviceOEMTool.dep")
!INCLUDE "DeviceOEMTool.dep"
!ELSE 
!MESSAGE Warning: cannot find "DeviceOEMTool.dep"
!ENDIF 
!ENDIF 


!IF "$(CFG)" == "DeviceOEMTool - Win32 Release" || "$(CFG)" == "DeviceOEMTool - Win32 Debug"
SOURCE=.\DeviceBase.cpp

!IF  "$(CFG)" == "DeviceOEMTool - Win32 Release"


"$(INTDIR)\DeviceBase.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\DeviceOEMTool.pch"


!ELSEIF  "$(CFG)" == "DeviceOEMTool - Win32 Debug"


"$(INTDIR)\DeviceBase.obj"	"$(INTDIR)\DeviceBase.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\DeviceOEMTool.pch"


!ENDIF 

SOURCE=.\DeviceOEMTool.cpp

!IF  "$(CFG)" == "DeviceOEMTool - Win32 Release"


"$(INTDIR)\DeviceOEMTool.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\DeviceOEMTool.pch"


!ELSEIF  "$(CFG)" == "DeviceOEMTool - Win32 Debug"


"$(INTDIR)\DeviceOEMTool.obj"	"$(INTDIR)\DeviceOEMTool.sbr" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\DeviceOEMTool.pch"


!ENDIF 

SOURCE=.\StdAfx.cpp

!IF  "$(CFG)" == "DeviceOEMTool - Win32 Release"

CPP_SWITCHES=/nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Fp"$(INTDIR)\DeviceOEMTool.pch" /Yc"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\DeviceOEMTool.pch" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "DeviceOEMTool - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /FR"$(INTDIR)\\" /Fp"$(INTDIR)\DeviceOEMTool.pch" /Yc"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /GZ /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\StdAfx.sbr"	"$(INTDIR)\DeviceOEMTool.pch" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 


!ENDIF 

