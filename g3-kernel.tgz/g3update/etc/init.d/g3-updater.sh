#!/bin/sh

echo "Running g3-update...."
RUN_ITB=$(find /boot -type f -name "*.itb" ! -name "*_new.itb")
#RUN_ITB=$(find /boot -type f ! -name "*_new.itb")
if [ "x${RUN_ITB}" == "x" ]; then
	echo "No running ITB file present."
	exit 1
fi

NEW_ITB=$(find /boot -type f -name "*_new.itb")
if [ "x${NEW_ITB}" == "x" ]; then
	echo "No new upgrade ITB file present. Aborting upgrade!"
	exit 1
fi

echo "Upgrading running ITB: ${RUN_ITB} to ${NEW_ITB}"

# Cleanup previous upgrade
rm /boot/*.prev
cp "${RUN_ITB}" "${RUN_ITB}.prev"
sync
mv "${NEW_ITB}" "${RUN_ITB}"
sync

exit 0

