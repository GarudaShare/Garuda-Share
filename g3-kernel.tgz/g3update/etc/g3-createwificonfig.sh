#!/bin/sh
# Create hostapd or wpa_supplication configuration files based on parameters
# configured in g3-wlan.config

source /etc/g3-wlan.config
source /etc/g3-hostapd-param.conf
source /etc/g3-dhcp.conf
BT="BT"
DNSMASQ_CONF="/etc/dnsmasq.conf"
SERIAL_NO="0000"

create_ssid()
{
	SERIAL_NO=$(cat /dev/mtd5)
	SERIAL_NO=${SERIAL_NO:10:11}
	BT_SSID=${WIFI_SSID}_${SERIAL_NO}_${BT}
	hciconfig hci0 name "${BT_SSID}"
}

create_dnsmasq_conf()
{
	if [ ${DHCP} = "0" ]; then
		cat <<-EOF >> ${DNSMASQ_CONF}
			dhcp-range=${DHCP_RANGE_START},${DHCP_RANGE_END},${DHCP_RANGE_MASK},${DHCP_LEASE_TIME}
			dhcp-option=option:router,${DHCP_GATEWAY_IP}
			dhcp-option=option:dns-server,${DHCP_GATEWAY_IP}
			dhcp-option=option:domain-name,local
			dhcp-authoritative
		EOF
		sed -i 's/DHCP*=*"0"/DHCP="1"/' "/etc/g3-wlan.config"
	fi
}

# Function to write common hostapd config
write_hostapd_common()
{
	cat <<-EOF > ${HOSTAPD_CONF}
	logger_syslog=$LOGGER_SYSLOG
	logger_syslog_level=$LOGGER_SYSLOG_LEVEL
	logger_stdout=$LOGGER_STDOUT
	logger_stdout_level=$LOGGER_STDOUT_LEVEL
	ctrl_interface=$CTRL_INTERFACE
	ctrl_interface_group=$CTRL_INTERFACE_GROUP
	beacon_int=$BEACON_INT
	dtim_period=$DTIM_PERIOD
	max_num_sta=$MAX_NUM_STA
	rts_threshold=$RTS_THRESHOLD
	fragm_threshold=$FRAGM_THRESHOLD
	macaddr_acl=$MACADDR_ACL
	auth_algs=$AUTH_ALGS
	ignore_broadcast_ssid=$IGNORE_BROADCAST_SSID
	wmm_enabled=$WMM_ENABLED
	wmm_ac_bk_cwmin=$WMM_AC_BK_CWMIN
	wmm_ac_bk_cwmax=$WMM_AC_BK_CWMAX
	wmm_ac_bk_aifs=$WMM_AC_BK_AIFS
	wmm_ac_bk_txop_limit=$WMM_AC_BK_TXOP_LIMIT
	wmm_ac_bk_acm=$WMM_AC_BK_ACM
	wmm_ac_be_aifs=$WMM_AC_BE_AIFS
	wmm_ac_be_cwmin=$WMM_AC_BE_CWMIN
	wmm_ac_be_cwmax=$WMM_AC_BE_CWMAX
	wmm_ac_be_txop_limit=$WMM_AC_BE_TXOP_LIMIT
	wmm_ac_be_acm=$WMM_AC_BE_ACM
	wmm_ac_vi_aifs=$WMM_AC_VI_AIFS
	wmm_ac_vi_cwmin=$WMM_AC_VI_CWMIN
	wmm_ac_vi_cwmax=$WMM_AC_VI_CWMAX
	wmm_ac_vi_txop_limit=$WMM_AC_VI_TXOP_LIMIT
	wmm_ac_vi_acm=$WMM_AC_VI_ACM
	wmm_ac_vo_aifs=$WMM_AC_VO_AIFS
	wmm_ac_vo_cwmin=$WMM_AC_VO_CWMIN
	wmm_ac_vo_cwmax=$WMM_AC_VO_CWMAX
	wmm_ac_vo_txop_limit=$WMM_AC_VO_TXOP_LIMIT
	wmm_ac_vo_acm=$WMM_AC_VO_ACM
	ieee80211n=$IEEE80211N
	ieee80211ax=$IEEE80211AX
	ht_capab=$HT_CAPAB
	he_su_beamformer=$HE_SU_BEAMFORMER
	he_su_beamformee=$HE_SU_BRAMFORMEE
	own_ip_addr=$OWN_IP_ADDR
	wpa_key_mgmt=$WPA_KEY_MGMT
	wpa=$WPA
	rsn_pairwise=$RSN_PAIRWISE
	wpa_passphrase=$WLAN_AP_PASSPHRASE
	interface=$WLAN_AP_IF
	driver=$WLAN_AP_DRIVER
	country_code=$COUNTRY_CODE
	EOF
}

create_hostapd_conf()
{
	if [ "${WLAN_BAND}" = "AP_2_4" ]; then
		BAND="2G"
		write_hostapd_common
		cat <<-EOF >> ${HOSTAPD_CONF}
		ssid=${WLAN_AP_SSID}_${SERIAL_NO}_${BAND}
		hw_mode=$HW_MODE_2_4
		channel=$CHANNEL_2_4
		he_oper_chwidth=$HE_OPER_CHWIDTH_2_4
		EOF
	else
		BAND="5G"
		write_hostapd_common
		cat <<-EOF >> ${HOSTAPD_CONF}
		ssid=${WLAN_AP_SSID}_${SERIAL_NO}_${BAND}
		ieee80211d=$IEE80211D
		hw_mode=$HW_MODE_5
		channel=$CHANNEL_5
		ieee80211ac=$IEEE80211AC
		vht_oper_chwidth=$VHT_OPER_CHWIDTH
		vht_oper_centr_freq_seg0_idx=$VHT_OPER_CENTR_FREQ_SEG0_IDX
		he_oper_chwidth=$HE_OPER_CHWIDTH_5
		he_oper_centr_freq_seg0_idx=$HE_OPER_CENTR_FREQ_SEG0_IDX
		eap_server=$EAP_SERVER
		EOF
	fi
}

create_wpasupplicant_conf()
{
	cat <<-EOF > ${WPA_SUPPLICANT_CONF}
	ctrl_interface=DIR=/var/run/wpa_supplicant
	update_config=1

	network={
		ssid="${WLAN_STA_WPA_SSID}"
		psk="${WLAN_STA_WPA_PASSPHRASE}"
		key_mgmt=WPA-PSK
	}
	EOF
}

create_wlan_configs()
{
	if [ ${WLAN_MODE} == "AP" ]; then
		create_hostapd_conf
	else
		create_wpasupplicant_conf
	fi
}

# Public function to create AP or STA Wi-Fi Configuration
run_wifi_config()
{
	create_ssid
	create_dnsmasq_conf
	create_wlan_configs
}

