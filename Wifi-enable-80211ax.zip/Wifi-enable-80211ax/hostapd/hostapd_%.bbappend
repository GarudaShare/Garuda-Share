COMPATIBLE_MACHINE = "(sama5d29-garuda3-noremmc|sama5d29-garuda3-emmc)"

FILESEXTRAPATHS:prepend := "${THISDIR}/${PN}:"
SRC_URI += "file://ieee80211ax.cfg"

do_configure:append() {
    cat ${WORKDIR}/ieee80211ax.cfg >> ${S}/hostapd/.config
}
