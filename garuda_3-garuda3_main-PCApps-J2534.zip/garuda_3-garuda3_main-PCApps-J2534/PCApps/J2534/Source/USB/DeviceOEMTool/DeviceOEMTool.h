/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*****************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: DeviceOEMTool.h
 Description			: Interface file for DeviceOEMTool class
 Date					: Jan 29, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_____________________________________________________________________________
 
 1.0		 Jan 29, 2008	Chakravarthy				Initial Version
_____________________________________________________________________________
*****************************************************************************/

#ifndef _CDEVICEOEMTOOL_H_
#define _CDEVICEOEMTOOL_H_

#include "DeviceBase.h"
#include "objbase.h"
#include <initguid.h>
#include "winuser.h"
#include "NewProtocol.h"
#include "usb.h"

/*Directive for switching between Garuda and Innova DLL configuration*/
#define GARUDA_TOOL 

//#define GARUDA_BULK
#define GARUDA_HID

extern "C" 
{
	#include "hidsdi.h"
	#include <setupapi.h>
	#include <dbt.h>
}

/*Macro definitions for INNOVA OEM TOOL USB DEVICE INTERFACE*/
#define INPUTREPORTMAX				65  // Defines the maximum number of bytes in input report
#define OUTPUTREPORTMAX				64 // Maximum number of bytes in output report
#define MAX_PROTOCOL_NUM			255


#define EP_IN  0x82
#define EP_OUT 0x02
//Innova Kit
#ifdef GARUDA_TOOL
	#define VID							0x0471
	#define PID							0x5741

	#define VID_2_0						0x03EB
	#define PID_2_0						0x5743
#else
	#define VID							0x1720 // Vendor id of the innova device
	#define PID							0x120 // Product id of the innova device
#endif
/*Set Programming Voltage constants*/
#define MIN_BAT_VOLTAGE				5000
#define MAX_BAT_VOLTAGE				20000
#define SHORT_TO_GROUND				0xFFFFFFFE
#define VOLTAGE_OFF					0xFFFFFFFF
typedef struct
{
	unsigned char ucFuncID;
	bool bValid;
}
COEMTOOL_J1850PWM_LOOKUP_TABLE;
/*Jayasheela-added structure to hold consecutive frame,data lenght,dataindex */
typedef struct
{
	PASSTHRU_MSG stSaveMultSegmPassRxThruMsg;
	unsigned short usLeftDL;
	unsigned short usDataIndex;

	unsigned long ulLastRxTimeStamp;

	unsigned char uchSendPackets_MaxCount;
	unsigned char uchNoOfPackets;
	unsigned long ulDataBytes;
	unsigned long ulPGN;
	unsigned char uchDest;
	unsigned char uchSrc;

	bool			  bBAM;
	BYTE			  nBAMRTSPkts;
	DWORD			  nBAMRTSTotBytes;
	BYTE			  nBAMRTSSource;
	BYTE			  nBAMRTSNextPkt;
	BYTE			  nBAMRTSBytesReceived;
	DWORD			  nBAMRTSPGN;
	BYTE			  nBAMRTSHowPriority;

	BYTE			  nCTSRTSPkts;
	DWORD			  nCTSRTSTotBytes;
	BYTE			  nCTSRTSSource;
	BYTE			  nCTSRTSNextPkt;
	BYTE			  nCTSRTSBytesReceived;
	DWORD			  nCTSRTSPGN;
	BYTE			  nCTSRTSHowPriority;
	BYTE			  nCTSRTSMaxPacketsForCTS;
	BYTE			  nCTSRTSPacketCntForCTS;

}SAVE_MULTIPLE_SEGMENT_RXDATA;

class CDeviceOEMTool : public CDeviceBase  
{
public:
	CDeviceOEMTool(CDebugLog * pclsDebugLog=NULL); 
	~CDeviceOEMTool();

	//Operations
	virtual J2534ERROR vOpenDevice();
	virtual J2534ERROR vCloseDevice();
	virtual J2534ERROR vConnectProtocol(
							J2534_PROTOCOL	enProtocolID,
							unsigned long   ulFlags, 
							unsigned long	ulBaudRate,
							DEVICEBASE_CALLBACK_RX_FUNC pfnCallback,
							DEVICEBASE_CALLBACK_FC_FUNC pfirstframefnCallback,
 						    DEVICEBASE_CALLBACK_ISO15765_SETRXSTATUS_FUNC psetRxstatusfnCallback,
							LPVOID			pVoid,
							unsigned long	*pulChannelID);

	virtual J2534ERROR vDisconnectProtocol(unsigned long ulChannelID);

	virtual J2534ERROR vGetRevision(char *pchFirmwareVersion,
								    char *pchDllVersion,
								    char *pchApiVersion);

	virtual J2534ERROR vWriteMsgs(unsigned long	ulChannelID,
								  PASSTHRU_MSG	*pstPassThruMsg,
								  unsigned long	*pulNumMsgs);
							

	virtual J2534ERROR vStartPeriodic(unsigned long	ulChannelID, 
									  PASSTHRU_MSG	*pstMsg, 
									  unsigned long	ulTimeInterval, 
									  unsigned long	*pulPeriodicRefID);

	virtual J2534ERROR vUpdatePeriodic(unsigned long	ulChannelID, 
									  PASSTHRU_MSG	*pstMsg, 
									  unsigned long	ulTimeInterval, 
									  unsigned long	pulPeriodicRefID);
							

	virtual J2534ERROR vStopPeriodic(unsigned long	ulChannelID,
									unsigned long	ulPeriodicRefID);
						
	virtual J2534ERROR vStartFilter(unsigned long	ulChannelID,
									J2534_FILTER	enFilterType, 
									PASSTHRU_MSG	*pstMask, 
									PASSTHRU_MSG	*pstPattern,
									PASSTHRU_MSG	*pstFlowControl,
									unsigned long	*pulFilterRefID);

	virtual J2534ERROR vStopFilter(unsigned long	ulChannelID,
								   unsigned long	ulFilterRefID);

	virtual J2534ERROR vIoctl(unsigned long	ulChannelID,
							  J2534IOCTLID enumIoctlID,
							  void *pInput,
							  void *pOutput);

	virtual J2534ERROR vProgrammingVoltage(unsigned long ulDeviceID,
									    unsigned long ulPin,
									    unsigned long ulVoltage);

	virtual BOOL  vIsDeviceConnected(BOOL bFlag = true);

	virtual J2534ERROR  vGetLastError(char *pErrorDescription);

#ifdef GARUDA_TOOL
	virtual J2534ERROR vLoggingStatus(unsigned long bLogFlag,SYSTEMTIME *Time );
	virtual	J2534ERROR vSessionCommand(unsigned long bsessionFlag);
#endif

public:
	
	/*Innova OEM TOOL USB Device Interface Variable Declaration*/
	BOOL HidAttached;					// Used by member functions to make sure device enumerated
	HANDLE HidDevHandle;				// Handle for HID Device
	HANDLE ReadHandle;						
	HANDLE WriteHandle;	
	GUID HidGuid;						// holds GUID of device
	PSP_DEVICE_INTERFACE_DETAIL_DATA detailData;
	OVERLAPPED HIDOverlapped;
	DWORD dwError;
	ULONG Length;
	LPOVERLAPPED lpOverLap;
	DWORD NumberOfBytesRead;
	ULONG Required;
	HIDP_CAPS Capabilities;				// holds enumeration info
	HANDLE								hEventObject;
	UCHAR								OutputReport[OUTPUTREPORTMAX+1];
	UCHAR								InputReport[INPUTREPORTMAX];
	unsigned short						usFirmwareVersion;
	J2534_PROTOCOL						m_enChannelList[MAX_PROTOCOL_NUM];
	HANDLE								hCallBckThread;
	BOOL								m_bThreadQuit;
	int									m_nChannelID;
	BOOL								m_bLoopBack;
	J2534ERROR							m_ulLastErrorCode;

    /* Acknowledge message handle */
    HANDLE                              m_CmdAck;
    /*Fast and Fivebaud Int Handles*/
    HANDLE                              m_FastInit;
    HANDLE                              m_5BaudInit;
    BOOL                                m_bFastInitIssued;
    PASSTHRU_MSG                        m_ptFastInitResponse;
    BOOL                                m_bWriteDone;
	HANDLE								m_bSepTimeEvent;
	/*J1850 Function Look up table*/
	COEMTOOL_J1850PWM_LOOKUP_TABLE	m_FunctionTable[J1850PWM_LIMIT];

	/* Ravi : Integrated the ISO 15765 Variables */
	/*ISO15765 Related Variables*/
	unsigned int      m_nTxID;
	CPtrArray         m_TxList;
    CPtrArray         m_RxList;
    unsigned char     m_nFramePadValue;
	unsigned int	  m_nBlockSizeTx;
	WORD			  m_nSTminTx;
	BYTE			  m_ByteISO15765_BS;
	BYTE			  m_ByteISO15765_STMIN;
	/*Jayasheela-added to hold no of wait flow control frames allowed */
	BYTE			  m_ByteISO15765_WFT_MAX;
	HANDLE			  m_FlowControlEvent;
	BOOL			  m_bFlowControlIssued;
	unsigned long	  m_ulJ1939_BRDCST_MIN_DELAY;

	/*Innova OEM TOOL USB Device Interface Functions Declaration*/
	BOOL bOpenHidDevice();	// Open the HID Device based on VID and PID
	//Reads the newest report from the device
	void  ReadInputReport();
	//Get Output Report size
	int GetOutputReportSize(void); 
	int GetInputReportSize(void);
	int GetFeatureReportByteLength(void);
	//Writes the newest report from the device based on report number
	BOOL WriteOutputReport(unsigned char*ucReport,DWORD dwLength);
	void CloseHandles();
	BOOL GetDeviceDetected() {return (HidAttached);}
	void DisplayInputReport();
	void PrepareForOverlappedTransfer();
	// gets the device capabilites and puts it in Capabilities
	void GetDeviceCapabilities(void);
	void LogToDebugFile(CString szFunct, int nDebugType, 
						CString szLogInfo);

	usb_dev_handle *dev;
public:

	/*Device Initialize and communication Functions*/
	J2534ERROR InitUSBDevice();
	J2534ERROR CloseUSBDevice();
	
	/*Initialize Communication on Protocl*/
	J2534ERROR EnableCommuncation(unsigned long, unsigned long,J2534_PROTOCOL);
	
	/*Disable Communication*/
	J2534ERROR DisableCommuncation(unsigned long);

	/*Send Message Function*/
	J2534ERROR SendECUMessage(PASSTHRU_MSG *, unsigned char);
	J2534ERROR SendMultipleCANECUMessage(PASSTHRU_MSG *, unsigned char,unsigned long);
		
	/*Send message for 9141 / J1850VPWM / SCI  / CCD */
	J2534ERROR SendMultipleFrameECUMessages(PASSTHRU_MSG *,unsigned long ulChannelID);
	J2534ERROR SendSingleFrameECUMessage(unsigned char *,PASSTHRU_MSG *,int,unsigned long ulChannelID);
	
	/*Send ISO15765 message over the network*/
	J2534ERROR DecomposeISO15765Message(unsigned char *,short,unsigned long);
	J2534ERROR SendToDevice(unsigned int,unsigned char *,int,unsigned long, unsigned char);
	J2534ERROR SendISO15765Messages (unsigned char);
	void EmptyTxList(CPtrArray & ptrList);

	/*Send J1939 Message over the network*/
	J2534ERROR DecomposeJ1939Message(unsigned char *,short,unsigned long);
	J2534ERROR SendJ1939Messages (unsigned char ucProtocolid);
	J2534ERROR SendJ1939MsgToDevice (const int num_frames,int block_size,int *frame_index,int seperation_time,bool bBAM,unsigned char nStartPacketNo);
	unsigned long GetJ1939MsgIndex(SAVE_MULTIPLE_SEGMENT_RXDATA *stSaveRxMultipleSegmData, unsigned long ulProtocolId,
										  unsigned long uchSrc,bool bBAMMsg = true);
	J2534ERROR SendJ1939SingleMessage(unsigned long ulMsgId, 
										unsigned char *pData,
										unsigned char uchDataLength,
										unsigned long ulTxFlags,
										unsigned long ulProtocolId);


	/*IOCTL COMMANDS*/
	J2534ERROR GetConfig	(SCONFIG *sIptPtrConfig, unsigned long ulChannelID);
	J2534ERROR SetConfig	(SCONFIG *sIptPtrConfig,unsigned long ulChannelID);
	J2534ERROR FastInit		(PASSTHRU_MSG*,PASSTHRU_MSG*,unsigned long ulChannelID);
	J2534ERROR FiveBaudInit	(SBYTE_ARRAY *, SBYTE_ARRAY *,unsigned long ulChannelID);
	J2534ERROR SendIOCTLData(J2534IOCTLID,unsigned char *,int,unsigned long ulChannelID);
	J2534ERROR ProtectJ1939Address	(SBYTE_ARRAY *, SBYTE_ARRAY *,unsigned long ulChannelID);
	unsigned long GetIndexToStoreMessage(SAVE_MULTIPLE_SEGMENT_RXDATA* stSaveRxMultipleSegmData);
	unsigned long GetMsgIndex(SAVE_MULTIPLE_SEGMENT_RXDATA *stSaveRxMultipleSegmData,
										  PASSTHRU_MSG stPassRxThruMsg,
										  unsigned char ucCANIDSize);
	J2534ERROR SendISO15765MsgToDevice(const int,int,int *,int);

	//Added Functions for support J1939 Frame Id Parsing and Contructing
	bool GetPGNParametersFromHeader(ULONG ulReqHdr,UCHAR &uchPriority,ULONG &ulPGN,UCHAR &uchPDUSpecific,
											  UCHAR &uchPDUFormat,UCHAR &uchSrcAddr,UCHAR &uchDestAddr);
	bool GetPGNParametersFromHeader(ULONG ulReqHdr,UCHAR &uchPriority,ULONG &ulPGN,UCHAR &uchSrcAddr,UCHAR &uchDestAddr);
	unsigned long ComputeJ1939Header(UCHAR uchPriority,ULONG ulPGN,UCHAR uchSrcAddr,UCHAR uchDestAddr);


};

#endif // !defined(AFX_DEVICEOEMTOOL_H__4F59517B_F1EC_4CEB_84FE_FBBB5D0900A1__INCLUDED_)
