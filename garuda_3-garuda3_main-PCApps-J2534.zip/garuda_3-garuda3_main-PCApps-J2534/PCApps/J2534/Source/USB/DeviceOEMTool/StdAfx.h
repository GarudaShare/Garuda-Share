// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__7D24FA56_B9BF_4E28_B076_E2ACB023E8CB__INCLUDED_)
#define AFX_STDAFX_H__7D24FA56_B9BF_4E28_B076_E2ACB023E8CB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afx.h>
#include <afxwin.h>
/*This is Level 1 warning.this will not affect the application performence.
so i am supressing this warning.*/
#pragma warning( disable : 4273)
// TODO: reference additional headers your program requires here

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__7D24FA56_B9BF_4E28_B076_E2ACB023E8CB__INCLUDED_)
