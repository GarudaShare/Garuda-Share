//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ConfigApp.rc
//
#define IDAUTODETECT                    3
#define IDD_DIALOG_CFG                  101
#define IDB_BITMAP1                     103
#define IDI_ICON1                       104
#define IDD_DIALOG1                     107
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_EDIT3                       1002
#define IDC_EDIT4                       1003
#define IDC_EDIT5                       1004
#define IDC_EDIT6                       1005
#define IDC_EDIT7                       1006
#define IDC_COMBO_INTERFACE             1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
