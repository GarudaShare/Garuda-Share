//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GarudaReflash.rc
//
#define IDSELFWM                        3
#define IDREFLASH                       4
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_GARUDAREFLASH_DIALOG        102
#define IDD_DELABELER_DIALOG            103
#define IDR_MAINFRAME                   128
#define IDR_MENU_HELP                   129
#define IDB_BITMAP1                     132
#define IDI_MAINFRAME                   133
#define IDI_ICON_FO                     135
#define IDC_EDIT1                       1000
#define IDC_BUTTON_SF                   1000
#define IDC_PROGRESS1                   1001
#define IDC_EDIT_FL                     1001
#define IDC_PERCENT                     1002
#define IDC_EDIT_EP                     1002
#define IDC_BUTTON_BL                   1003
#define IDC_COMBO_ENC                   1003
#define IDC_EDIT_CHECK                  1004
#define IDC_EDIT_CODE                   1005
#define IDC_FS                          1006
#define IDC_STATIC_SET                  1006
#define IDC_KBSEC                       1007
#define IDC_EDIT_STATUS                 1007
#define IDC_COMBO_HW                    1011
#define IDD_USER_MANUAL                 32773
#define ID_LABEL                        32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
