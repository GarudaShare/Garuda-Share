/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: SWISO15765.cpp
 Description			: This file contains the implementation of the class 
						  that is derived from CProtocolBase to support SWISO15765
						  protocol as required by J2534.
 Date					: Feb 21, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Feb 21, 2008	Chakravarthy				Initial Version
*******************************************************************************/

#include "stdafx.h"
#include "J2534Generic.h"
#include "SWISO15765.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//-----------------------------------------------------------------------------
//	Function Name	: CSWISO15765
//	Input Params	: void
//	Output Params	: void
//	Description		: Constructor for CSWISO15765 class
//-----------------------------------------------------------------------------
CSWISO15765::CSWISO15765(CDeviceBase *pclsDevice, CDebugLog *pclsDebugLog) :
			CProtocolBase(pclsDevice, pclsDebugLog)
{
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWISO15765.cpp", "CSWISO15765()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWISO15765.cpp", "CSWISO15765()", DEBUGLOG_TYPE_COMMENT, 
						 "End");
	}
	m_bLoopback = FALSE;
}

//-----------------------------------------------------------------------------
//	Function Name	: ~CSWISO15765
//	Input Params	: void
//	Output Params	: void
//	Description		: Destructor for CSWISO15765 class
//-----------------------------------------------------------------------------
CSWISO15765::~CSWISO15765()
{
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWISO15765.cpp", "~CSWISO15765()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Disconnect() incase not called yet.
	vDisconnect();

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWISO15765.cpp", "~CSWISO15765()", DEBUGLOG_TYPE_COMMENT, "End");
	}
}
//-----------------------------------------------------------------------------
//	Function Name	: vConnect
//	Input Params	: 
//	Output Params	: 
//	Description		: This function establishes connection to the proctol.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR CSWISO15765::vConnect(J2534_PROTOCOL	enProtocolID,
								unsigned long   ulFlags,
								unsigned long	ulBaudRate,
								DEVICEBASE_CALLBACK_RX_FUNC pfnCallback,
								DEVICEBASE_CALLBACK_FC_FUNC pfirstframefnCallback,
								DEVICEBASE_CALLBACK_ISO15765_SETRXSTATUS_FUNC psetRxstatusfnCallback,
								LPVOID			pVoid)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char			szBuffer[SWISO15765_ERROR_TEXT_SIZE];
	J2534ERROR		enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWISO15765.cpp", "vConnect()", DEBUGLOG_TYPE_COMMENT, "Start");
	}


	if(enProtocolID == SW_ISO15765_PS )
	{
  		/*if ((ulBaudRate != SWISOCAN_DATA_RATE_DEFAULT) && 
			((ulBaudRate != SWISOCAN_DATA_RATE_MEDIUM)))
		{
			return(J2534_ERR_INVALID_BAUDRATE);
		}*/
		m_enSWISO15765Protocol = SW_ISO15765_PS;
	}

	// Call Connect of Base.
	if ((enJ2534Error = CProtocolBase::vConnect(enProtocolID, ulFlags, ulBaudRate,
												OnSWISO15765RxMessage,NULL,NULL,this))
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("SWISO15765.cpp", "vConnect()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("SWISO15765.cpp", "vConnect()", DEBUGLOG_TYPE_COMMENT, szBuffer);
	}
	m_ulPPSS = 0;
	m_ulSWCAN_SpeedChange_Enable = 0;
	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vDisconnect
//	Input Params	: 
//	Output Params	: 
//	Description		: This function disconnects the connection to a protocol.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR CSWISO15765::vDisconnect()
{
	char			szBuffer[SWISO15765_ERROR_TEXT_SIZE];
	J2534ERROR		enJ2534Error;

	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWISO15765.cpp", "vDisconnect()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Disconnect this protocol.
	if ((enJ2534Error = CProtocolBase::vDisconnect()) != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("SWISO15765.cpp", "vDisconnect()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("SWISO15765.cpp", "CSWISO15765()", DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vReadMsgs
//	Input Params	: 
//	Output Params	: 
//	Description		: This function reads the messages out of a circular buffer
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here. 
//-----------------------------------------------------------------------------
J2534ERROR CSWISO15765::vReadMsgs(PASSTHRU_MSG	*pstPassThruMsg,
								unsigned long	*pulNumMsgs,
								unsigned long	ulTimeout)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char		szBuffer[SWISO15765_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWISO15765.cpp", "vReadMsgs()", DEBUGLOG_TYPE_COMMENT, "Start");
	}


	// Write using the generic Write.
	if ((enJ2534Error = CProtocolBase::vReadMsgs(pstPassThruMsg,
												 pulNumMsgs,
												 ulTimeout)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("SWISO15765.cpp", "vReadMsgs()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		if (enJ2534Error == J2534_ERR_BUFFER_EMPTY)
		{
			if (((m_pclsFilterMsg == NULL) || (!m_pclsFilterMsg->IsFlowControlFilterSet())))
			{
				sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NO_FLOW_CONTROL);
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					m_pclsLog->Write("SWISO15765.cpp", "vReadMsgs()", DEBUGLOG_TYPE_ERROR, 
									 szBuffer);
				}
				return(J2534_ERR_NO_FLOW_CONTROL);
			}
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("SWISO15765.cpp", "vReadMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}
	return(J2534_STATUS_NOERROR);
}
//-----------------------------------------------------------------------------
//	Function Name	: vWriteMsgs
//	Input Params	: 
//	Output Params	: 
//	Description		: This function writes the message out to a circular buffer
//					  and waits until it is transmitted out on the bus or exits
//					  immediately after writing to buffer if it is non-blocking.
//					  The message is Blocking if the given timeout value is 
//					  greater than 0. The base class implements the generic 
//					  functionality. Any specific functionality to this derived
//					  class is implented here.
//-----------------------------------------------------------------------------
J2534ERROR CSWISO15765::vWriteMsgs(PASSTHRU_MSG	*pstPassThruMsg,
								unsigned long	*pulNumMsgs,
								unsigned long	ulTimeout)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char		szBuffer[SWISO15765_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;
	unsigned long	ulIdx1;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWISO15765.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}


	for (ulIdx1 = 0; ulIdx1 < *pulNumMsgs; ulIdx1++)
	{
		// Check Msg. Protocol ID.
		if ((pstPassThruMsg + ulIdx1)->ulProtocolID != m_enSWISO15765Protocol)
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_MSG_PROTOCOL_ID);
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("SWISO15765.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
								 szBuffer);
			}
			return(J2534_ERR_MSG_PROTOCOL_ID);
		}

		if (((pstPassThruMsg + ulIdx1)->ulDataSize > SWISO15765_MSG_SIZE_MAX_SF) && 
			((m_pclsFilterMsg == NULL) || (!m_pclsFilterMsg->IsFlowControlFilterSet())))
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_NO_FLOW_CONTROL);
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("SWISO15765.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
								 szBuffer);
			}
			return(J2534_ERR_NO_FLOW_CONTROL);
		}

		// Check if msg. format is valid.
		if (!IsMsgValid((pstPassThruMsg + ulIdx1)))
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("SWISO15765.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
								 szBuffer);
			}
			return(J2534_ERR_INVALID_MSG);
		}
	}
	// Write using the generic Write.
	if ((enJ2534Error = CProtocolBase::vWriteMsgs(pstPassThruMsg,
												  pulNumMsgs,
												  ulTimeout)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("SWISO15765.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("SWISO15765.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}
//-----------------------------------------------------------------------------
//	Function Name	: vStartPeriodicMsg
//	Input Params	: 
//	Output Params	: 
//	Description		: This funtions starts a Periodic msg. on a given channel
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR CSWISO15765::vStartPeriodicMsg(PASSTHRU_MSG	*pstPassThruMsg,
										unsigned long	*pulMsgID,
										unsigned long	ulTimeInterval)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char		szBuffer[SWISO15765_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWISO15765.cpp", "vStartPeriodicMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}


	// Check Msg. Protocol ID.
	if (pstPassThruMsg->ulProtocolID != m_enSWISO15765Protocol)
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_MSG_PROTOCOL_ID);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("SWISO15765.cpp", "vStartPeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_MSG_PROTOCOL_ID);
	}
	
	if ((pstPassThruMsg->ulDataSize > SWISO15765_MSG_SIZE_MAX_SF))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("SWISO15765.cpp", "vStartPeriodicMsg()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(J2534_ERR_INVALID_MSG);
	}
	// Check if msg. format is valid.
	if (!IsMsgValid(pstPassThruMsg))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("SWISO15765.cpp", "vStartPeriodicMsgs()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_INVALID_MSG);
	}

	// Start Periodic using the generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStartPeriodicMsg(pstPassThruMsg,
														 pulMsgID,
														 ulTimeInterval)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("SWISO15765.cpp", "vStartPeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("SWISO15765.cpp", "vStartPeriodicMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStopPeriodicMsg
//	Input Params	: 
//	Output Params	: 
//	Description		: This functions stops the Periodic Msg. that was started
//					  earlier. The base class implements the generic 
//					  functionality. Any specific functionality to this derived
//					  class is implented here.
//-----------------------------------------------------------------------------
J2534ERROR CSWISO15765::vStopPeriodicMsg(unsigned long ulMsgID)
{
	char		szBuffer[SWISO15765_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWISO15765.cpp", "vStopPeriodicMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Stop Periodic using the generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStopPeriodicMsg(ulMsgID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("SWISO15765.cpp", "vStopPeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("SWISO15765.cpp", "vStopPeriodicMsgs()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStartMsgFilter
//	Input Params	: 
//	Output Params	: 
//	Description		: This function sets up a msg. filter as requested.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR	CSWISO15765::vStartMsgFilter(J2534_FILTER	enumFilterType,
									   PASSTHRU_MSG		*pstMask,
									   PASSTHRU_MSG		*pstPattern,
									   PASSTHRU_MSG		*pstFlowControl,
									   unsigned long	*pulFilterID)
{
	char		szBuffer[SWISO15765_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// NOTE : If request is for PASS filter, try setting this filter in device 
	//		  as well. If the device cannot set and returns an 
	//		  error, ignore it. Some device drivers may not be able to set 
	//		  hardware filters. Anyway it will be filtered by our software
	//		  filter.  

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWISO15765.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Check Filter Type.
	if (enumFilterType != J2534_FILTER_FLOW_CONTROL)
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_FILTER_ID);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("SWISO15765.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(J2534_ERR_INVALID_FILTER_ID);
	}

	// Check Msg. Protocol ID.
	if ((pstMask->ulProtocolID != m_enSWISO15765Protocol) ||
		(pstPattern->ulProtocolID != m_enSWISO15765Protocol) || 
		(pstFlowControl->ulProtocolID != m_enSWISO15765Protocol))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_MSG_PROTOCOL_ID);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("SWISO15765.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(J2534_ERR_MSG_PROTOCOL_ID);
	}
	// Check Filter Type.

	// NOTE : In SWISO15765, if pstFlowControl is not NULL then check for  
	//		  J2534_ERR_MSG_PROTOCOL_ID.

	// NOTE : In SWISO15765, pass the pstFlowControl through 
	//		  IsMsgValid().
	// Check if msg. format is valid.
	if (!IsMsgValid(pstPattern, true))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("SWISO15765.cpp", "vStartMsgFilter()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_INVALID_MSG);
	}

	if (!IsMsgValid(pstMask, true))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("SWISO15765.cpp", "vStartMsgFilter()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_INVALID_MSG);
	}

	if (!IsMsgValid(pstFlowControl, true))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("SWISO15765.cpp", "vStartMsgFilter()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_INVALID_MSG);
	}

	// NOTE : In SWISO15765, check to see that the mask of 4 or 5 bytes are
	//        all 0xFF. The size of pstMask, pstPattern and pstFlowControl
	//		  should be 4 or 5 bytes depanding on extended addressing or not
	//		  respectively.

	// NOTE : In SWISO15765, if the filter type is PASS or BLOCK return error.
	//		  In other words only allow FLOW_CONTROL filter type.

	// StartMsgFilter using generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStartMsgFilter(
										  enumFilterType,
										  pstMask,
										  pstPattern,
										  pstFlowControl,
										  pulFilterID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("SWISO15765.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("SWISO15765.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStopMsgFilter
//	Input Params	: 
//	Output Params	: 
//	Description		: This function stops a msg. filter that was set earlier.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR	CSWISO15765::vStopMsgFilter(unsigned long ulFilterID)
{
	char		szBuffer[SWISO15765_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWISO15765.cpp", "vStopMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// StopMsgFilter using generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStopMsgFilter(ulFilterID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("SWISO15765.cpp", "vStopMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("SWISO15765.cpp", "vStopMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}
//-----------------------------------------------------------------------------
//	Function Name	: vIoctl
//	Input Params	: 
//	Output Params	: 
//	Description		: This is a virtual function. This function is used to read
//					  and write all the protocol hardware and software
//					  configuration parameters for a given enumIoctlID.
//-----------------------------------------------------------------------------
J2534ERROR  CSWISO15765::vIoctl(J2534IOCTLID enumIoctlID,
							  void *pInput,
							  void *pOutput)
{
	J2534ERROR	enumJ2534Error;
	char	szBuffer[SWISO15765_ERROR_TEXT_SIZE];	
	enumJ2534Error = J2534_STATUS_NOERROR;
	
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
			"Start");
	}
	// IoctlID values
	switch(enumIoctlID)
	{
	case GET_CONFIG:			// Get configuration
		
			enumJ2534Error = GetConfig((SCONFIG_LIST *)pInput);
		
		break;
		
	case SET_CONFIG:			// Set configuration
		
		enumJ2534Error = SetConfig((SCONFIG_LIST *)pInput);

		break;
		
	case CLEAR_TX_BUFFER:		// Clear all messages in its transmit queue
		if(m_pclsTxCircBuffer != NULL)
		{
			m_pclsTxCircBuffer->ClearBuffer();
			if (enumJ2534Error = CProtocolBase::vIoctl(CLEAR_TX_BUFFER,
														NULL,
														NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
		}
		break;
		
	case CLEAR_RX_BUFFER:		// Clear all messages in its receive queue
		if(m_pclsRxCircBuffer != NULL)
		{
			m_pclsRxCircBuffer->ClearBuffer();
			if (enumJ2534Error = CProtocolBase::vIoctl(CLEAR_RX_BUFFER,
													   NULL,
													   NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
		}
		break;
		
	case CLEAR_PERIODIC_MSGS:	// Clear all periodic messages
		
			if (m_pclsPeriodicMsg != NULL)
			{
				delete m_pclsPeriodicMsg;
				m_pclsPeriodicMsg = NULL;
			}
			if (enumJ2534Error = CProtocolBase::vIoctl(CLEAR_PERIODIC_MSGS,
													   NULL,
													   NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
		break;
		
	case CLEAR_MSG_FILTERS:		// Clear all message filters
			if (m_pclsFilterMsg != NULL)
			{
				delete m_pclsFilterMsg;
				m_pclsFilterMsg = NULL;
			}
			if (enumJ2534Error = CProtocolBase::vIoctl(CLEAR_MSG_FILTERS,
													   NULL,
													   NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
		break;
	case SW_CAN_HS:
		
			if (enumJ2534Error = CProtocolBase::vIoctl(enumIoctlID,
														NULL,
														NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
				return(enumJ2534Error);
			}	
		break;
	
	case SW_CAN_NS:
		
			if (enumJ2534Error = CProtocolBase::vIoctl(enumIoctlID,
														NULL,
														NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
				return(enumJ2534Error);
			}	
		break;
		
	default:					// Others not supported
		enumJ2534Error = J2534_ERR_NOT_SUPPORTED;
		break;
	}
	
	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
		if (enumJ2534Error != J2534_STATUS_NOERROR)
			m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
			szBuffer);
		else
			m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
			szBuffer);
	}
	
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
			"End");
	}	
	return(enumJ2534Error);
}

//-----------------------------------------------------------------------------
//	Function Name	: OnSWISO15765Rx
//	Input Params	: void
//	Output Params	: void
//	Description		: This is a callback routine that is called upon receiving
//					  SWISO15765 messages.
//-----------------------------------------------------------------------------
void OnSWISO15765RxMessage(PASSTHRU_MSG *pstPassThruMsg,LPVOID pVoid)
{
	CSWISO15765					*pclsSWISO15765;
	FILTERMSG_CONFORM_REQ	stConformReq;
	unsigned long ulDataSize;
	char	szBuffer[SWISO15765_ERROR_TEXT_SIZE];	

	pclsSWISO15765 = (CSWISO15765 *) pVoid;

	// Check for NULL pointer.
	if (pclsSWISO15765 == NULL)
	{
		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			CProtocolBase::m_pclsLog->Write("CSWISO15765.cpp", "OnSWISO15765Rx()", 
							 DEBUGLOG_TYPE_COMMENT, "NULL pointer");
		}
		return;
	}


	// Check if the message is valid as per the Connect Flag is set.
	if ((pclsSWISO15765->m_ulConnectFlag & J2534_CONNECT_FLAGBIT_CANBOTH) == 0)
	{
		if (pclsSWISO15765->m_ulConnectFlag & J2534_CONNECT_FLAGBIT_CAN29BIT)
		{	
			if ((pstPassThruMsg->ulRxStatus & J2534_RX_FLAGBIT_CAN29BIT) == 0)
			{
				return;
			}
		}
		else
		{
			if ((pstPassThruMsg->ulRxStatus & J2534_RX_FLAGBIT_CAN29BIT) != 0)
			{
				return;
			}
		}
	}

	// Check if this is a Loopback message.
	if (pstPassThruMsg->ulRxStatus & (0x08 | J2534_RX_FLAGBIT_MSGTYPE))
	{
		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			CProtocolBase::m_pclsLog->Write("CSWISO15765.cpp", "OnSWISO15765Rx()", 
							 DEBUGLOG_TYPE_COMMENT, "Tx Done CALLBACK");
		}

		ulDataSize = pstPassThruMsg->ulDataSize;

		if (pstPassThruMsg->ulTxFlags & 0x80)
			pstPassThruMsg->ulDataSize = 5;
		else
			pstPassThruMsg->ulDataSize = 4;

		pstPassThruMsg->ulExtraDataIndex = 0;//pstPassThruMsg->ulDataSize;

		// Write status to Log File.
		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "pstPassThruMsg->ulTxFlags 0x%X", pstPassThruMsg->ulTxFlags);
			CProtocolBase::m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
				szBuffer);
			sprintf(szBuffer, "pstPassThruMsg->ulDataSize 0x%X", pstPassThruMsg->ulDataSize);
			CProtocolBase::m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
				szBuffer);
		}
		// Enqueue to Circ Buffer.
		pclsSWISO15765->m_pclsRxCircBuffer->Write((unsigned char *) pstPassThruMsg, 
					(sizeof(PASSTHRU_MSG) - sizeof(pstPassThruMsg->ucData) +
					pstPassThruMsg->ulDataSize));
		pstPassThruMsg->ulRxStatus &= (0xFF - 0x08);
	}
	// Check if this is a Loopback message.
	if (pstPassThruMsg->ulRxStatus & J2534_RX_FLAGBIT_MSGTYPE)
	{
		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			CProtocolBase::m_pclsLog->Write("CSWISO15765.cpp", "OnSWISO15765Rx()", 
							 DEBUGLOG_TYPE_COMMENT, "Tx CALLBACK");
		}

		if (pclsSWISO15765->m_ulSWCAN_SpeedChange_Enable == 1)
		{
			if ((pstPassThruMsg->ulTxFlags & J2534_TX_FLAGBIT_CAN29BIT) == 0)
			{
				if ((pstPassThruMsg->ucData[2] == 0x01) &&
					(pstPassThruMsg->ucData[3] == 0x01) &&
					(pstPassThruMsg->ucData[4] == 0xFE))
				{
					if ((pstPassThruMsg->ucData[5] == 0xA5))
					{
						if (pstPassThruMsg->ucData[6] == 0x01)
						{
							pclsSWISO15765->m_bNormalHighSpeed = false;
						}
						else if (pstPassThruMsg->ucData[6] == 0x02)
						{
							pclsSWISO15765->m_bNormalHighSpeed = true;
						}
						else if (pstPassThruMsg->ucData[6] == 0x03)
						{
							if (pclsSWISO15765->m_bNormalHighSpeed)
							{
								// Normal Speed to High Speed - 
								// Functionally Addressed Programming Mode
								pclsSWISO15765->vIoctl(SW_CAN_HS, NULL, NULL);
							}
							else
							{
								// High Speed to Normal Speed - 
								// Functionally Addressed Return to Normal Mode
								pclsSWISO15765->vIoctl(SW_CAN_NS, NULL, NULL);
							}
						}
					}
				}
				else if ((pstPassThruMsg->ucData[2] == 0x02) &&
					(pstPassThruMsg->ucData[3] >= 0x41) &&
					(pstPassThruMsg->ucData[3] <= 0x5F))
				{
					if ((pstPassThruMsg->ucData[4] == 0xA5))
					{
						if (pstPassThruMsg->ucData[5] == 0x01)
						{
							pclsSWISO15765->m_bNormalHighSpeed = false;
						}
						else if (pstPassThruMsg->ucData[5] == 0x02)
						{
							pclsSWISO15765->m_bNormalHighSpeed = true;
						}
						else if (pstPassThruMsg->ucData[5] == 0x03)
						{
							if (pclsSWISO15765->m_bNormalHighSpeed)
							{
								// Normal Speed to High Speed - 
								// Functionally Addressed Programming Mode
								pclsSWISO15765->vIoctl(SW_CAN_HS, NULL, NULL);
							}
							else
							{
								// High Speed to Normal Speed - 
								// Functionally Addressed Return to Normal Mode
								pclsSWISO15765->vIoctl(SW_CAN_NS, NULL, NULL);
							}
						}
					}
				}
			}
		}
		
		if (pclsSWISO15765->m_bLoopback == false)
			return;

		pstPassThruMsg->ulDataSize = ulDataSize;
		pstPassThruMsg->ulExtraDataIndex = pstPassThruMsg->ulDataSize;

		// Enqueue to Circ Buffer.
		pclsSWISO15765->m_pclsRxCircBuffer->Write((unsigned char *) pstPassThruMsg, 
					(sizeof(PASSTHRU_MSG) - sizeof(pstPassThruMsg->ucData) +
					pstPassThruMsg->ulDataSize));
		return;
	}
	
	if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
	{
		CProtocolBase::m_pclsLog->Write("CSWISO15765.cpp", "OnSWISO15765Rx()", 
						 DEBUGLOG_TYPE_COMMENT, "Rx CALLBACK");
	}
	// Apply Filters and see if msg. is required.
	if (pclsSWISO15765->m_pclsFilterMsg != NULL)
	{
		stConformReq.bReqPass = true;
		stConformReq.bReqBlock = true;
		if (pclsSWISO15765->m_pclsFilterMsg->IsMsgRequired(pstPassThruMsg, &stConformReq))
		{
			// Enqueue to Circ Buffer.
			pclsSWISO15765->m_pclsRxCircBuffer->Write((unsigned char *) pstPassThruMsg, 
					(sizeof(PASSTHRU_MSG) - sizeof(pstPassThruMsg->ucData) +
					pstPassThruMsg->ulDataSize));
		}
	}
	return;
}
//-----------------------------------------------------------------------------
//	Function Name	: IsMsgValid
//	Input Params	: void
//	Output Params	: void
//	Description		: This checks the validity of message structure as required
//					  by J2534 standard.
//-----------------------------------------------------------------------------
bool CSWISO15765::IsMsgValid(PASSTHRU_MSG *pstPassThruMsg, bool bFilter)
{
	if (!bFilter)
	if ((pstPassThruMsg->ulDataSize < SWISO15765_MSG_SIZE_MIN) || 
		(pstPassThruMsg->ulDataSize > SWISO15765_MSG_SIZE_MAX))
	{
		return(false);
	}

	if ((m_ulConnectFlag & J2534_CONNECT_FLAGBIT_CANBOTH) == 0)
	{
		if (m_ulConnectFlag & J2534_CONNECT_FLAGBIT_CAN29BIT)
		{	
			if ((pstPassThruMsg->ulTxFlags & J2534_TX_FLAGBIT_CAN29BIT) == 0)
			{
				return(false);
			}
		}
		else
		{
			if ((pstPassThruMsg->ulTxFlags & J2534_TX_FLAGBIT_CAN29BIT) != 0)
			{
				return(false);
			}
		}
	}
	
	return(true);
}

//-----------------------------------------------------------------------------
//	Function Name	: GetConfig
//	Input Params	: 
//	Output Params	: 
//	Description		: This function gets the configuration for selected 
//					  parameters for a given channel card.
//-----------------------------------------------------------------------------
J2534ERROR  CSWISO15765::GetConfig(SCONFIG_LIST *pInput)
{
	J2534ERROR		enumJ2534Error;
	SCONFIG			*pSconfig;
	unsigned long	ulCount;
	char	szBuffer[SWISO15765_ERROR_TEXT_SIZE];
	enumJ2534Error = J2534_STATUS_NOERROR;

	// Make sure pInput is not NULL
	if (pInput == NULL)
		return(J2534_ERR_NULLPARAMETER);

	if (pInput->ulNumOfParams == 0)
	{
		return(J2534_ERR_FAILED);
	}

	pSconfig = pInput->pConfigPtr;
	
	for (ulCount = 0; ulCount < pInput->ulNumOfParams; ulCount++)
	{
		switch (pSconfig->Parameter)
		{
			case DATA_RATE:			// Data Rate
				
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
				
			case LOOPBACK:			// Loopback
				pSconfig->ulValue = m_bLoopback;
				break;

			case BIT_SAMPLE_POINT:	// Bit Sample Point
				
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
				
			case SYNC_JUMP_WIDTH:	// Sync Jump Width

				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case ISO15765_BS:		// Block Size
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			case BS_TX:				// Block Size Tx
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			case ISO15765_STMIN:		// STmin
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			case STMIN_TX:				// STminTx
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			case ISO15765_WFT_MAX:
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			/*Jayasheela-application sends ioctl id's as per J2534 spec 2
			  but HFCP defines different id's,so require mapping*/
			case 0x00008001:
				//pSconfig->ulValue = m_ulPPSS;
				pSconfig->Parameter = J1962_PINS;
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
													   pSconfig,
													   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("SWCAN.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
					}
				}
				pSconfig->Parameter =(J2534_IOCTLPARAMID) 0x00008001;
				break;
			case 0x00008010:
				pSconfig->Parameter = SWCAN_HS_DATA_RATE;

				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				pSconfig->Parameter =(J2534_IOCTLPARAMID)0x00008010;

				break;
			case 0x00008011:
				pSconfig->Parameter = SWCAN_SPEEDCHANGE_ENABLE;
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				pSconfig->Parameter =(J2534_IOCTLPARAMID)0x00008011;
				break;
			case 0x00008012:
				pSconfig->Parameter = SWCAN_RES_SWITCH;
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				pSconfig->Parameter =(J2534_IOCTLPARAMID)0x00008012;
				break;
			default:
				return(J2534_ERR_NOT_SUPPORTED);
		}

		if (enumJ2534Error != J2534_STATUS_NOERROR) // If something is wrong
			return(enumJ2534Error);
		
		pSconfig++;
	}
	return(enumJ2534Error);
}

//-----------------------------------------------------------------------------
//	Function Name	: SetConfig
//	Input Params	: 
//	Output Params	: 
//	Description		: This function sets the configuration for selected 
//					  parameters for a given channel card.
//-----------------------------------------------------------------------------
J2534ERROR  CSWISO15765::SetConfig(SCONFIG_LIST *pInput)
{
	J2534ERROR		enumJ2534Error;
	SCONFIG			*pSconfig;
	unsigned long	ulCount;
	char	szBuffer[SWISO15765_ERROR_TEXT_SIZE];	
	enumJ2534Error = J2534_STATUS_NOERROR;

	// Make sure pInput is not NULL
	if (pInput == NULL)
		return(J2534_ERR_NULLPARAMETER);

	if (pInput->ulNumOfParams == 0)
	{
		return(J2534_ERR_FAILED);
	}

	pSconfig = pInput->pConfigPtr;

	for (ulCount = 0; ulCount < pInput->ulNumOfParams; ulCount++)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "Parameter is 0x%02X", pSconfig->Parameter);
			m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
				szBuffer);
		}
		switch (pSconfig->Parameter)
		{
			case DATA_RATE:			// Data Rate

				if ((pSconfig->ulValue < 5) || (pSconfig->ulValue > 500000))
					return(J2534_ERR_INVALID_IOCTL_VALUE);
				else
				{
					if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
						pSconfig,
						NULL))														
					{
						if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
						{
							sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
							m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
								szBuffer);
						}
					}
				}
				break;

			case LOOPBACK:			// Loopback

				
				if ((pSconfig->ulValue < 0) || (pSconfig->ulValue > 1))
					return(J2534_ERR_INVALID_IOCTL_VALUE);
				else
				{
					if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															   pSconfig,
															   NULL))														
					{
						if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
						{
							sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
							m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
								szBuffer);
						}
					}
					m_bLoopback = pSconfig->ulValue;
				}
				break;
			case BIT_SAMPLE_POINT:	// Bit Sample Point
					if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
																pSconfig,
																NULL))														
					{
						if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
						{
							sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
							m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
								szBuffer);
						}
					}
				break;

			case SYNC_JUMP_WIDTH:	// Sync Jump Width
					if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
																pSconfig,
																NULL))														
					{
						if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
						{
							sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
							m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
								szBuffer);
						}
					}
				break;
			/*Jayasheela-application sends ioctl id's as per J2534 spec 2
			  but HFCP defines different id's,so require mapping*/

			case 0x00008001:

				pSconfig->Parameter = J1962_PINS;

				enumJ2534Error = J1962Pins(pSconfig->ulValue);
				if(enumJ2534Error == J2534_STATUS_NOERROR)
				{
					if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
																pSconfig,
																NULL))														
					{
						if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
						{
							sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
							m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
								szBuffer);
						}
					}
					if(enumJ2534Error == J2534_STATUS_NOERROR)
					{
						m_ulPPSS = pSconfig->ulValue;
					}
				}
				else
					enumJ2534Error = J2534_ERR_INVALID_IOCTL_VALUE;

					pSconfig->Parameter =(J2534_IOCTLPARAMID)0x00008001;
				break;

			case 0x00008010:

					pSconfig->Parameter = SWCAN_HS_DATA_RATE;

					if ((pSconfig->ulValue < 5) || (pSconfig->ulValue > 500000))
						return(J2534_ERR_INVALID_IOCTL_VALUE);
					if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
																pSconfig,
																NULL))														
					{
						if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
						{
							sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
							m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
								szBuffer);
						}
					}
					pSconfig->Parameter =(J2534_IOCTLPARAMID)0x00008010;
				break;

			case 0x00008011:
					pSconfig->Parameter = SWCAN_SPEEDCHANGE_ENABLE;
					if ((pSconfig->ulValue < 0) || (pSconfig->ulValue > 1))
						return(J2534_ERR_INVALID_IOCTL_VALUE);

					if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															   pSconfig,
															   NULL))														
					{
						if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
						{
							sprintf(szBuffer,"returned 0x%02X", enumJ2534Error);
							m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
								szBuffer);
						}
					}
					if(enumJ2534Error == J2534_STATUS_NOERROR)
						m_ulSWCAN_SpeedChange_Enable = pSconfig->ulValue;

					pSconfig->Parameter = (J2534_IOCTLPARAMID)0x00008011;

				break;

			case 0x00008012:
					pSconfig->Parameter = SWCAN_RES_SWITCH;
					if ((pSconfig->ulValue < 0) || (pSconfig->ulValue > 2))
						return(J2534_ERR_INVALID_IOCTL_VALUE);
					if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															   pSconfig,
															   NULL))														
					{
						if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
						{
							sprintf(szBuffer,"returned 0x%02X", enumJ2534Error);
							m_pclsLog->Write("SWISO15765.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
								szBuffer);
						}
					}
					pSconfig->Parameter = (J2534_IOCTLPARAMID)0x00008012;
				break;
			default:
				return(J2534_ERR_NOT_SUPPORTED);
		}

		if (enumJ2534Error != J2534_STATUS_NOERROR) // If something is wrong
			return(enumJ2534Error);
		
		pSconfig++;
	}

	return(enumJ2534Error);
}
J2534ERROR  CSWISO15765::J1962Pins(unsigned long ulValue)
{
	J2534ERROR	enumJ2534Error;
		
	enumJ2534Error = J2534_STATUS_NOERROR;
	
	if ((ulValue < 0) || (ulValue > 0xFFFF))
		return(J2534_ERR_INVALID_IOCTL_VALUE);


	if ((ulValue & 0xFF00 > 0x1000) || (ulValue & 0x00FF > 0x0010))
		return(J2534_ERR_INVALID_IOCTL_VALUE);

	if ((ulValue != 0x0000) &&
		((ulValue >> 8) & 0x00FF) == (ulValue & 0x00FF))
		return(J2534_ERR_INVALID_IOCTL_VALUE);

	if (((ulValue >> 8) == 4) || (ulValue == 4) ||
		((ulValue >> 8) == 5) || (ulValue == 5) ||
		((ulValue >> 8) == 16) || (ulValue == 16))
		return(J2534_ERR_INVALID_IOCTL_VALUE);

	// J1962 Pins
	if ((ulValue == 0x0000) || 
		(ulValue == 0x0100))
	{
		enumJ2534Error = J2534_STATUS_NOERROR;
	}
	else
	{
		enumJ2534Error = J2534_ERR_NOT_SUPPORTED;
	}
	return(enumJ2534Error);
}
