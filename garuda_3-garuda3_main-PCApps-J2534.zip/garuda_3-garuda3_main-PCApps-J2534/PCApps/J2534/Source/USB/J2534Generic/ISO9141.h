/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: ISO9141.h
 Description			: This file contains the implementation of the class 
						  that is derived from CProtocolBase to support ISO9141 
						  protocol as required by J2534.
 Date					: Feb 20, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Feb 20, 2008	Chakravarthy				Initial Version
*******************************************************************************/

#if !defined(AFX_ISO9141_H__62C51F2F_E74D_470B_AB01_DACBD056AA50__INCLUDED_)
#define AFX_ISO9141_H__62C51F2F_E74D_470B_AB01_DACBD056AA50__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "J2534.h"
#include "ProtocolBase.h"
#include "CircBuffer.h"

/*Callback to receive ISO9141 messages to the network*/

void OnISO9141RxMessage(PASSTHRU_MSG *pstPassThruMsg,LPVOID pVoid);

class CISO9141 : public CProtocolBase  
{
public:
	CISO9141(CDeviceBase *pclsDevice, CDebugLog * pclsDebugLog = NULL);
	~CISO9141();
	
	virtual J2534ERROR	vConnect(
								J2534_PROTOCOL enProtocolID,
								unsigned long ulFlags,
								unsigned long ulBaudRate,
								DEVICEBASE_CALLBACK_RX_FUNC pfnCallback=NULL,
								DEVICEBASE_CALLBACK_FC_FUNC pfirstframefnCallback=NULL,
								DEVICEBASE_CALLBACK_ISO15765_SETRXSTATUS_FUNC psetRxstatusfnCallback=NULL,
								LPVOID		  pVoid=NULL);

	virtual J2534ERROR	vDisconnect();
	virtual J2534ERROR	vReadMsgs(
								PASSTHRU_MSG  *pstrucJ2534Msg, 
								unsigned long *pulNumMsgs, 
								unsigned long ulTimeout);
	virtual J2534ERROR	vWriteMsgs(
								PASSTHRU_MSG *pstrucJ2534Msg, 
								unsigned long *pulNumMsgs, 
								unsigned long ulTimeout);
	virtual J2534ERROR	vStartPeriodicMsg(
								PASSTHRU_MSG *pstrucJ2534Msg,
								unsigned long *pulMsgID,
								unsigned long ulTimeInterval);
	virtual J2534ERROR	vStopPeriodicMsg(unsigned long ulMsgID);

	virtual J2534ERROR	vStartMsgFilter(
								J2534_FILTER enFilterType,
								PASSTHRU_MSG *pstrucJ2534Mask,
								PASSTHRU_MSG *pstrucJ2534Pattern,
								PASSTHRU_MSG *pstrucJ2534FlowControl,
								unsigned long *pulFilterID);
	virtual J2534ERROR	vStopMsgFilter(unsigned long ulFilterID);

	virtual J2534ERROR	vIoctl(J2534IOCTLID enumIoctlID,
								void *pInput,
								void *pOutput);
	private:
	bool				IsMsgValid(PASSTHRU_MSG *pstPassThruMsg);
public:
	J2534ERROR				GetConfig(SCONFIG_LIST *pInput);
	J2534ERROR				SetConfig(SCONFIG_LIST *pInput);
	unsigned long			m_ulChecksumFlag;
};

#endif // !defined(AFX_ISO9141_H__62C51F2F_E74D_470B_AB01_DACBD056AA50__INCLUDED_)
