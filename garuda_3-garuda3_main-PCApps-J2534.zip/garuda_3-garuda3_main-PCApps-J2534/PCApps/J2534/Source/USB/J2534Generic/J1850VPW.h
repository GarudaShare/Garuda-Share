/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: J1850VPW.h
 Description			: This file contains the implementation of the class 
						  that is derived from CProtocolBase to support J1850VPW 
						  protocol as required by J2534.
 Date					: Feb 08, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Feb 08, 2008	Chakravarthy				Initial Version
*******************************************************************************/

#if !defined(AFX_J1850VPW_H__62BCD68E_73D8_4663_8413_F95CA3AEC9E3__INCLUDED_)
#define AFX_J1850VPW_H__62BCD68E_73D8_4663_8413_F95CA3AEC9E3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ProtocolBase.h"

/*Receving J1850 Messages*/
void OnJ1850VPWRxMessage(PASSTHRU_MSG *pstPassThruMsg, LPVOID pVoid);

class CJ1850VPW : public CProtocolBase  
{
public:

	CJ1850VPW(CDeviceBase *pclsDevice, CDebugLog * pclsDebugLog = NULL);
	~CJ1850VPW();
		
	virtual J2534ERROR	vConnect(
								J2534_PROTOCOL enProtocolID,
								unsigned long ulFlags,
								unsigned long ulBaudRate,
								DEVICEBASE_CALLBACK_RX_FUNC pfnCallback=NULL,
								DEVICEBASE_CALLBACK_FC_FUNC pfirstframefnCallback=NULL,
								DEVICEBASE_CALLBACK_ISO15765_SETRXSTATUS_FUNC psetRxstatusfnCallback=NULL,
								LPVOID		  pVoid=NULL);
	virtual J2534ERROR	vDisconnect();
	virtual J2534ERROR	vReadMsgs(
								PASSTHRU_MSG  *pstrucJ2534Msg, 
								unsigned long *pulNumMsgs, 
								unsigned long ulTimeout);
	virtual J2534ERROR	vWriteMsgs(
								PASSTHRU_MSG *pstrucJ2534Msg, 
								unsigned long *pulNumMsgs, 
								unsigned long ulTimeout);
	virtual J2534ERROR	vStartPeriodicMsg(
								PASSTHRU_MSG *pstrucJ2534Msg,
								unsigned long *pulMsgID,
								unsigned long ulTimeInterval);
	virtual J2534ERROR	vStopPeriodicMsg(unsigned long ulMsgID);

	virtual J2534ERROR	vStartMsgFilter(
								J2534_FILTER enFilterType,
								PASSTHRU_MSG *pstrucJ2534Mask,
								PASSTHRU_MSG *pstrucJ2534Pattern,
								PASSTHRU_MSG *pstrucJ2534FlowControl,
								unsigned long *pulFilterID);
	virtual J2534ERROR	vStopMsgFilter(unsigned long ulFilterID);

	virtual J2534ERROR	vIoctl(J2534IOCTLID enumIoctlID,
								void *pInput,
								void *pOutput);
	

	J2534ERROR				MessageValid(PASSTHRU_MSG	   *pstrucJ2534Msg,
										unsigned long  *pulNumMsgs);
	J2534ERROR				GetConfig(SCONFIG_LIST *pInput);
	J2534ERROR				SetConfig(SCONFIG_LIST *pInput);
	J2534ERROR				vSetProgrammingVoltage(unsigned long ulPin,
													unsigned long ulVoltage);
private:
	bool					IsMsgValid(PASSTHRU_MSG *pstPassThruMsg);
	PASSTHRU_MSG			structj1850;
	J2534_PROTOCOL			m_enJ1850Protocol;
};

#endif // !defined(AFX_J1850VPW_H__62BCD68E_73D8_4663_8413_F95CA3AEC9E3__INCLUDED_)
