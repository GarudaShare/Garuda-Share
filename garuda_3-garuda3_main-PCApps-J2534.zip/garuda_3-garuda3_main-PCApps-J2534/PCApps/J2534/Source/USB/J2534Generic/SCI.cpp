/******************************************************************************
					Dearborn Electronics India Pvt Ltd.,
*******************************************************************************
 Project Name			: Innova Shop Software - OEM Tool - J2534 API
 File Name				: SCI.cpp
 Description			: This file contains the implementation of the class 
						  that is derived from CProtocolBase to support SCI
						  protocol as required by J2534.
 Date					: Feb 21, 2008
 Version				: 1.0
 Author					: Chakravarthy
 Revision				: 
 Copyright (c) 2008 Dearborn Electronics India Pvt L, Inc

 File		 Date			Author						Description
 Version
_______________________________________________________________________________
 1.0		Feb 21, 2008	Chakravarthy				Initial Version
*******************************************************************************/

#include "stdafx.h"
#include "J2534Generic.h"
#include "SCI.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
//-----------------------------------------------------------------------------
//	Function Name	: CSCI
//	Input Params	: void
//	Output Params	: void
//	Description		: Constructor for CSCI class
//-----------------------------------------------------------------------------
CSCI::CSCI(CDeviceBase *pclsDevice, CDebugLog *pclsDebugLog) :
			CProtocolBase(pclsDevice, pclsDebugLog)
{
	
	//	m_pCFilterMsg = NULL;	
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SCI.cpp", "CSCI()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Initialize.
	m_bConnected = false;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SCI.cpp", "CSCI()", DEBUGLOG_TYPE_COMMENT, 
						 "End");
	}
	m_bLoopback = FALSE;
}
//-----------------------------------------------------------------------------
//	Function Name	: ~CSCI
//	Input Params	: void
//	Output Params	: void
//	Description		: Destructor for CSCI class
//-----------------------------------------------------------------------------
CSCI::~CSCI()
{
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SCI.cpp", "~CSCI()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Disconnect() incase not called yet.
	vDisconnect();

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SCI.cpp", "~CSCI()", DEBUGLOG_TYPE_COMMENT, "End");
	}
}
//-----------------------------------------------------------------------------
//	Function Name	: vConnect
//	Input Params	: 
//	Output Params	: 
//	Description		: This function establishes connection to the proctol.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR CSCI::vConnect(
						J2534_PROTOCOL	enProtocolID,
						unsigned long   ulFlags,
						unsigned long	ulBaudRate,
						DEVICEBASE_CALLBACK_RX_FUNC pfnCallback,
						DEVICEBASE_CALLBACK_FC_FUNC pfirstframefnCallback,
						DEVICEBASE_CALLBACK_ISO15765_SETRXSTATUS_FUNC psetRxstatusfnCallback,
						LPVOID			pVoid)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char			szBuffer[SCI_ERROR_TEXT_SIZE];
	J2534ERROR		enJ2534Error;

	switch(enProtocolID)
	{
		case SCI_A_ENGINE:
		case SCI_A_TRANS:
		case SCI_B_ENGINE:
		case SCI_B_TRANS:
			{
				if (((abs(ulBaudRate - SCI_DATA_RATE_DEFAULT) / SCI_DATA_RATE_DEFAULT) > 0.02) && 
					((abs(ulBaudRate - SCI_MIDDATA_RATE) / SCI_MIDDATA_RATE) > 0.02) &&
					((abs(ulBaudRate - SCI_MAXDATA_RATE) / SCI_MAXDATA_RATE) > 0.02))
				{
					return(J2534_ERR_INVALID_BAUDRATE);
				}
				m_enSCIProtocol = enProtocolID;
			}
			break;
		default:
			break;
	}
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SCI.cpp", "vConnect()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Call Connect of Base.
	if ((enJ2534Error = CProtocolBase::vConnect(enProtocolID, ulFlags, ulBaudRate,
												OnSCIRxMessage,NULL,NULL,this))
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("SCI.cpp", "vConnect()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("SCI.cpp", "vConnect()", DEBUGLOG_TYPE_COMMENT, szBuffer);
	}
	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vDisconnect
//	Input Params	: 
//	Output Params	: 
//	Description		: This function disconnects the connection to a protocol.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR CSCI::vDisconnect()
{
	char			szBuffer[SCI_ERROR_TEXT_SIZE];
	J2534ERROR		enJ2534Error;

	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SCI.cpp", "vDisconnect()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Disconnect this protocol.
	if ((enJ2534Error = CProtocolBase::vDisconnect()) != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("SCI.cpp", "vDisconnect()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("SCI.cpp", "CSCI()", DEBUGLOG_TYPE_COMMENT, szBuffer);
	}
	return(J2534_STATUS_NOERROR);
}
//-----------------------------------------------------------------------------
//	Function Name	: vReadMsgs
//	Input Params	: 
//	Output Params	: 
//	Description		: This function reads the messages out of a circular buffer
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here. 
//-----------------------------------------------------------------------------
J2534ERROR CSCI::vReadMsgs(PASSTHRU_MSG		*pstPassThruMsg,
						   unsigned long	*pulNumMsgs,
						   unsigned long	ulTimeout)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char		szBuffer[SCI_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SCI.cpp", "vReadMsgs()", DEBUGLOG_TYPE_COMMENT, "Start");
	}

	// Write using the generic Write.
	if ((enJ2534Error = CProtocolBase::vReadMsgs(pstPassThruMsg,
												 pulNumMsgs,
												 ulTimeout)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("SCI.cpp", "vReadMsgs()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("SCI.cpp", "vReadMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}
//-----------------------------------------------------------------------------
//	Function Name	: vWriteMsgs
//	Input Params	: 
//	Output Params	: 
//	Description		: This function writes the message out to a circular buffer
//					  and waits until it is transmitted out on the bus or exits
//					  immediately after writing to buffer if it is non-blocking.
//					  The message is Blocking if the given timeout value is 
//					  greater than 0. The base class implements the generic 
//					  functionality. Any specific functionality to this derived
//					  class is implented here.
//-----------------------------------------------------------------------------
J2534ERROR CSCI::vWriteMsgs(PASSTHRU_MSG	*pstPassThruMsg,
						    unsigned long	*pulNumMsgs,
						    unsigned long	ulTimeout)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char		szBuffer[SCI_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;
	unsigned long	ulIdx1;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SCI.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	for (ulIdx1 = 0; ulIdx1 < *pulNumMsgs; ulIdx1++)
	{
		// Check Msg. Protocol ID.
		if ((pstPassThruMsg + ulIdx1)->ulProtocolID != m_enSCIProtocol)
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_MSG_PROTOCOL_ID);
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("SCI.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
								 szBuffer);
			}
			return(J2534_ERR_MSG_PROTOCOL_ID);
		}

		// Check if msg. format is valid.
		if (!IsMsgValid((pstPassThruMsg + ulIdx1)))
		{
			sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
			if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
			{
				m_pclsLog->Write("SCI.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
								 szBuffer);
			}
			return(J2534_ERR_INVALID_MSG);
		}
	}

	// Write using the generic Write.
	if ((enJ2534Error = CProtocolBase::vWriteMsgs(pstPassThruMsg,
												  pulNumMsgs,
												  ulTimeout)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("SCI.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("SCI.cpp", "vWriteMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}
//-----------------------------------------------------------------------------
//	Function Name	: vStartPeriodicMsg
//	Input Params	: 
//	Output Params	: 
//	Description		: This funtions starts a Periodic msg. on a given channel
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR CSCI::vStartPeriodicMsg(PASSTHRU_MSG		*pstPassThruMsg,
								   unsigned long	*pulMsgID,
								   unsigned long	ulTimeInterval)
{
	//*****************************IMPORTANT NOTE******************************* 
	// Perform all the protocol specific stuff in this function.
	//**************************************************************************

	char		szBuffer[SCI_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SCI.cpp", "vStartPeriodicMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Check Msg. Protocol ID.
	if (pstPassThruMsg->ulProtocolID != m_enSCIProtocol)
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_MSG_PROTOCOL_ID);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("SCI.cpp", "vStartPeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_MSG_PROTOCOL_ID);
	}

	// Check if msg. format is valid.
	if (!IsMsgValid(pstPassThruMsg))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_INVALID_MSG);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("SCI.cpp", "vStartPeriodicMsgs()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(J2534_ERR_INVALID_MSG);
	}

	// Start Periodic using the generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStartPeriodicMsg(pstPassThruMsg,
														 pulMsgID,
														 ulTimeInterval)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("SCI.cpp", "vStartPeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("SCI.cpp", "vStartPeriodicMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStopPeriodicMsg
//	Input Params	: 
//	Output Params	: 
//	Description		: This functions stops the Periodic Msg. that was started
//					  earlier. The base class implements the generic 
//					  functionality. Any specific functionality to this derived
//					  class is implented here.
//-----------------------------------------------------------------------------
J2534ERROR CSCI::vStopPeriodicMsg(unsigned long ulMsgID)
{
	char		szBuffer[SCI_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;
	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SCI.cpp", "vStopPeriodicMsgs()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Stop Periodic using the generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStopPeriodicMsg(ulMsgID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("SCI.cpp", "vStopPeriodicMsg()", 
							 DEBUGLOG_TYPE_ERROR, szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("SCI.cpp", "vStopPeriodicMsgs()", 
						 DEBUGLOG_TYPE_COMMENT, szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStartMsgFilter
//	Input Params	: 
//	Output Params	: 
//	Description		: This function sets up a msg. filter as requested.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR	CSCI::vStartMsgFilter(J2534_FILTER		enumFilterType,
								  PASSTHRU_MSG		*pstMask,
								  PASSTHRU_MSG		*pstPattern,
								  PASSTHRU_MSG		*pstFlowControl,
								  unsigned long		*pulFilterID)
{
	char		szBuffer[SCI_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;
	unsigned long	ulOne;
	ulOne = 1;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SCI.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	// Check Msg. Protocol ID.
	if ((pstMask->ulProtocolID != m_enSCIProtocol) ||
		(pstPattern->ulProtocolID != m_enSCIProtocol))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_ERR_MSG_PROTOCOL_ID);
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			m_pclsLog->Write("SCI.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(J2534_ERR_MSG_PROTOCOL_ID);
	}
	// StartMsgFilter using generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStartMsgFilter(
										  enumFilterType,
										  pstMask,
										  pstPattern,
										  pstFlowControl,
										  pulFilterID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("SCI.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("SCI.cpp", "vStartMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}

//-----------------------------------------------------------------------------
//	Function Name	: vStopMsgFilter
//	Input Params	: 
//	Output Params	: 
//	Description		: This function stops a msg. filter that was set earlier.
//					  The base class implements the generic functionality. Any
//					  specific functionality to this derived class is implented
//					  here.
//-----------------------------------------------------------------------------
J2534ERROR	CSCI::vStopMsgFilter(unsigned long ulFilterID)
{
	char		szBuffer[SCI_ERROR_TEXT_SIZE];
	J2534ERROR	enJ2534Error;

	// Write to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SCI.cpp", "vStopMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}
	// StopMsgFilter using generic routine from base.
	if ((enJ2534Error = CProtocolBase::vStopMsgFilter(ulFilterID)) 
					  != J2534_STATUS_NOERROR)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "returned 0x%02X", enJ2534Error);
			m_pclsLog->Write("SCI.cpp", "vStopMsgFilter()", DEBUGLOG_TYPE_ERROR, 
						     szBuffer);
		}
		return(enJ2534Error);
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", J2534_STATUS_NOERROR);
		m_pclsLog->Write("SCI.cpp", "vStopMsgFilter()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	return(J2534_STATUS_NOERROR);
}
//-----------------------------------------------------------------------------
//	Function Name	: vIoctl
//	Input Params	: 
//	Output Params	: 
//	Description		: This is a virtual function which should be implemented by
//					  the class derived from this base class.
//-----------------------------------------------------------------------------
J2534ERROR	CSCI::vIoctl(J2534IOCTLID enumIoctlID,
							   void *pInput,
							   void *pOutput)
{
	char	szBuffer[SCI_ERROR_TEXT_SIZE];
	J2534ERROR enumJ2534Error = J2534_STATUS_NOERROR;

	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SCI.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
						 "Start");
	}

	switch(enumIoctlID)
	{
	case GET_CONFIG:			// Get configuration	
		{
			enumJ2534Error = GetConfig((SCONFIG_LIST *)pInput);
		}
		break;
		
	case SET_CONFIG:			// Set configuration
		{
			enumJ2534Error = SetConfig((SCONFIG_LIST *)pInput);
		}
		
		break;
		
	case CLEAR_TX_BUFFER:
			// Clear all messages in its transmit queue
			if( m_pclsTxCircBuffer != NULL)
			{
			m_pclsTxCircBuffer->ClearBuffer();
			/*Send the IOCTL to device also*/
			if (enumJ2534Error = CProtocolBase::vIoctl(CLEAR_TX_BUFFER,
														NULL,
														NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("SCI.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
		}
		break;
		
	case CLEAR_RX_BUFFER:// Clear all messages in its receive queue
			if( m_pclsRxCircBuffer != NULL)
		{		
			m_pclsRxCircBuffer->ClearBuffer();
			if (enumJ2534Error = CProtocolBase::vIoctl(CLEAR_RX_BUFFER,
														NULL,
														NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("SCI.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
		}
		
		break;
		
	case CLEAR_PERIODIC_MSGS:	// Clear all periodic messages
		{			
			if (m_pclsPeriodicMsg != NULL)
			{
				delete m_pclsPeriodicMsg;
				m_pclsPeriodicMsg = NULL;
			}
			if (enumJ2534Error = CProtocolBase::vIoctl(CLEAR_PERIODIC_MSGS,
														NULL,
														NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("SCI.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
		}
		break;
		
	case CLEAR_MSG_FILTERS:		// Clear all message filters
		{		
			if (m_pclsFilterMsg != NULL)
			{
				delete m_pclsFilterMsg;
				m_pclsFilterMsg = NULL;
			}
			if (enumJ2534Error = CProtocolBase::vIoctl(CLEAR_MSG_FILTERS,
														NULL,
														NULL))														
			{
				if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
				{
					sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
					m_pclsLog->Write("SCI.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						szBuffer);
				}
			}
		}
		break;
		
	default:					// Others not supported
		enumJ2534Error = J2534_ERR_NOT_SUPPORTED;
		break;
	}

	// Write status to Log File.
	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
		if (enumJ2534Error != J2534_STATUS_NOERROR)
			m_pclsLog->Write("SCI.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
						 szBuffer);
		else
			m_pclsLog->Write("SCI.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
						 szBuffer);
	}

	if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
	{
		m_pclsLog->Write("SCI.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
						 "End");
	}

	return(enumJ2534Error);
}

//-----------------------------------------------------------------------------
//	Function Name	: OnSCIRx
//	Input Params	: void
//	Output Params	: void
//	Description		: This is a callback routine that is called upon receiving
//					  SCI messages.
//-----------------------------------------------------------------------------
void OnSCIRxMessage(PASSTHRU_MSG *pstPassThruMsg, LPVOID pVoid)
{
	CSCI					*pclsSCI;
	FILTERMSG_CONFORM_REQ	stConformReq;

	pclsSCI = (CSCI *) pVoid;

	// Check for NULL pointer.
	if (pclsSCI == NULL)
	{
		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			CProtocolBase::m_pclsLog->Write("CSCI.cpp", "OnSCIRx()", 
							 DEBUGLOG_TYPE_COMMENT, "NULL pointer");
		}
		return;
	}

	if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
	{
		CProtocolBase::m_pclsLog->Write("CSCI.cpp", "OnSCIRx()", 
						 DEBUGLOG_TYPE_COMMENT, "CALLBACK");
	}

	// Check if this is a Loopback message.
	if (pstPassThruMsg->ulRxStatus & J2534_RX_FLAGBIT_MSGTYPE)
	{
		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			CProtocolBase::m_pclsLog->Write("CSCI.cpp", "OnSCIRx()", 
							 DEBUGLOG_TYPE_COMMENT, "Tx CALLBACK");
		}
		if (pclsSCI->m_bLoopback == false)
			return;

		// Enqueue to Circ Buffer.
		pclsSCI->m_pclsRxCircBuffer->Write((unsigned char *) pstPassThruMsg, 
					(sizeof(PASSTHRU_MSG) - sizeof(pstPassThruMsg->ucData) +
					pstPassThruMsg->ulDataSize));
		return;
	}
	else
	{

		if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
		{
			CProtocolBase::m_pclsLog->Write("CSCI.cpp", "OnSCIRx()", 
							 DEBUGLOG_TYPE_COMMENT, "Tx CALLBACK");
		}

		// Enqueue to Circ Buffer.
		pclsSCI->m_pclsRxCircBuffer->Write((unsigned char *) pstPassThruMsg, 
					(sizeof(PASSTHRU_MSG) - sizeof(pstPassThruMsg->ucData) +
					pstPassThruMsg->ulDataSize));
		return;
	}

	if ((CProtocolBase::m_pclsLog != NULL) && (CProtocolBase::m_pclsLog->m_pfdLogFile != NULL))
	{
		CProtocolBase::m_pclsLog->Write("CSCI.cpp", "OnSCIRx()", 
						 DEBUGLOG_TYPE_COMMENT, "Rx CALLBACK");
	}
	// Apply Filters and see if msg. is required.
	if (pclsSCI->m_pclsFilterMsg != NULL)
	{
		stConformReq.bReqPass = true;
		stConformReq.bReqBlock = true;
		if (pclsSCI->m_pclsFilterMsg->IsMsgRequired(pstPassThruMsg, &stConformReq))
		{
		// Enqueue to Circ Buffer.
			pclsSCI->m_pclsRxCircBuffer->Write((unsigned char *) pstPassThruMsg, 
					(sizeof(PASSTHRU_MSG) - sizeof(pstPassThruMsg->ucData) +
					pstPassThruMsg->ulDataSize));
		}
	}

	return;
}

//-----------------------------------------------------------------------------
//	Function Name	: IsMsgValid
//	Input Params	: void
//	Output Params	: void
//	Description		: This checks the validity of message structure as required
//					  by J2534 standard.
//-----------------------------------------------------------------------------
bool CSCI::IsMsgValid(PASSTHRU_MSG *pstPassThruMsg)
{
	if ((pstPassThruMsg->ulDataSize < SCI_MSG_SIZE_MIN) || 
		(pstPassThruMsg->ulDataSize > SCI_MSG_SIZE_MAX))
	{
		return(false);
	}
	return(true);
}

J2534ERROR CSCI::MessageValid(PASSTHRU_MSG	   *pstrucJ2534Msg,
								   unsigned long  *pulNumMsgs)
{
	unsigned long	ulIdx1;
	
	for (ulIdx1 = 0; ulIdx1 < *pulNumMsgs; ulIdx1++)
	{		
		if ((pstrucJ2534Msg + ulIdx1)->ulDataSize == 0 ||
			(pstrucJ2534Msg + ulIdx1)->ulDataSize > SCI_MAX_DATALENGTH)
		{
			// Message with data length being 0 bytes or 
			// greater than 4128 bytes
			*pulNumMsgs = 0;
			return(J2534_ERR_INVALID_MSG);
		}
	}
	return(J2534_STATUS_NOERROR);
}
//-----------------------------------------------------------------------------
//	Function Name	: GetConfig
//	Input Params	: 
//	Output Params	: 
//	Description		: This function gets the configuration for selected 
//					  parameters for a given channel card.
//-----------------------------------------------------------------------------
J2534ERROR CSCI::GetConfig(SCONFIG_LIST *pInput)
{
	J2534ERROR		enumJ2534Error;
	SCONFIG			*pSconfig;
	unsigned long	ulCount;
	char	szBuffer[SCI_ERROR_TEXT_SIZE];

	enumJ2534Error = J2534_STATUS_NOERROR;

	// Make sure pInput is not NULL
	if (pInput == NULL)
		return(J2534_ERR_NULLPARAMETER);

	if (pInput->ulNumOfParams == 0)
	{
		return(J2534_ERR_FAILED);
	}

	pSconfig = pInput->pConfigPtr;
	for (ulCount = 0; ulCount < pInput->ulNumOfParams; ulCount++)
	{
		switch (pSconfig->Parameter)
		{
			case DATA_RATE:			// Data Rate
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
														  pSconfig,
														  NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("SCI.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;

			case LOOPBACK:			// Loopback
				pSconfig->ulValue = m_bLoopback;
				break;
			case T1_MAX:			// T1_MAX
				
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("SCI.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			case T2_MAX:			// T2_MAX
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("SCI.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			case T3_MAX:			// T3_MAX
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("SCI.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			case T4_MAX:			// T4_MAX
				
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("SCI.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
		
			case T5_MAX:			// T5_MAX
				if (enumJ2534Error = CProtocolBase::vIoctl(GET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("SCI.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				break;
			default:
				return(J2534_ERR_NOT_SUPPORTED);
		}
		if (enumJ2534Error != J2534_STATUS_NOERROR) // If something is wrong
			return(enumJ2534Error);
		
		pSconfig++;
	}
	return(enumJ2534Error);
}

//-----------------------------------------------------------------------------
//	Function Name	: SetConfig
//	Input Params	: 
//	Output Params	: 
//	Description		: This function sets the configuration for selected 
//					  parameters for a given channel card.
//-----------------------------------------------------------------------------
J2534ERROR CSCI::SetConfig(SCONFIG_LIST *pInput)
{
	J2534ERROR		enumJ2534Error;
	SCONFIG			*pSconfig;
	unsigned long	ulCount;
	char	szBuffer[SCI_ERROR_TEXT_SIZE];

	enumJ2534Error = J2534_STATUS_NOERROR;

	// Make sure pInput is not NULL
	if (pInput == NULL)
		return(J2534_ERR_NULLPARAMETER);

	if (pInput->ulNumOfParams == 0)
	{
		return(J2534_ERR_FAILED);
	}

	pSconfig = pInput->pConfigPtr;

	for (ulCount = 0; ulCount < pInput->ulNumOfParams; ulCount++)
	{
		if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
		{
			sprintf(szBuffer, "SetConfig Parameter %lu Value %lu", 
				pSconfig->Parameter, pSconfig->ulValue);
			m_pclsLog->Write("SCI.cpp", "vIoctl()", DEBUGLOG_TYPE_COMMENT, 
				szBuffer);
		}
		switch (pSconfig->Parameter)
		{
		case DATA_RATE:			// Data Rate

			if (((abs(pSconfig->ulValue - SCI_DATA_RATE_DEFAULT) / SCI_DATA_RATE_DEFAULT) <= 0.02) || 
				((abs(pSconfig->ulValue - SCI_MIDDATA_RATE) / SCI_MIDDATA_RATE) <= 0.02) ||
				((abs(pSconfig->ulValue - SCI_MAXDATA_RATE) / SCI_MAXDATA_RATE) <= 0.02))
			{
				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
															pSconfig,
															NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("SCI.cpp", "vConnect()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
			}
			else
				enumJ2534Error = J2534_ERR_INVALID_BAUDRATE;
			break;
			case LOOPBACK:			// Loopback

				if ((pSconfig->ulValue < 0) || (pSconfig->ulValue > 1))
					return(J2534_ERR_INVALID_IOCTL_VALUE);
				
				if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
														   pSconfig,
														   NULL))														
				{
					if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
					{
						sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
						m_pclsLog->Write("SCI.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
							szBuffer);
					}
				}
				m_bLoopback = pSconfig->ulValue;
				break;

			case T1_MAX:			// T1_MAX
					if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))	
					// Invalid value
					{
						return(J2534_ERR_INVALID_IOCTL_VALUE);
					}
					if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
																pSconfig,
																NULL))														
					{
						if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
						{
							sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
							m_pclsLog->Write("SCI.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
								szBuffer);
						}
					}
					break;
			case T2_MAX:			// T2_MAX
					if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))	
					// Invalid value
					{
						return(J2534_ERR_INVALID_IOCTL_VALUE);
					}
					if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
																pSconfig,
																NULL))														
					{
						if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
						{
							sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
							m_pclsLog->Write("SCI.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
								szBuffer);
						}
					}
					break;
			case T3_MAX:			// T3_MAX
					if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))	
					// Invalid value
					{
						return(J2534_ERR_INVALID_IOCTL_VALUE);
					}
					if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
																pSconfig,
																NULL))														
					{
						if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
						{
							sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
							m_pclsLog->Write("SCI.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
								szBuffer);
						}
					}
					break;
			case T4_MAX:			// T4_MAX
					if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))	
					// Invalid value
					{
						return(J2534_ERR_INVALID_IOCTL_VALUE);
					}
					if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
																pSconfig,
																NULL))														
					{
						if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
						{
							sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
							m_pclsLog->Write("SCI.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
								szBuffer);
						}
					}
					break;
			case T5_MAX:			// T5_MAX
					if ((pSconfig->ulValue < 0x0) || (pSconfig->ulValue > 0xFFFF))	
					// Invalid value
					{
						return(J2534_ERR_INVALID_IOCTL_VALUE);
					}
					if (enumJ2534Error = CProtocolBase::vIoctl(SET_CONFIG,
																pSconfig,
																NULL))														
					{
						if ((m_pclsLog != NULL) && (m_pclsLog->m_pfdLogFile != NULL))
						{
							sprintf(szBuffer, "returned 0x%02X", enumJ2534Error);
							m_pclsLog->Write("SCI.cpp", "vIoctl()", DEBUGLOG_TYPE_ERROR, 
								szBuffer);
						}
					}
					break;	
			default:
				return(J2534_ERR_NOT_SUPPORTED);
		}

		if (enumJ2534Error != J2534_STATUS_NOERROR) // If something is wrong
			return(enumJ2534Error);
		
		pSconfig++;
	}

	return(enumJ2534Error);
}
